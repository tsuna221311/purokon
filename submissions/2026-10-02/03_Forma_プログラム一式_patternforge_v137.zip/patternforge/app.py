"""app.py — PatternForge のFlask API + 簡易フロントエンド。

エンジン部分(engine/)とは完全に分離してあるので、Flaskを別のフレームワーク
(FastAPIなど)に差し替えたい場合もengine配下のコードは変更不要。

エンドポイント:
  GET  /                       — 採寸入力・パーツ選択フォーム(UI本体)
  POST /api/generate           — 型紙生成本体。JSON {ok, ...summary...} を返す
  POST /api/custom-panel/trace  — アップロード画像から輪郭を自動抽出（round10で追加）
  GET  /download/<job_id>/<fmt> — 生成したSVG/PDFのダウンロード(fmt: svg|pdf)
  GET  /healthz                 — 動作確認用
  GET  /favicon.ico              — favicon（ブラウザが自動リクエストするため常時提供）
  GET/POST /signup, /login      — アカウント登録・ログイン
  POST /logout                  — ログアウト
  GET  /verify/<token>           — メールアドレス確認
  POST /account/resend-verification — 確認メールの再送
  GET/POST /forgot-password      — パスワード再設定メールの送信
  GET/POST /reset-password/<token> — パスワードの再設定
  GET  /account                 — マイページ（利用状況・プラン・生成履歴・採寸プロフィール）
  POST /account/upgrade|downgrade — プラン切り替え
  POST /api/profiles             — 採寸プロフィールの保存（JSON API、ログイン必須）
  POST /account/profiles/<id>/delete — 採寸プロフィールの削除
  POST /account/jobs/<job_id>/regenerate — 生成履歴からの再生成（round8で追加）
  GET  /account/export           — 自分のデータ一式をJSONでダウンロード（round8で追加）
  GET/POST /account/delete       — 退会（パスワード再確認の上でアカウント削除。round8で追加）
  POST /account/api-keys          — APIキーの発行（round8で追加）
  POST /account/api-keys/<id>/revoke — APIキーの失効（round8で追加）
  POST /api/v1/generate           — プログラマティックAPI（APIキー認証。round8で追加）
  POST /org/create                — 組織の作成（round8で追加）
  POST /org/invite                — 組織メンバーの招待（round8で追加）
  GET  /org/invites/<token>       — 招待の確認画面（round8で追加）
  POST /org/invites/<token>/accept — 招待の受諾（round8で追加）
  POST /org/members/<id>/remove   — メンバーを外す・自主退会（round8で追加）
  POST /org/disband               — 組織の解散（round8で追加）
  POST /billing/webhook          — Stripe Webhook（Stripe未設定時は404）
  GET  /pricing                 — 料金ページ
  GET  /guide                   — 使い方ガイド（操作マニュアル）
  GET  /terms, /privacy, /legal — 利用規約・プライバシーポリシー・運営者情報
                                   （公開前に実際の事業者情報へ差し替えが必要。README参照）

商用サービス化にあたって追加した機能と、正直な実装レベルの注記:
  - ジョブの所有権チェック（本物）: 生成したパターンは、生成したブラウザ
    セッション（未ログイン時はセッションに紐づく匿名visitor_id、ログイン時は
    ユーザーID）以外からはダウンロードできない。store.py にSQLiteで永続化。
  - 認証（本物）: パスワードはwerkzeug.securityでハッシュ化して保存し、
    セッションもFlaskの署名付きセッションで管理する。メールアドレス確認・
    パスワード再設定も、使い捨てトークン(store.py)+メール送信(mailer.py)で
    実際に機能する（ただしConsoleMailerが既定のため、SMTP環境変数を設定
    しない限り実際にはメールは届かず、代わりに開発用としてリンクを画面に
    表示する。下記mailer.py参照）。
  - 決済（設定次第で本物）: `STRIPE_SECRET_KEY` と `STRIPE_PRICE_ID` を
    設定すると、実際にStripeのCheckout Session(サブスクリプション)を作成し、
    Webhook(`/billing/webhook`)で支払い確定/解約を受け取ってplanを更新する
    (billing.py参照)。未設定の場合はこれまで通り、DB上のplan列を
    テストモードで即座に切り替えるだけのモックにフォールバックする。
  - 利用回数の上限（本物）: プランごとの1日あたり生成回数をSQLiteで
    強制する。読み取り→判定→書き込みは `BEGIN IMMEDIATE` で直列化しており、
    並行リクエストによる上限のすり抜けを防いでいる（store.py参照）。
    短い時間窓のレート制限(下記_RateLimiter)も、round6で同じSQLite
    (`store.py`の`check_rate_limit`)に切り替えたため、複数ワーカー/
    複数プロセス構成でも正しく共有される。

第2回セキュリティ監査（認証・並行性・新機能の攻撃面）で見つかった問題と対応:
  - パスワード再設定後のセッション無効化（本物）: `users.session_version`を
    パスワード変更のたびにインクリメントし、`_current_user()`で現在の値と
    セッションに埋め込んだ値を比較する。不一致（＝再設定前の古いセッション
    Cookie）ならその場でログアウト扱いにする。
  - スキーママイグレーションの並行性（修正済み）: 複数ワーカーが同時に
    `Store()`を構築しても`_migrate()`が"duplicate column name"で落ちない
    よう、`BEGIN IMMEDIATE`での直列化と重複エラーの無害化を追加した
    （store.py参照）。
  - メール確認・パスワード再設定エンドポイントのレート制限（本物）:
    IPベースの制限(`_email_send_rate_limiter`)に加え、同一ユーザー・
    同一目的への短時間の連続発行をDB側でも防ぐ(`store.seconds_since_last_token`)。
    IPローテーションを使った分散的なメール爆撃対策。
  - CSRF対策（round6で完全実装、README参照）: `SESSION_COOKIE_SAMESITE=Lax`に
    加え、状態変更リクエスト(GET/HEAD/OPTIONS以外)全体を対象にした
    トークン方式のCSRF対策を導入した(下記`_csrf_protect`参照)。第2回監査で
    「部分的な対策」として既知の制約に挙げていたものを、round6で解消した。
  - Stripe Webhookの防御的処理（本物）: `client_reference_id`が数値でない
    ・該当ユーザーが存在しない場合も例外で500にせず、警告ログを残した上で
    200を返しStripe側の再送ループを防ぐ。
  - `/account/upgrade`の冪等性（本物）: 既にProプランのユーザーが誤って
    連打しても、二重にCheckout Session/サブスクリプションを作らない。
  - メール確認は実装済みだが機能ゲートには使っていない（正直な限界。
    README参照）。

運用面の注意:
  - 開発サーバ(`python app.py`)は検証用。実運用では `gunicorn wsgi:app` 等の
    WSGIサーバを使うこと（wsgi.py参照）。
  - `generated/` に生成物が溜まり続けないよう、バックグラウンドスレッドで
    古いファイル(_cleanup_old_outputs)とjobsテーブルの古い行を掃除する
    簡易TTLクリーンアップを入れている。以前はリクエストごとに同期実行
    していたため、生成物が増えるほど毎リクエストのレイテンシが悪化する
    問題があった。今は最短実行間隔(_CLEANUP_MIN_INTERVAL_SECONDS)を
    設けたうえでバックグラウンドスレッドに投げるようにしている。
  - 同時多発リクエストからサーバを守るための最小限のレート制限を実装している
    (_RateLimiter)。round6より前は単一プロセスのメモリ(dequeベース)のみの
    簡易実装で、複数ワーカー/複数インスタンス構成では実質的な上限がワーカー
    数倍に緩んでいたが、round6でstore.pyのSQLite(`check_rate_limit`)に
    切り替え、複数ワーカー/複数プロセス間で共有されるようにした。
  - SECRET_KEY を環境変数で設定しないと、起動ごと・ワーカーごとにランダムな
    鍵を生成する。複数ワーカー構成ではワーカー間でセッションの署名鍵が
    揃わず、ログイン状態や匿名ジョブの所有権が正しく機能しないため、
    本番では必ず環境変数で固定値を設定すること。
"""

from __future__ import annotations
import hmac
import dataclasses
import json
import logging
import math
import os
import re
import secrets
import time
import unicodedata
import uuid
from functools import lru_cache, wraps
from pathlib import Path
from threading import Lock, Thread


def _load_project_dotenv() -> None:
    """プロジェクト直下の`.env`を読み込む最小実装。

    `.env.example` は以前から配布していたが、実際にはアプリが読んでいなかった。
    外部依存を増やさず、`KEY=value`、空行、`#`コメント、単純な引用符だけを
    扱う。既にPowerShellやOSから設定された値は絶対に上書きしない。
    """
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    try:
        with open(path, encoding="utf-8") as dotenv_file:
            lines = dotenv_file.readlines()
    except FileNotFoundError:
        return
    except OSError:
        # 秘密情報を含み得るファイルなので、内容や絶対パスをログへ出さない。
        logging.getLogger(__name__).warning("Project environment file could not be read.")
        return

    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if key.startswith("export "):
            key = key[7:].strip()
        if not key or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


# engine の初期化より先に読む必要がある。秘密鍵の値はログへ出さない。
_load_project_dotenv()

from flask import (
    Flask, Response, flash, g, jsonify, redirect, render_template, request, send_from_directory,
    session, url_for,
)
from PIL import Image, ImageDraw, ImageOps
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.middleware.proxy_fix import ProxyFix

import billing
import labels
import mailer
import store
from engine.custom_panel import (
    CustomPanelError,
    CustomPanelSpec,
    MAX_CUSTOM_PANELS_PER_REQUEST,
    validate_replacement_part_type,
    calibrate_points_to_cm,
    resolve_reference_cm,
    validate_boolean,
    validate_label,
    validate_quantity,
    validate_grade_increment,
)
from engine.accessory3d import (
    export_accessories_stl, export_vendor_package, normalize_order_options,
    validate_accessory_settings, validate_curvature_settings,
    validate_compound_curvature_settings,
    validate_attachment_interface, validate_magnet_pockets,
    validate_mounting_holes, validate_mounting_slots,
)
from engine.specification import export_specification_pdf, production_readiness
from engine.measurements import (Measurements, STANDARD_SIZE_GRADE_CM,
                                  _VALID_RANGES as MEASUREMENT_RANGES,
                                  validate_custom_grade_cm)
from engine.fabric_groups import (
    ASSIGNABLE_AREAS, DEFAULT_FABRIC_NAME, FabricGroupError,
    MAX_FABRIC_GROUPS, normalize_assignments,
)
from engine.measure_guide import guides_as_dict
from engine.plausibility import measurement_hints
from engine.costume_projects import costume_project_choices, get_costume_project
from engine.part_specs import (
    DEFAULT_FIT, FIT_PRESETS, STRETCH_PERCENT_RANGE, FitEase, custom_fit_ease,
    stretch_fit_ease,
)
from engine.blocks import (BLOCKS, DEFAULT_BLOCK_KEY, MEASURED_BLOCK_FIELDS,
                           MEASURED_BLOCK_KEY, MENS_BLOCK_ABSENT_NOTE,
                           validate_measured_block, get_block)
from engine.alteration import (ALTERATION_KINDS, MAX_ALTERATION_CM,
                                validate as validate_alterations)
from engine.stash import MIN_STASH_LENGTH_CM as STASH_MIN_LENGTH_CM
from engine.illustration_fit import SKIRT_LENGTH_RANGE_CM
from engine.pipeline import (
    PartRequest,
    COLLAR_STYLES,
    CUFFS_STYLES,
    NECKLINES,
    PANTS_STYLES,
    SKIRT_STYLES,
    SLEEVE_STYLES,
    WAISTBAND_STYLES,
    GarmentSpec,
    PatternForgePipeline,
    DEFAULT_SEAM_ALLOWANCE_CM,
    STANDARD_SIZE_ORDER,
    build_custom_panel_requests,
    build_garment_spec,
    merge_custom_panel_requests,
)
from engine.segmentation import SimpleSilhouetteSegmenter

# モジュールレベルで最低限のロギングを設定する。`logging.basicConfig` は
# root loggerにハンドラが無い場合のみ効くため、gunicorn配下で既にログ設定が
# されている場合は何もしない(no-op)。以前はこの呼び出しが `if __name__ ==
# "__main__":` の中にしか無く、本番のエントリポイントである wsgi.py 経由
# (`gunicorn wsgi:app`)ではその分岐を通らないため、app.logger.exception(...)
# が一切のハンドラ無しで実行され、最初の本番障害を追跡できない状態だった。
logging.basicConfig(
    level=os.environ.get("PATTERNFORGE_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)

# round8で追加: エラー監視(Sentry等)の任意統合。
#
# それまでは想定外の例外(app.logger.exception呼び出し箇所)がファイル/
# 標準出力のログにしか残らず、運用担当者がログを能動的に見に行かない限り
# 障害に気付けない(healthzによるプロセス生存確認とは別の、個々のリクエスト
# 単位のエラーを能動的に通知してくれる仕組みが無かった)という既知の限界が
# あった。`SENTRY_DSN`環境変数が設定されている場合のみ`sentry_sdk`を
# 初期化する。未設定時(デフォルト)は、これまで通りログのみの挙動を一切
# 変えない(既存の`app.logger.exception`呼び出しは、Sentry初期化後は
# FlaskIntegration経由で自動的にもSentryへ送られるが、初期化していなければ
# 何も変わらない)。
#
# 正直な限界: `sentry-sdk`パッケージ自体はrequirements.txtの必須依存には
# 含めていない(全ての利用者がSentryを使うとは限らないため、未使用機能の
# ためだけに依存を強制したくない)。`SENTRY_DSN`を設定したのに
# `sentry-sdk`が未インストールの場合は、起動時に警告ログを出した上で
# 通常通り起動を続ける(エラー監視が使えないだけで、サービス自体は落とさ
# ない)。実際に`pip install sentry-sdk`せずに`SENTRY_DSN`だけを設定して
# 起動し、ImportErrorが握りつぶされて通常通り動くことを確認済み。
_SENTRY_DSN = os.environ.get("SENTRY_DSN")
if _SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.flask import FlaskIntegration

        sentry_sdk.init(
            dsn=_SENTRY_DSN,
            integrations=[FlaskIntegration()],
            environment=os.environ.get("SENTRY_ENVIRONMENT", "production"),
            # パフォーマンストレース(traces_sample_rate)は既定でオフ。
            # エラー監視(例外の捕捉・通知)だけが目的で、リクエストごとの
            # 詳細なパフォーマンストレースはSentry側の追加コスト・データ量
            # 増加を伴うため、必要な場合のみ明示的に有効化させる。
            traces_sample_rate=float(os.environ.get("SENTRY_TRACES_SAMPLE_RATE", "0.0")),
        )
        logging.getLogger(__name__).info("Sentry error monitoring initialized (DSN configured).")
    except ImportError:
        logging.getLogger(__name__).warning(
            "SENTRY_DSN is set but the 'sentry-sdk' package is not installed. "
            "Run `pip install sentry-sdk` to enable error monitoring. "
            "Continuing without it (errors will still be logged normally)."
        )

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.environ.get("PATTERNFORGE_OUTPUT_DIR", os.path.join(BASE_DIR, "generated"))
DB_PATH = os.environ.get("PATTERNFORGE_DB_PATH", os.path.join(BASE_DIR, "patternforge.db"))
_JOB_ID_RE = re.compile(r"^[0-9a-f]{6,32}$")

#: `/download/<job_id>/<fmt>` が配れる形式 -> 実ファイル名のひな形。
#:
#: round39までは分岐(`fmt == "projector"`)を`download()`の中に直接書いて
#: いたが、round41で裏地(表地とは別の生地なので別ファイル)を足して形式が
#: 8つになったため、**許可リストとファイル名の対応を1か所**にまとめた。
#: 片方だけ更新して「許可はされているのにファイル名が合わず404」になる、
#: という食い違いが起きないようにするため。
_DOWNLOAD_FORMATS = {
    "svg": "{job_id}.svg",
    "pdf": "{job_id}.pdf",
    "dxf": "{job_id}.dxf",
    "zip": "{job_id}.zip",
    "stl": "{job_id}.stl",
    "vendor_zip": "{job_id}_vendor.zip",
    "spec_pdf": "{job_id}_specification.pdf",
    # round39: プロジェクター投影用の実寸1枚もの。
    "projector": "{job_id}_projector.pdf",
    # round41: 裏地の型紙。
    "lining_svg": "{job_id}_lining.svg",
    "lining_pdf": "{job_id}_lining.pdf",
    "lining_dxf": "{job_id}_lining.dxf",
    "lining_projector": "{job_id}_lining_projector.pdf",
    # round57: 生地ごとの章を1本にまとめたPDF(生地を分けたときだけ)。
    "all_fabrics_pdf": "{job_id}_all_fabrics.pdf",
    # round54: 2種類目以降の生地の型紙(engine/fabric_groups.py)。
    # 1種類目は上の "svg"/"pdf"/"dxf"/"projector" がそのまま担当する。
    # 形式名は `fabric2_pdf` のように「何番目の生地か」を含む。
    **{
        f"fabric{index}_{fmt}": pattern.format(job_id="{job_id}", index=index)
        for index in range(2, 7)   # engine.fabric_groups.MAX_FABRIC_GROUPS と対応
        for fmt, pattern in (
            ("svg", "{job_id}_fabric{index}.svg"),
            ("pdf", "{job_id}_fabric{index}.pdf"),
            ("dxf", "{job_id}_fabric{index}.dxf"),
            ("projector", "{job_id}_fabric{index}_projector.pdf"),
        )
    },
}

# 生成物の保存期間。ディスクを無制限に肥大化させないため、
# 既定では1時間で掃除する（ダウンロードし忘れてもしばらくは残る想定）。
OUTPUT_TTL_SECONDS = int(os.environ.get("PATTERNFORGE_OUTPUT_TTL_SECONDS", 3600))

# アップロード画像の最大ピクセル数（幅×高さ）。MAX_CONTENT_LENGTH(下記)は
# バイト数の上限だが、圧縮率の高いPNG(単色に近いイラスト等)は数百KBのまま
# 数千万〜億単位のピクセル数に展開できてしまう。SimpleSilhouetteSegmenterは
# 画像全体をnumpy配列に複数回コピーするため、対策無しだと数百MB〜数GBの
# メモリを1リクエストで確保してしまい、gunicornワーカーをOOM停止させ、
# 同じワーカーで処理中の他の顧客のリクエストまで巻き添えにする恐れがある。
# Image.open() 自体は多くの形式でヘッダのみ読み画素バッファは確保しないため、
# open()直後・load()より前にサイズを検査することで、実際のデコードコストを
# 払わずに拒否できる。
MAX_UPLOAD_IMAGE_PIXELS = int(os.environ.get("PATTERNFORGE_MAX_IMAGE_PIXELS", 25_000_000))

# Pillow自身も「解凍爆弾」対策として既定でMAX_IMAGE_PIXELS(約1.79億px)超の
# 画像をImage.open()の時点でDecompressionBombErrorとして例外にする。これが
# 有効なままだと、上のMAX_UPLOAD_IMAGE_PIXELS(2500万px)判定に到達する前に
# open()自体が失敗し、_load_uploaded_image()の広いexceptで「画像を読み込め
# ませんでした。対応形式(PNG/JPEG等)かご確認ください」という的外れな
# メッセージになってしまう(実際に手元で1.5万x1.5万pxのPNGを送って確認した
# 実バグ)。今回の上限は既にPillowの既定閾値よりずっと厳しく、かつ
# open()直後・load()より前にサイズだけ検査しているため、Pillow側の
# チェックは不要かつ有害。無効化して、常に上のwidth*height判定を
# 「解像度が大きすぎます」という正しい案内文で行わせる。
Image.MAX_IMAGE_PIXELS = None

# レート制限のクライアント識別に X-Forwarded-For を使うかどうか。
# このヘッダーはクライアントが自由に送れるため、信頼できるリバースプロキシの
# 背後で動かしていない限り、既定では無視して request.remote_addr のみを使う
# （そうしないと、ヘッダー値をリクエストごとに変えるだけでレート制限を
# 無条件に迂回できてしまう）。実際にnginx等のプロキシ配下で動かし、
# プロキシが正しくX-Forwarded-Forを設定し直している場合のみ、
# 環境変数で明示的に有効化すること。
TRUST_PROXY_HEADERS = os.environ.get("PATTERNFORGE_TRUST_PROXY_HEADERS") == "1"

os.makedirs(OUTPUT_DIR, exist_ok=True)

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "web", "templates"),
    static_folder=os.path.join(BASE_DIR, "web", "static"),
)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024  # 12MB（イラスト画像アップロード上限）
# SameSite=Lax: 他サイトからの自動送信フォーム(クロスサイトPOST)にセッション
# Cookieを付与しないようブラウザ側で防ぐ、実効性のあるCSRF対策の第一層。
# （第2回監査 指摘: 状態変更エンドポイント全体を保護する完全なCSRFトークン
# 方式ではないため、既存テストへの影響が大きいことを理由に当時は見送っていた
# が、round6で下記`_csrf_protect`のトークン方式を追加し、この制限を解消した。
# SameSite=Laxは、トークン方式の実装に不備があった場合の多層防御として
# 引き続き有効にしておく）。
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# HTTPS配下で運用する場合はPATTERNFORGE_FORCE_HTTPS=1を設定してSecure属性を
# 付与すること。既定でオフなのは、ローカル開発(HTTP)でログインできなくなる
# のを避けるため。
FORCE_HTTPS = os.environ.get("PATTERNFORGE_FORCE_HTTPS") == "1"
app.config["SESSION_COOKIE_SECURE"] = FORCE_HTTPS

#: HSTSの有効期間(秒)。1年。 (round48で追加)
#:
#: 【round47まで何が起きていたか】`PATTERNFORGE_FORCE_HTTPS=1` という
#: 「HTTPSで運用する」ための切り替えがあり、それでCookieにSecureは付けて
#: いたのに、**Strict-Transport-Security は一度も送っていなかった**。
#: 実際にヘッダーを読み出して見つけた(round48)。HSTSが無いと、利用者が
#: `http://` で来た最初の1回はブラウザが平文で繋ぎに行く——そこに
#: セッションCookieは乗らない(Secure付きなので)が、採寸値を打ち込む
#: ページ自体が平文で配られうる。
#:
#: 平文(HTTP)では**送らない**。HSTSはHTTPS応答でのみ意味を持つ仕様であり、
#: ローカル開発をHTTPSに縛ってしまわないためでもある。
#: `preload` は付けない——一度登録すると取り消しが難しく、
#: 運用する人が意図して選ぶべきものだから。
HSTS_MAX_AGE_SECONDS = 365 * 24 * 60 * 60

# --- 静的ファイルのキャッシュ (round48) -------------------------------------
#
# 【round47まで何が起きていたか】静的ファイルの寿命を指定していなかったため、
# Flaskの既定で `Cache-Control: no-cache` が付き、**ブラウザは毎回サーバへ
# 確認しに行っていた**。実測(Playwrightで2回続けて開く):
#
#     1回目: 全21リクエスト / うち /static/ が20 / 0.94秒
#     2回目: 全21リクエスト / うち /static/ が20（**全部304**）/ 0.67秒
#
# 20の内訳はネックライン・袖・スカートの見本SVGが18枚、CSSとJSが1つずつ。
# 中身は配信し直すまで1バイトも変わらないのに、開くたびに20往復している。
# 手元では0.67秒でも、往復に100ms掛かる回線では体感がまるで違う。
#
# 【どう直すか】URLに中身から決まる版(v=...)を付け、そのURLは1年キャッシュ
# させる。配信し直してファイルが変われば版が変わるので、古いものが
# 残り続けることはない。テンプレートは `url_for('static', ...)` のままでよい
# ——`url_defaults` で全部のURLに自動で付く。
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 365 * 24 * 60 * 60


@lru_cache(maxsize=1024)
def _static_asset_version(filename: str) -> str:
    """静的ファイルの版。更新時刻と大きさから決める(中身が変われば変わる)。

    毎リクエストstatするのを避けるためキャッシュする。ファイルを差し替えて
    すぐ反映したい開発中は、サーバを立ち上げ直せばよい(配信は入れ替えの
    たびにプロセスが起動するので、そこで新しくなる)。
    """
    if not app.static_folder:
        return ""
    path = os.path.join(app.static_folder, filename)
    try:
        stat = os.stat(path)
    except OSError:
        return ""          # 無いファイルには付けない(404はそのまま404)
    return f"{int(stat.st_mtime):x}{stat.st_size:x}"[-12:]


@app.url_defaults
def _add_static_asset_version(endpoint: str, values: dict) -> None:
    if endpoint != "static" or not values or "filename" not in values:
        return
    version = _static_asset_version(values["filename"])
    if version:
        values.setdefault("v", version)

# 実際にnginx等のリバースプロキシ配下を想定し、`X-Forwarded-Proto: https`・
# `X-Forwarded-Host`付きのリクエストを実際に(開発用サーバへ)送って見つかった
# 実バグの修正: 本番でよくある構成(プロキシがTLSを終端し、アプリへは平文
# HTTPで転送する)では、Flask/Werkzeugはリクエストがどの経路で来たかを
# 生のソケット接続だけで判断するため、`request.is_secure`は常にFalseになり、
# `url_for(..., _external=True)`が生成するURLは常に`http://`のまま、かつ
# ホスト名も外部向けのドメインではなくアプリが直接bindしている内部アドレス
# になってしまう。これはメール本文に載せる確認/パスワード再設定リンク
# (`_send_verification_email`・`/forgot-password`)にそのまま使われており、
# `PATTERNFORGE_FORCE_HTTPS=1`を設定していても、実際に上記ヘッダー付きで
# `/forgot-password`にPOSTしたところ、メールに載る再設定URLが
# `http://127.0.0.1:5000/reset-password/...`のような、外部の利用者からは
# アクセスできない/HTTPSの意図に反するリンクになることを確認した。
# `PATTERNFORGE_TRUST_PROXY_HEADERS=1`(信頼できる単一のリバースプロキシ
# 配下で動かしている場合のみ有効化する、既存のフラグ。上のX-Forwarded-For
# 対応と同じ前提)が立っている場合のみ、Werkzeug標準の`ProxyFix`で
# `X-Forwarded-Proto`/`X-Forwarded-Host`を1段分信頼してスキーム・ホスト名を
# 補正する(`x_for`はレート制限側の`_client_key()`で個別に、末尾値の抽出まで
# 含めて既に正しく扱っているため、ここでは重複させないよう`x_for=0`にする)。
if TRUST_PROXY_HEADERS:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=0, x_proto=1, x_host=1, x_port=0, x_prefix=0)

_SECRET_KEY_ENV = os.environ.get("SECRET_KEY")
if not _SECRET_KEY_ENV:
    logging.getLogger(__name__).warning(
        "SECRET_KEY が未設定のため、起動ごとにランダムな鍵を生成しています。"
        "複数ワーカー/複数プロセス構成では各プロセスで鍵が異なり、"
        "セッション(ログイン状態・匿名ジョブの所有権)が正しく機能しません。"
        "本番運用では環境変数 SECRET_KEY に固定の秘密値を設定してください"
        "（例: python -c \"import secrets; print(secrets.token_hex(32))\"）。"
    )
app.secret_key = _SECRET_KEY_ENV or secrets.token_hex(32)

# CSRF検証(下記`_csrf_protect`)を適用しないエンドポイント。billing_webhookは
# ブラウザセッションを経由しない(Stripeサーバーからの直接呼び出し)ため
# セッションCookieを持たず、そもそもCSRFトークンを検証する前提が成立しない。
# 代わりにStripe側の署名検証(`Stripe-Signature`ヘッダー)で保護している。
_CSRF_EXEMPT_ENDPOINTS = {"billing_webhook", "api_v1_generate"}

pipeline = PatternForgePipeline(output_dir=OUTPUT_DIR)
db = store.Store(DB_PATH)
mail = mailer.get_default_mailer()
payment_provider = billing.get_default_provider()


@app.after_request
def _set_security_headers(response):
    """すべてのレスポンスに最低限のセキュリティヘッダーを付与する。

    setdefaultを使っているのは、/download のようにレスポンス側で個別に
    もっと厳しいヘッダー(例: SVGへのContent-Security-Policy: sandbox)を
    設定している場合に、ここで上書きしてしまわないようにするため。
    """
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    )
    # round48: 実際にヘッダーを読み出して、付いていなかった3つを足す。
    # どれもこのアプリが**一度も使っていない**機能を閉じるもので、
    # 動きは変わらない(閉じることで、将来なにかが紛れ込んだときの被害を狭める)。
    response.headers.setdefault(
        # カメラ・マイク・位置情報・支払いは一切使っていない。
        "Permissions-Policy",
        "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    )
    # 別オリジンの窓から window.opener でこのページを触れないようにする。
    # このアプリは他所の窓と連携しないので、切って困るところが無い。
    response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    # 生成物(型紙)や画像を、他所のサイトから読み込ませない。
    # 採寸値から作られた個人性のあるファイルなので、埋め込みを許す理由が無い。
    response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
    # HTTPSで運用すると宣言しているときだけHSTSを送る(上記定数のコメント参照)。
    if FORCE_HTTPS:
        response.headers.setdefault(
            "Strict-Transport-Security",
            f"max-age={HSTS_MAX_AGE_SECONDS}; includeSubDomains")
    return response


def _client_key() -> str:
    if TRUST_PROXY_HEADERS:
        # 実際にPATTERNFORGE_TRUST_PROXY_HEADERS=1を有効にした状態でサーバを
        # 起動し、`/login`へ間違ったパスワードで15回連続POSTしたところ、
        # 毎回異なる値(例: "10.0.0.1, 203.0.113.9"、"10.0.0.2, 203.0.113.9"...)
        # をX-Forwarded-Forに付けるだけで一度も429にならず、レート制限が
        # 完全に無効化されることを確認した(同じ値を毎回送った場合は正しく
        # 11回目以降429になることも確認済み)。
        #
        # 原因: X-Forwarded-Forはクライアントが自由に最初のエントリを名乗れる
        # ヘッダーで、単一の信頼できるリバースプロキシ経由の場合、プロキシは
        # クライアントが送ってきた値の末尾に「実際に接続してきたIP」を追記する
        # (例: クライアントが"fake, spoofed"と送ると、プロキシ通過後は
        # "fake, spoofed, 実際のIP"になる)。以前はヘッダー値全体をそのまま
        # レート制限の鍵に使っていたため、クライアントが自由に書ける先頭部分
        # を変えるだけで毎回別の鍵として扱われ、TRUST_PROXY_HEADERSを有効化
        # したこと自体が既定(無効時)より安全性を下げてしまっていた
        # (無効時にこの迂回ができないことは
        # test_rate_limit_cannot_be_bypassed_by_spoofing_forwarded_for_header
        # で既にテスト済みだったが、有効時の同じ迂回は未検証だった)。
        #
        # 修正: ヘッダーをカンマ区切りで分解し、末尾(信頼できる直近のプロキシ
        # 自身が追記した部分)だけを鍵に使う。単一のプロキシがX-Forwarded-For
        # を正しく追記モードで運用している前提であり、複数段のプロキシを
        # 経由する構成では、末尾から数えて「信頼できるプロキシの段数」分だけ
        # 遡って取る必要がある(現状は1段のみ対応。将来複数段プロキシ構成に
        # 対応する場合は、信頼するプロキシの段数を別途環境変数化すること)。
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            parts = [p.strip() for p in forwarded.split(",") if p.strip()]
            if parts:
                return parts[-1]
        return request.remote_addr or "unknown"
    return request.remote_addr or "unknown"


@app.template_filter("datetime")
def _format_datetime(epoch_seconds: float) -> str:
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(epoch_seconds))


# round9で追加: index.htmlのプルダウン(ネックライン・袖の形等)の表示テキストを
# 内部識別子のまま出さず、日本語ラベルに変換するためのフィルタ
# (labels.pyのdocstring「実際に開発用サーバーを起動し...見つけた実バグ」参照)。
@app.template_filter("style_label")
def _style_label_filter(value: str | None) -> str:
    return labels.style_label(value)


def _today_str() -> str:
    """UTC日付の文字列(YYYY-MM-DD)。利用回数カウンタの区切り単位。"""
    return time.strftime("%Y-%m-%d", time.gmtime())


def _get_or_create_visitor_id() -> str:
    """未ログインユーザーのジョブ所有権を追跡するための匿名ID。

    Flaskの署名付きセッションクッキーに保存するため、クライアント側で
    値を書き換えて他人のジョブを装うことはできない。
    """
    vid = session.get("visitor_id")
    if not vid:
        vid = secrets.token_hex(16)
        session["visitor_id"] = vid
    return vid


def _get_or_create_csrf_token() -> str:
    """CSRFトークンをセッションから取得し、無ければ発行する。

    `_get_or_create_visitor_id`と同じ発想: Flaskの署名付きセッションCookie
    に保存するため、クライアント側で値を書き換えることはできない。ログイン
    有無にかかわらず(匿名で型紙生成する利用者もいるため)発行する。
    """
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_hex(32)
        session["csrf_token"] = token
    return token


@app.before_request
def _csrf_protect():
    """状態変更リクエスト全体を対象にしたCSRFトークン検証(round6で追加)。

    それまでは`SESSION_COOKIE_SAMESITE=Lax`のみに頼っており、第2回監査で
    「他サイトの自動送信フォームによる強制実行」は防げるが完全なCSRF対策
    ではないと指摘されていた既知の制約。ここでは、GET/HEAD/OPTIONS以外の
    全リクエストに対して、セッションに保存済みのトークンとリクエストに
    含まれるトークン(フォームの`csrf_token`フィールド、またはJSON/AJAX
    向けの`X-CSRFToken`ヘッダー)が一致することを検証する。

    ひとつの`before_request`フックで全エンドポイントを一括保護する設計に
    したのは、各POSTエンドポイントに個別デコレータを付け忘れるリスクを
    無くすため(実際、今回洗い出した時点で状態変更エンドポイントは10個以上
    あり、手動での付け忘れは現実的なリスクだった)。Stripe Webhook
    (`/billing/webhook`)だけは例外(`_CSRF_EXEMPT_ENDPOINTS`)で、そもそも
    ブラウザセッションを経由しない(Stripeサーバーからの直接呼び出しで
    セッションCookie自体を持たない)上、署名検証(`Stripe-Signature`)という
    CSRFより強い方式で保護されているため対象外にしている。
    """
    if request.method in ("GET", "HEAD", "OPTIONS", "TRACE"):
        return None
    if request.endpoint is None or request.endpoint in _CSRF_EXEMPT_ENDPOINTS:
        # endpoint未解決(存在しないパスへのPOST等)はこの後どのみち404に
        # なるため、CSRF検証をする意味が無く素通しする。
        return None

    expected = session.get("csrf_token")
    submitted = request.form.get("csrf_token") or request.headers.get("X-CSRFToken", "")
    if not expected or not submitted or not hmac.compare_digest(expected, submitted):
        app.logger.warning(
            "CSRF token mismatch or missing (endpoint=%s, path=%s)",
            request.endpoint, request.path,
        )
        message = "セキュリティ確認に失敗しました。ページを再読み込みしてからもう一度お試しください。"
        if request.path.startswith("/api/") or request.accept_mimetypes["application/json"] > request.accept_mimetypes["text/html"]:
            return jsonify({"ok": False, "error": message}), 400
        # 第2回監査で見つけた`_login_required`の実バグ(下記参照)と同じ罠を
        # ここでも踏まないよう、あえて`flash()`(=session書き込み)を使わない。
        # SameSite=Laxにより、他サイトからの偽装クロスサイトPOSTはそもそも
        # 本物のセッションCookieを伴わずに届く(=このリクエストのsessionは
        # 空)。この状態で`flash()`を呼ぶと、Flaskは空の新規セッションに
        # フラッシュメッセージを書き込んで`modified`扱いにし、302応答に
        # Set-Cookieを付与してしまう。ログイン中の利用者のブラウザは
        # これを同一オリジンからの正当な応答として受け取り保存するため、
        # 本来のログイン済みセッションCookieが空の新規セッションで
        # 上書きされ、利用者が何もしていないのに強制ログアウトされる
        # (`_login_required`のコメント、および`tests/test_app.py`の
        # `test_login_required_redirect_does_not_touch_session_cookie`参照)。
        # 代わりに`login_required=1`と同じ考え方で、セッションを一切
        # 変更しないクエリ文字列(`csrf_error=1`)だけでエラー状態を伝える。
        # リダイレクト先も`request.referrer`(攻撃者ページである可能性が
        # あり、そこへ誘導するとオープンリダイレクトになりうる)は使わず、
        # 常に固定の安全なページ(トップページ)にする。
        return redirect(url_for("index", csrf_error="1"))
    return None


def _current_user() -> "store.User | None":
    """ログイン中のユーザーを返す。session_versionが一致しない場合は無効化する。

    パスワード再設定時にDB側のsession_versionをインクリメントする(store.py
    set_password参照)ことで、再設定前に発行済みの署名付きセッションCookieを
    「盗まれていても」無効化できる（第2回監査 指摘#1）。ログイン時に
    session["session_version"]へ現在の値を保存しておき、リクエストの度に
    DB上の最新値と比較する。不一致（＝パスワード再設定後の古いCookie）なら
    セッションをその場でクリアし、未ログイン扱いにする。
    """
    if "_current_user_cache" not in g.__dict__:
        user_id = session.get("user_id")
        user = db.get_user(user_id) if user_id else None
        if user is not None and session.get("session_version") != user.session_version:
            session.pop("user_id", None)
            session.pop("session_version", None)
            user = None
        g._current_user_cache = user
    return g._current_user_cache


def _login_session_start(user: "store.User") -> None:
    """ログイン/サインアップ成功時に呼ぶ。session_versionもあわせて保存する。"""
    session["user_id"] = user.id
    session["session_version"] = user.session_version


def _current_org() -> dict | None:
    """ログイン中ユーザーが所属する組織(round8で追加)。未ログイン、または
    どの組織にも所属していない場合はNone。

    リクエストごとに何度も呼ばれる(_current_owner_key/_current_plan_name
    両方から)ため、`_current_user`と同様`g`にキャッシュしてリクエスト内で
    DBへの問い合わせを1回に抑える。
    """
    if "_current_org_cache" not in g.__dict__:
        user = _current_user()
        g._current_org_cache = db.get_org_for_user(user.id) if user else None
    return g._current_org_cache


def _current_owner_key() -> str:
    """生成物の所有権キー。組織に所属するユーザーは`org:<org_id>`を返す。

    これにより、同じ組織のメンバーは互いの生成履歴・利用回数プールを
    共有する(README「組織アカウント」の節、store.pyの該当コメント参照。
    複数人のチームで顧客の型紙を共同管理するという実務ニーズに応える
    ための意図的な設計)。
    """
    org = _current_org()
    if org:
        return f"org:{org['id']}"
    user = _current_user()
    if user:
        return f"user:{user.id}"
    return f"anon:{_get_or_create_visitor_id()}"


def _current_plan_name() -> str:
    """組織に所属するユーザーは組織のプランに従う(個人のplan列は無視する)。"""
    org = _current_org()
    if org:
        return org["plan"]
    user = _current_user()
    return user.plan if user else "anon"


def _daily_limit_for_plan(plan_name: str) -> int | None:
    return store.DEFAULT_DAILY_LIMITS.get(plan_name, store.DEFAULT_DAILY_LIMITS["free"])


_PLAN_DISPLAY_NAMES = {"anon": "未ログイン", "free": "Free", "pro": "Pro"}


def _plan_display_name(plan_name: str) -> str:
    return _PLAN_DISPLAY_NAMES.get(plan_name, plan_name)


def _login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not _current_user():
            # 実際にPlaywright経由の本物のブラウザで、無関係な別オリジンの
            # ページから、ログイン中の利用者のブラウザでこのデコレータ付きの
            # POSTエンドポイント(例:/account/profiles/<id>/delete)へ
            # 自動送信フォームを送るCSRFを実行して見つかった実バグ(修正済み)。
            #
            # SESSION_COOKIE_SAMESITE=Lax(上記コメント参照)により、この
            # クロスサイトPOSTには本物のセッションCookieが付与されず、この
            # if分岐に落ちて保護対象の操作自体は実行されない(実際に
            # プロフィールが削除されていないことをDBで確認済み)。しかし、
            # 以前はここで`flash()`を呼んでいたため、Cookie無しの真新しい
            # 匿名セッションが作られ、そこにフラッシュメッセージが書き込まれて
            # 「変更あり」になり、302応答に新しいSet-Cookieが付与されて
            # いた。ブラウザは(Cookieを送る/送らないの制限とは別に)この
            # Set-Cookieを同一オリジンからの応答として素直に受け取って
            # 保存するため、たとえ本来のログイン済みセッションCookieが
            # ブラウザ側にまだ残っていても、同じCookie名(session)で
            # 上書きされてしまい、利用者が何もしていないのに強制的に
            # ログアウトさせられる(実際にPlaywrightでCookie値の変化を
            # 追跡して確認した)。
            #
            # 対処として、ここでは`flash()`(=session書き込み)を使わず、
            # クエリ文字列でログイン画面に理由を伝える。これでこの
            # リダイレクト応答はセッションを一切変更せずSet-Cookieヘッダーを
            # 出さないため、ブラウザ側の既存Cookie(ログイン済みでも未ログイン
            # でも)をこの分岐が壊すことはなくなる。
            return redirect(url_for("login", login_required="1"))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def _inject_template_globals():
    return {
        "current_user": _current_user(),
        "current_year": time.strftime("%Y", time.gmtime()),
        "csrf_token": _get_or_create_csrf_token(),
        # `_csrf_protect`からのリダイレクトの目印(session書き込みを避けて
        # いるため、`show_login_required_notice`と同じクエリ文字列方式)。
        "show_csrf_error_notice": request.args.get("csrf_error") == "1",
    }


# ---------------------------------------------------------------------------
# 生成物・ジョブレコードのバックグラウンド掃除
# ---------------------------------------------------------------------------

_cleanup_lock = Lock()
_last_cleanup_at = 0.0
_CLEANUP_MIN_INTERVAL_SECONDS = 60.0


def _cleanup_old_outputs(max_age_seconds: int = OUTPUT_TTL_SECONDS) -> None:
    """generated/ 内の古いSVG/PDF/DXF/ZIPと、jobsテーブルの古い行を削除する。

    round5でDXF(.dxf、単体ジョブ)とZIP(.zip、複数サイズ一括生成の束ね
    ファイル)を`generated/`に書き出すようになったが、この掃除処理の対象
    拡張子リストに追加するのを忘れており、実際に`export_pattern`/
    `export_multi_size_bundle`が書き出したファイルが1時間経っても一切
    削除されずに残り続ける実バグがあった(生成のたびにディスク使用量が
    増え続ける)。追記して修正。
    """
    now = time.time()
    try:
        for name in os.listdir(OUTPUT_DIR):
            if not name.endswith((".svg", ".pdf", ".dxf", ".zip")):
                continue
            path = os.path.join(OUTPUT_DIR, name)
            try:
                if now - os.path.getmtime(path) > max_age_seconds:
                    os.remove(path)
            except OSError:
                pass  # 他プロセスが同時に消していた等は無視して良い
    except OSError:
        pass  # OUTPUT_DIRが読めない状況でもリクエスト処理自体は継続する
    try:
        db.delete_jobs_older_than(now - max_age_seconds)
    except Exception:  # pragma: no cover - DB掃除の失敗でリクエスト処理を止めない
        app.logger.exception("job cleanup failed")
    try:
        # レート制限(round6でSQLite共有化、_RateLimiter参照)のヒット記録も
        # 同じ掃除サイクルでまとめて古い行を削除する。全バケット中最も長い
        # ウィンドウ幅(現状60秒)より十分大きいmax_age_secondsを使っている
        # ため、アクティブに使われていないバケット/キーの行も取りこぼさない。
        db.delete_rate_limit_hits_older_than(now - max_age_seconds)
    except Exception:  # pragma: no cover - DB掃除の失敗でリクエスト処理を止めない
        app.logger.exception("rate limit hit cleanup failed")
    try:
        # アカウント単位のログイン失敗記録(round7で追加、store.check_account_lockout
        # 参照)も同じ掃除サイクルでまとめて古い行を削除する。
        # ACCOUNT_LOCKOUT_WINDOW_SECONDS(15分)より十分大きいmax_age_secondsを
        # 使っているため、二度とログインを試みないメールアドレスの行も
        # 取りこぼさない。
        db.delete_login_failures_older_than(now - max_age_seconds)
    except Exception:  # pragma: no cover - DB掃除の失敗でリクエスト処理を止めない
        app.logger.exception("login failure record cleanup failed")


def _cleanup_old_outputs_throttled() -> None:
    """掃除を毎リクエストではなく最短間隔を空けて、バックグラウンドで実行する。

    以前は _cleanup_old_outputs() を毎リクエストの先頭で同期的に呼んでいた。
    generated/ に溜まるファイルが増えるほど os.listdir + 各ファイルの
    os.path.getmtime が線形に増え、複数ワーカーが同じディレクトリに対して
    重複した掃除処理を行うことになる。ここでは(a)前回実行から
    _CLEANUP_MIN_INTERVAL_SECONDS以内なら何もしない、(b)実行する場合も
    レスポンスを止めないようバックグラウンドスレッドに投げる、の2点で
    リクエストのレイテンシから掃除コストを切り離している。
    """
    global _last_cleanup_at
    now = time.time()
    with _cleanup_lock:
        if now - _last_cleanup_at < _CLEANUP_MIN_INTERVAL_SECONDS:
            return
        _last_cleanup_at = now
    Thread(target=_cleanup_old_outputs, daemon=True).start()


class _RateLimiter:
    """スライディングウィンドウ方式のレート制限。実体はSQLite(store.py)で、
    複数ワーカー/複数プロセス構成でも共有される(round6で実装)。

    以前はプロセス内メモリ(dequeベース)のみで動いており、複数ワーカー
    (`gunicorn -w N`等)構成では各ワーカーが別々にカウントするため、実際の
    上限が実質N倍緩んでいた。プランごとの1日あたり利用回数上限は既に
    store.pyのSQLiteで複数ワーカー間で共有されていたのに、より短い時間窓の
    こちらのレート制限だけ取り残されていたのは一貫性を欠くと判断し、
    `db.check_rate_limit()`(`check_and_increment_usage()`と同じ
    `BEGIN IMMEDIATE`直列化パターン)に置き換えた。

    `db`はこのモジュールのグローバル変数を実行時に参照する(テストで
    `monkeypatch.setattr(app_module, "db", ...)`により差し替えられた場合も
    追従するようにするため、コンストラクタでの束縛はしない)。
    """

    def __init__(self, bucket: str, max_requests: int, window_seconds: float):
        self.bucket = bucket
        self.max_requests = max_requests
        self.window_seconds = window_seconds

    def allow(self, key: str) -> bool:
        return db.check_rate_limit(self.bucket, key, self.max_requests, self.window_seconds)


_generate_rate_limiter = _RateLimiter("generate", max_requests=20, window_seconds=60.0)
# ダウンロードは生成直後にプレビュー表示・SVG/PDFの取得で複数回叩かれるのが
# 正常系なので、生成本体より緩めの上限にする（不特定多数からの連打防止が目的）。
_download_rate_limiter = _RateLimiter("download", max_requests=90, window_seconds=60.0)
# メール送信系(確認メール再送・パスワード再設定)専用のIPベースレート制限。
# 第2回監査で「これらのエンドポイントに何の制限も無く、他人のメール
# アドレスへの迷惑メール爆撃に悪用できる」と指摘された(指摘#3)。
_email_send_rate_limiter = _RateLimiter("email_send", max_requests=5, window_seconds=60.0)
# ログイン試行専用のIPベースレート制限。
#
# 実際にサーバを起動し、同一アカウント宛に間違ったパスワードで60回連続
# ログインを試したところ、全て400（通常の認証失敗）としてそのまま処理され、
# 429やロックアウトが一切発生しないことを確認した（総当たり攻撃が無制限に
# 可能な状態だった）。/api/generate等の他エンドポイントには既にIPベースの
# レート制限があるのに、/loginにだけ無かったのは見落としと判断し、他の
# 限定と同じ`_RateLimiter`パターンで追加する。
#
# 正直な限界: 他のIPベース制限と同様、単一IPを前提にした安全弁であり(round6
# でプロセス間の共有には対応したが)、IPをローテーションする分散的な
# パスワードスプレー攻撃までは防げない。特定アカウントを狙った本格的な
# 総当たり対策としては、将来的にアカウント単位の失敗回数カウント(CAPTCHA
# 表示や段階的な遅延)への拡張を検討する必要がある。
_login_rate_limiter = _RateLimiter("login", max_requests=10, window_seconds=60.0)
# IPベースの制限だけでは、IPをローテーションする分散的な迷惑メール送信
# （同一の被害者アドレスを狙い撃ちにするケース)を防げないため、
# ユーザー単位・目的単位でのクールダウンもDB側で強制する(store.py参照)。
_EMAIL_TOKEN_COOLDOWN_SECONDS = 60

# /forgot-password の応答時間を一定以上に揃えるための下限(秒)。
#
# 実際にaiosmtpdでローカルSMTPシンクを立て、PATTERNFORGE_MAIL_BACKEND=smtp
# (本番で推奨している構成)で実際にサーバを起動して計測したところ、実在する
# メールアドレスへのリクエストは実際にメール送信を行う分平均約20ms、実在
# しないメールアドレスの場合はメール送信処理自体をスキップするため平均約
# 10msと、応答時間に約2倍の差があることを確認した(ConsoleMailerの既定
# 構成でも約1.5msの差が実測された)。実際のSMTPプロバイダ(Gmail/SES等)を
# 使う本番構成では、TLSハンドシェイク・認証を含む本物のネットワーク往復が
# 発生するため、この差はさらに大きくなる(数百ms単位になりうる)。これは
# ログイン応答時間の件(store.pyのauthenticate()参照)と同種の、実際に
# 悪用可能なタイミングサイドチャネルだった。表示文言は既に「常に同じ」に
# 揃えてあった(既存コメント参照)が、応答時間までは揃っていなかった。
#
# 対策として、リクエスト全体の処理時間がこの下限を下回っていた場合は
# 残り時間分だけ待ってから応答する(どちらの分岐でも下限以上の一定時間を
# 必ずかける)。パスワード認証のダミーハッシュ検証(store.py参照)と違い、
# メール送信のネットワーク往復時間そのものを事前に予測してCPU側だけで
# 再現することはできないため、この「下限まで待つ」方式を採用している。
# 正直な限界として、実際のSMTP送信がこの下限を超えて掛かった場合は、
# その回だけ応答時間差が残ってしまう(下限値は環境に応じて調整すること)。
# テストではPATTERNFORGE_FORGOT_PASSWORD_MIN_SECONDS=0相当に短縮している
# (conftest.py参照)。
_FORGOT_PASSWORD_MIN_RESPONSE_SECONDS = float(
    os.environ.get("PATTERNFORGE_FORGOT_PASSWORD_MIN_SECONDS", "0.3")
)


def _pad_to_min_response_time(start_time: float) -> None:
    remaining = _FORGOT_PASSWORD_MIN_RESPONSE_SECONDS - (time.time() - start_time)
    if remaining > 0:
        time.sleep(remaining)


#: 初期表示で選ばれているパーツ構成(round32)。
#:
#: 【なぜ必要か】選択肢は`sorted(NECKLINES)`のように**内部識別子の
#: アルファベット順**で並べていて、`selected`をどれにも付けていなかった。
#: その結果、初めて開いた人が何も触らずに生成すると
#: 「ボートネック + ベル袖 + サーキュラースカート」という、かなり凝った
#: 組み合わせの型紙が出ていた(実際にブラウザで開いて発見)。既定は
#: 「どれを選べばいいか分からない人が押しても素直な物が出る」形——
#: 原型に最も近い基本形にする。
DEFAULT_NECKLINE = "round_neck"
DEFAULT_SLEEVE_STYLE = "straight"
DEFAULT_SKIRT_STYLE = "flare"


@app.get("/")
def index():
    plan_name = _current_plan_name()
    limit = _daily_limit_for_plan(plan_name)
    used = db.usage_today(_current_owner_key(), _today_str())
    user = _current_user()
    profiles = db.list_measurement_profiles(user.id) if user else []
    return render_template(
        "index.html",
        necklines=sorted(NECKLINES),
        sleeve_styles=sorted(SLEEVE_STYLES),
        skirt_styles=sorted(SKIRT_STYLES),
        # round34: 採寸図の説明文(engine/measure_guide.py が唯一の出どころ)。
        # CSPで inline script が使えないので、data-*属性でJSへ渡す。
        measure_guides_json=json.dumps(guides_as_dict(), ensure_ascii=False),
        default_neckline=DEFAULT_NECKLINE,
        default_sleeve_style=DEFAULT_SLEEVE_STYLE,
        default_skirt_style=DEFAULT_SKIRT_STYLE,
        collar_styles=sorted(s for s in COLLAR_STYLES if s),
        cuffs_styles=sorted(s for s in CUFFS_STYLES if s),
        pants_styles=sorted(s for s in PANTS_STYLES if s),
        waistband_styles=sorted(s for s in WAISTBAND_STYLES if s),
        # round24: ゆとり(着方)の選択肢。engine側の定義をそのまま渡すので、
        # プリセットを足したときに画面側の書き換えが要らない。
        # round42: 原型ごとに標準ゆとりが違うので、絶対値(8.0cm)だけでは
        # 画面の表示が嘘になる(子ども原型の標準はバスト/4)。標準からの
        # 増減も一緒に渡し、原型を切り替えたら表示を書き換える。
        fit_presets=[(key, preset.label, preset.bodice_cm,
                       preset.bodice_cm - FIT_PRESETS[DEFAULT_FIT].bodice_cm)
                     for key, preset in FIT_PRESETS.items()],
        default_fit=DEFAULT_FIT,
        standard_sizes=list(STANDARD_SIZE_ORDER),
        # round42: 原型(大人(女性)/子ども)の選択肢。engine側の定義を
        # そのまま渡すので、原型を足したときに画面側の書き換えが要らない。
        blocks=[{"key": b.key, "label": b.label,
                  "height_lo": b.height_range_cm[0], "height_hi": b.height_range_cm[1],
                  "source_name": b.source_name, "source_url": b.source_url,
                  "ease_text": b.standard_ease.text()}
                 for b in BLOCKS.values()],
        default_block=DEFAULT_BLOCK_KEY,
        # round44: 採寸欄に min/max を入れて、単位・桁の間違いを**送信する前**に
        # ブラウザが捕まえられるようにする。数値はエンジンの`_VALID_RANGES`から
        # そのまま渡す(画面に書き写すと、範囲を動かしたときに食い違う)。
        # round52: 丈の指定欄の範囲。画面とエンジンで別々の数字を持たない。
        # `20.0`ではなく`20`と出す。同じ範囲をエラー文でも`:g`で
        # 書いている(_parse_design_lengths)ので、画面と食い違わせない。
        design_length_range=[f"{value:g}" for value in SKIRT_LENGTH_RANGE_CM],
        # round54: 生地の割り当て欄。区分の一覧と既定の生地名は
        # engine/fabric_groups.py が持つ(画面に書き写すと食い違う)。
        fabric_areas=[{"key": area.key, "label": area.label}
                      for area in ASSIGNABLE_AREAS],
        default_fabric_name=DEFAULT_FABRIC_NAME,
        max_fabric_groups=MAX_FABRIC_GROUPS,
        costume_project_choices=costume_project_choices(),
        # round52: 縫い代の範囲も同じ理由で渡す(画面に0.3/3.0と書き写して
        # あったので、0を通せるようにしたときに片方だけ古くなりかけた)。
        seam_allowance_range=[f"{SEAM_ALLOWANCE_NONE_CM:g}",
                              f"{MIN_SEAM_ALLOWANCE_CM:g}",
                              f"{MAX_SEAM_ALLOWANCE_CM:g}"],
        hem_seam_allowance_range=[f"{MIN_HEM_SEAM_ALLOWANCE_CM:g}",
                                  f"{MAX_HEM_SEAM_ALLOWANCE_CM:g}"],
        measurement_ranges={name: list(MEASUREMENT_RANGES[name])
                             for name in ("bust", "waist", "hip", "height",
                                           "sleeve_length", "shoulder_width",
                                           "upper_arm", "bust_point_spacing",
                                           "bust_point_drop",
                                           "head_circumference")},
        mens_block_absent_note=MENS_BLOCK_ABSENT_NOTE,
        # round40: 補正の項目(測り方・正負の意味・出典)をそのまま画面へ。
        alteration_kinds=[k.as_dict() for k in ALTERATION_KINDS],
        max_alteration_cm=MAX_ALTERATION_CM,
        # round21: 前後あわせた上限をヒント文に出すため(前後で別の入力欄に
        # なったので、片方だけの上限だと利用者が誤解する)。
        max_illustration_images=MAX_ILLUSTRATION_IMAGES,
        usage={"plan": plan_name, "used_today": used, "daily_limit": limit},
        profiles=profiles,
        # round9で追加: AIパーツ判定ログ表(app.js)がラベル辞書を参照できる
        # よう、data-*属性経由でJSONを渡す(labels.pyのdocstring参照。
        # CSPのscript-src 'self'によりインラインscriptでは渡せないため)。
        variation_labels_json=json.dumps(labels.VARIATION_LABELS_JA, ensure_ascii=False),
        part_type_labels_json=json.dumps(labels.PART_TYPE_LABELS_JA, ensure_ascii=False),
    )


@app.get("/healthz")
def healthz():
    """動作確認用。

    実際にpatternforge.dbのファイルを壊れた内容(SQLiteヘッダを持たない
    テキスト)に置き換えた状態でサーバーを起動して確認した実バグの修正:
    以前はDBに一切触れず常に200 {"ok": true}を返していたため、DBが壊れて
    signup/login等の中核機能が実際には500エラーになっている状況でも、
    ロードバランサ/オーケストレータのヘルスチェックだけは「正常」と判定
    し続け、障害に気付けない・トラフィックを振り分け続けてしまう監視上の
    盲点があった(store.Store.ping()参照)。DBへの軽い到達確認を行い、
    失敗時は503を返す。プロセス自体は生きているが依存先が壊れている状態を
    正しく「異常」として報告できるようにした。
    """
    try:
        db.ping()
    except Exception:
        app.logger.exception("healthz: database ping failed")
        return jsonify({"ok": False, "error": "database unavailable"}), 503
    return jsonify({"ok": True})


@app.get("/favicon.ico")
def favicon():
    # 実際にブラウザで動かして見つけた不具合の修正: ブラウザは各テンプレートの
    # <link rel="icon"> の有無に関係なく、サイトルートの /favicon.ico を毎回
    # 自動的にリクエストする。これまでファイルが無く全ページで404が発生していた
    # （タブにもアイコンが表示されず、コンソールにもエラーが出る）。
    # web/static/favicon.ico を返すことで解消する。
    return send_from_directory(
        os.path.join(BASE_DIR, "web", "static"), "favicon.ico",
        mimetype="image/vnd.microsoft.icon",
    )


# 一般公開する実サービスとしてテストして見つかった不備の修正: robots.txt/
# sitemap.xmlが存在せず、検索エンジンのクローラが巡回時に404を受け取っていた。
# ログイン必須のマイページ・ダウンロード・パスワード再設定等は検索結果に出す
# 意味がないどころか、トークン付きURLが漏れる懸念もあるため明示的に除外し、
# 公開してよいマーケティング系のページだけをサイトマップに列挙する。
_PUBLIC_SITEMAP_ENDPOINTS = (
    "index", "guide", "pricing", "signup", "login", "terms", "privacy", "legal_notice",
)


@app.get("/robots.txt")
def robots_txt():
    lines = [
        "User-agent: *",
        "Disallow: /account",
        "Disallow: /api/",
        "Disallow: /download/",
        "Disallow: /verify/",
        "Disallow: /reset-password/",
        "Disallow: /forgot-password",
        f"Sitemap: {url_for('sitemap_xml', _external=True)}",
        "",
    ]
    return Response("\n".join(lines), mimetype="text/plain")


@app.get("/sitemap.xml")
def sitemap_xml():
    urls = "".join(
        f"<url><loc>{url_for(endpoint, _external=True)}</loc></url>"
        for endpoint in _PUBLIC_SITEMAP_ENDPOINTS
    )
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + urls + "</urlset>"
    )
    return Response(xml, mimetype="application/xml")


def _parse_measurements(form) -> Measurements:
    fields = ("bust", "waist", "hip", "height", "sleeve_length", "shoulder_width")
    try:
        values = {name: float(form[name]) for name in fields}
    except KeyError as exc:
        raise ValueError(f"採寸項目が不足しています: {exc}") from exc
    except (TypeError, ValueError) as exc:
        raise ValueError(f"採寸値は数値で入力してください: {exc}") from exc
    # round25: 二の腕まわりは任意項目。空欄なら未指定のまま
    # (指定すると袖幅がこの実測から決まる)。
    raw_arm = (form.get("upper_arm") or "").strip()
    if raw_arm:
        try:
            values["upper_arm"] = float(raw_arm)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"二の腕まわりは数値で入力してください: {exc}") from exc
    # round29: 乳間(左右の乳頭の間隔)と乳下がり(前中央で首の付け根から
    # BPまで)も任意項目。指定するとBPの位置がその実測で決まり、胸ぐせ
    # ダーツと前身頃のウエストダーツがそこへ向く。空欄なら新文化式の
    # 推定式へ戻る(engine/bodice_fit.py参照)。
    # round75: 頭囲も任意項目。指定するとフードの大きさがその実測で決まる
    # (engine/hood.py)。空欄なら成人女性の平均57cmで引き、**その旨を
    # 利用者へ開示する**。
    for name, label in (("bust_point_spacing", "乳間"),
                        ("bust_point_drop", "乳下がり"),
                        ("head_circumference", "頭囲")):
        raw = (form.get(name) or "").strip()
        if not raw:
            continue
        try:
            values[name] = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{label}は数値で入力してください: {exc}") from exc
    return Measurements(**values)


def _parse_fit(form, measurements=None):
    """フォームからゆとりの指定を読む(round25)。

    プリセット名をそのまま返すのが基本で、"custom" が選ばれた場合だけ
    数値入力から`FitEase`を組み立てる。未知の値・範囲外の値は
    engine側(`fit_ease`/`custom_fit_ease`)が明確なエラーにする。

    round30で "stretch"(伸びる生地)を追加した。こちらは縮小率が**割合**
    なので、部位ごとのcmを出すのに採寸値が要る(`measurements`)。
    """
    fit = (form.get("fit") or DEFAULT_FIT).strip()
    if fit == "stretch":
        if measurements is None:
            raise ValueError("伸びる生地のゆとりを求めるには採寸値が必要です。")
        raw = (form.get("stretch_percent") or "").strip()
        if not raw:
            raise ValueError(
                "伸びる生地を選んだ場合は、生地の伸縮率(%)を入力してください。"
                "10cm四方に切った生地を無理なく伸びるところまで引っぱり、"
                "15cmになれば50%です。")
        raw_cling = (form.get("stretch_cling") or "").strip()
        try:
            percent = float(raw)
            cling = float(raw_cling) if raw_cling else 1.0
        except (TypeError, ValueError) as exc:
            raise ValueError(f"伸縮率・密着度は数値で入力してください: {exc}") from exc
        return stretch_fit_ease(measurements.bust, measurements.waist,
                                 measurements.hip, percent, cling,
                                 measurements.upper_arm)
    if fit != "custom":
        return fit
    values = {}
    for field, name in (("ease_bodice", "bodice_cm"), ("ease_waist", "waist_cm"),
                         ("ease_hip", "hip_cm"), ("ease_sleeve", "sleeve_cm")):
        raw = (form.get(field) or "").strip()
        if not raw:
            continue
        try:
            values[name] = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"ゆとりは数値で入力してください: {exc}") from exc
    return custom_fit_ease(**values)


def _download_links(result) -> dict[str, str]:
    """生成結果に**実際に存在する**出力だけのダウンロードリンクを返す(round41)。

    round40まではリンクの一覧を呼び出し側4か所にそのまま書き並べていた。
    形式が増えるたびに4か所を直す必要があり、実際に1か所では
    `"projector"`が二重に書かれていた(dictの重複キーなので例外にならず、
    値が同じだったため気付かれずに残っていた)。

    `result.output_files`の鍵をそのまま使うので、裏地を付けない生成では
    裏地のリンクが出ない——「押したら404」というリンクを出さないため。
    """
    return {fmt: f"/download/{result.job_id}/{fmt}"
            for fmt in result.output_files if fmt in _DOWNLOAD_FORMATS}


def _bool_field(form, name: str) -> bool:
    return form.get(name) in ("on", "true", "1", "True")


MAX_PROJECT_NAME_LENGTH = 80


def _parse_project_name(form) -> str | None:
    """生成結果と履歴を見分けるための任意名を検証する。"""
    value = unicodedata.normalize("NFKC", str(form.get("project_name", ""))).strip()
    if not value:
        return None
    if len(value) > MAX_PROJECT_NAME_LENGTH:
        raise ValueError(f"プロジェクト名は{MAX_PROJECT_NAME_LENGTH}文字以内で入力してください。")
    if any(unicodedata.category(char) in {"Cc", "Cs"} for char in value):
        raise ValueError("プロジェクト名に制御文字は使用できません。")
    return value


def _bool_field_default(form, name: str, default: bool) -> bool:
    """`_bool_field`と違い、フィールドが送られていない場合はdefaultを返す。

    round10で追加したinclude_body_garment(本体パーツを含めるかどうか)用。
    通常のチェックボックス(`_bool_field`)は「未送信=false」という
    HTMLの標準挙動を前提にしているが、こちらは「未指定なら従来通りTrue
    (本体パーツを含める)」という、既定値がTrue側にある設定のため別関数にした。
    """
    raw = form.get(name)
    if raw is None:
        return default
    return raw in ("on", "true", "1", "True")


# round5で追加した「縫い代を辺ごとに設定可能に」のUI側の許容範囲。
# 下限は「縫い代が細すぎてミシンで扱えない」実用上の目安、上限は
# 「入力ミスで桁を間違えた極端な値を弾く」ための緩い上限であり、
# 縫製上の"正しい"縫い代幅を規定するものではない。
#
# 【round52で訂正】この下限は**縫う前提の根拠**である。ところがこの製品は
# 「マント・翼・EVAフォーム装甲プレート」を名指しで勧めていて、フォームや
# 樹脂板は**縫わずに線の上で切る**。エンジンは`seam_allowance_cm=0.0`を
# 正しく扱う(実測: 30×40cmの板が裁断線30.0×40.0cmで出る)のに、
# 画面とAPIだけが0を弾いていた——しかもカスタムパーツの注意書きが
# 「縫い代の設定を0にしてください」と案内していた。**0だけは特例で通す**。
# 0と下限の間(0.1cmなど)は従来どおり弾く: それは「縫うつもりで細すぎる値を
# 入れた」入力ミスであって、「縫わない」という意思表示ではない。
SEAM_ALLOWANCE_NONE_CM = 0.0
MIN_SEAM_ALLOWANCE_CM = 0.3
MAX_SEAM_ALLOWANCE_CM = 3.0
MIN_HEM_SEAM_ALLOWANCE_CM = 0.3
MAX_HEM_SEAM_ALLOWANCE_CM = 8.0


#: 柄の縦のリピート幅として受け付ける範囲(cm)。
#: 下限は「柄合わせをする意味がある最小の柄」、上限は生地幅を超えない範囲。
MIN_PATTERN_REPEAT_CM = 0.5
MAX_PATTERN_REPEAT_CM = 150.0

#: 生地の収縮率(%)として受け付ける範囲。
#: うさこの洋裁工房が挙げる実例(1mが4.5cm=4.5%縮んだ)より広く取り、
#: それでも「半分に縮む生地」のような非現実的な値は弾く。
#: https://yousai.net/how_to/kiso/jinaosi
MIN_SHRINK_PERCENT = 0.0
MAX_SHRINK_PERCENT = 20.0


#: 手持ちの生地として受け付ける範囲(cm)。
#: 幅の下限は帯状パーツが載る最小限、上限は流通している最大幅(ダブル幅)。
MIN_STASH_WIDTH_CM = 30.0
MAX_STASH_WIDTH_CM = 300.0
MAX_STASH_LENGTH_CM = 3000.0


def _parse_alteration_fields(form) -> dict[str, float]:
    """round40: 着てみて合わなかったときの補正量を読む。

    フォームの名前は `alter_<key>`。空欄は「補正しない」。数値でなければ
    エラーにする——黙って0にすると、入力したのに効かない状態になる。
    """
    values: dict[str, float] = {}
    for kind in ALTERATION_KINDS:
        raw = (form.get(f"alter_{kind.key}") or "").strip()
        if not raw:
            continue
        try:
            values[kind.key] = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"「{kind.label}」の補正は数値で入力してください: {raw!r}") from exc
    # 範囲の検算はengine側(validate)が持つ。二重に持つと食い違う。
    return validate_alterations(values)


def _parse_stash_per_fabric(form) -> dict[str, tuple[float, float]]:
    """生地ごとの手持ち寸法を読む(round57で追加)。

    round55で手持ち生地の判定を生地ごとに答えるようにしたが、**寸法は
    1枚ぶんしか受け取れなかった**——「白を2m、紺を1m持っている」という
    ふつうの状態を、同じ1枚の寸法を全部の生地に当てて答えていた。

    画面は⑨で入力した生地の名前ごとに1行を出す(app.jsが作る)。
    ここでは名前・幅・長さの3つの並びを突き合わせて読む。
    行が空(幅も長さも未入力)なら、その生地は既定の1枚の寸法で判定する。
    """
    names = form.getlist("stash_fabric_name")
    widths = form.getlist("stash_fabric_width_cm")
    lengths = form.getlist("stash_fabric_length_cm")
    out: dict[str, tuple[float, float]] = {}
    for index, name in enumerate(names):
        name = " ".join(str(name).split())
        raw_width = (widths[index] if index < len(widths) else "").strip()
        raw_length = (lengths[index] if index < len(lengths) else "").strip()
        if not name or (not raw_width and not raw_length):
            continue
        if not raw_width or not raw_length:
            raise ValueError(
                f"「{name}」の手持ちを調べるには、幅と長さの両方を入力してください。")
        try:
            width, length = float(raw_width), float(raw_length)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"「{name}」の手持ちの寸法は数値で入力してください: {exc}") from exc
        if not (MIN_STASH_WIDTH_CM <= width <= MAX_STASH_WIDTH_CM):
            raise ValueError(
                f"「{name}」の幅は{MIN_STASH_WIDTH_CM:g}〜{MAX_STASH_WIDTH_CM:g}cmの"
                f"範囲で指定してください: {width:g}cm")
        if not (STASH_MIN_LENGTH_CM <= length <= MAX_STASH_LENGTH_CM):
            raise ValueError(
                f"「{name}」の長さは{STASH_MIN_LENGTH_CM:g}〜{MAX_STASH_LENGTH_CM:g}cmの"
                f"範囲で指定してください: {length:g}cm")
        out[name] = (width, length)
    return out


def _parse_stash_fields(form) -> tuple[float, float] | None:
    """round39: 手持ちの生地の寸法を読む。両方入っているときだけ判定する。

    片方だけでは判定できない(幅だけ分かっても、足りるかは言えない)ので、
    片方だけ入っていたらエラーにする——黙って無視すると、利用者は
    「入力したのに何も出ない」ことになる。
    """
    raw_width = (form.get("stash_width_cm") or "").strip()
    raw_length = (form.get("stash_length_cm") or "").strip()
    if not raw_width and not raw_length:
        return None
    if not raw_width or not raw_length:
        raise ValueError(
            "手持ちの生地で足りるか調べるには、幅と長さの両方を入力してください。")
    try:
        width = float(raw_width)
        length = float(raw_length)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"手持ちの生地の寸法は数値で入力してください: {exc}") from exc
    if not (MIN_STASH_WIDTH_CM <= width <= MAX_STASH_WIDTH_CM):
        raise ValueError(
            f"手持ちの生地の幅は{MIN_STASH_WIDTH_CM:g}〜{MAX_STASH_WIDTH_CM:g}cmの"
            f"範囲で指定してください: {width:g}cm")
    if not (STASH_MIN_LENGTH_CM <= length <= MAX_STASH_LENGTH_CM):
        raise ValueError(
            f"手持ちの生地の長さは{STASH_MIN_LENGTH_CM:g}〜{MAX_STASH_LENGTH_CM:g}cmの"
            f"範囲で指定してください: {length:g}cm")
    return width, length


#: 「中に着る服の出来上がりバスト」として受け付ける範囲(cm)。
#: 下限は素体のバストの下限、上限は重ね着を何枚重ねても届かない値。
MIN_WORN_OVER_BUST_CM = 50.0
MAX_WORN_OVER_BUST_CM = 200.0


def _parse_worn_over_bust_cm(form) -> float | None:
    """round74: 「この服は、出来上がりバスト◯cmの服の上に羽織る」を読む。

    未入力ならNone(=従来どおり素体を基準にゆとりを取る)。
    数値でない・範囲外はエラーにする——黙って無視すると、重ね着の指定が
    効かないまま「中の服と同じ太さのコート」が出てくる。
    """
    raw = (form.get("worn_over_bust_cm") or "").strip()
    if not raw:
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"中に着る服の出来上がりバストは数値で入力してください: {raw!r}") from exc
    if not (MIN_WORN_OVER_BUST_CM <= value <= MAX_WORN_OVER_BUST_CM):
        raise ValueError(
            f"中に着る服の出来上がりバストは{MIN_WORN_OVER_BUST_CM:g}〜"
            f"{MAX_WORN_OVER_BUST_CM:g}cmの範囲で指定してください: {value:g}")
    return value


#: 肩先を出せる量(cm)として受け付ける範囲。上限は`engine/drop_shoulder.py`の
#: `too_large_drop_reason`が採寸ごとに更に絞る(肩幅の半分まで)。
MIN_SHOULDER_DROP_CM = 0.5
MAX_SHOULDER_DROP_CM = 20.0


def _parse_shoulder_drop_cm(form) -> float | None:
    """round76: 「肩先を◯cm外へ出す」(ドロップショルダー)を読む。

    未入力ならNone(=従来どおり肩先は肩幅の半分の位置)。数値でない・
    範囲外はエラーにする——黙って無視すると、ドロップを指定したのに
    セットインスリーブの型紙が出てくる。
    """
    raw = (form.get("shoulder_drop_cm") or "").strip()
    if not raw:
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"肩先を出す量は数値で入力してください: {raw!r}") from exc
    if not (MIN_SHOULDER_DROP_CM <= value <= MAX_SHOULDER_DROP_CM):
        raise ValueError(
            f"肩先を出す量は{MIN_SHOULDER_DROP_CM:g}〜{MAX_SHOULDER_DROP_CM:g}cmの"
            f"範囲で指定してください: {value:g}")
    return value


def _parse_fabric_shopping_fields(form) -> tuple[bool, float | None, float | None]:
    """round38: 買い物メモのための任意入力を読む。

    `one_way_fabric`(一方方向の生地か)、`shrink_percent`(生地の収縮率)、
    `pattern_repeat_cm`(柄の縦のリピート幅)。どれも任意で、
    未入力なら None(=既定の見積もり)を返す。
    """
    one_way = _bool_field(form, "one_way_fabric")

    def _optional_number(field_name: str, label: str,
                          lo: float, hi: float) -> float | None:
        raw = (form.get(field_name) or "").strip()
        if not raw:
            return None
        try:
            value = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{label}は数値で入力してください: {raw!r}") from exc
        if not (lo <= value <= hi):
            raise ValueError(
                f"{label}は{lo:g}〜{hi:g}の範囲で指定してください: {value:g}")
        return value

    shrink = _optional_number("shrink_percent", "生地の収縮率(%)",
                               MIN_SHRINK_PERCENT, MAX_SHRINK_PERCENT)
    repeat = _optional_number("pattern_repeat_cm", "柄のリピート幅(cm)",
                               MIN_PATTERN_REPEAT_CM, MAX_PATTERN_REPEAT_CM)
    return one_way, shrink, repeat


#: 丈を直接指定できるパーツと、画面に出す名前 (round52で追加)。
#: `engine.pipeline` の `design_lengths` は part_type をキーにしており、
#: round39から`engine/stash.py`が「手持ちの生地に収まるまでスカートを詰める」
#: ために使っている——**仕組みは動いているのに、利用者からは触れなかった**。
DESIGN_LENGTH_FIELDS = (
    ("skirt", "スカート丈"),
    ("front_pants", "パンツ丈"),
    # round57: 袖丈・着丈。round52では「袖ぐりと連動するので同じやり方では
    # 縫い合わせ長さが崩れる」として見送っていたが、テンプレートが
    # `data-fit-y`("neck/underarm/hem"、袖は"cap/underarm/hem")を
    # 持っているので、**袖ぐりより下だけ**を伸縮させれば壊さずに当てられる
    # (engine/bodice_fit.py の apply_design_length_to_y_map)。
    ("sleeve", "袖丈"),
    ("front_bodice", "着丈"),
)

#: part_type から画面に出す名前を引く(round58)。
#: `DESIGN_LENGTH_FIELDS` と同じものを逆に引くだけで、新しい名前は
#: 増やさない——2か所に名前を書くと、片方だけ直す事故が起きる。
DESIGN_LENGTH_LABELS = dict(DESIGN_LENGTH_FIELDS)

#: 前後で対になっていて、片方の指定をもう片方にも及ぼすもの(round57)。
#: 片方だけ短いと脇線が合わず縫えない。
DESIGN_LENGTH_PAIRS = {
    "front_pants": "back_pants",
    "front_bodice": "back_bodice",
}


#: round55: 生成履歴に`fit`を保存するときの目印。
#:
#: `fit`はプリセット名(文字列)のこともあれば、「ゆとりを自分で入れる」
#: 「伸びる生地」で組み立てた`FitEase`(データクラス)のこともある。
#: 後者はそのままJSONにできないので、辞書に直して目印を付けて保存し、
#: 再生成で組み立て直す。
#: **これを忘れると`TypeError: Object of type FitEase is not JSON
#: serializable`で生成そのものが500になる**(round55に実際に踏み、
#: 既存のテストが捕まえた)。
_FIT_EASE_JSON_KEY = "__fit_ease__"


def _fit_to_json(fit):
    """`fit`をJSONにできる形にする(プリセット名はそのまま)。"""
    if isinstance(fit, FitEase):
        return {_FIT_EASE_JSON_KEY: dataclasses.asdict(fit)}
    return fit


def _fit_from_json(value):
    """`_fit_to_json`で保存したものを、元の形に戻す。"""
    if isinstance(value, dict) and _FIT_EASE_JSON_KEY in value:
        return FitEase(**value[_FIT_EASE_JSON_KEY])
    return value


def _restore_generation_kwargs(stored: dict) -> dict:
    """生成履歴から読んだ設定を、`generate_from_selection`へ渡せる形に戻す。"""
    restored = dict(stored)
    if "fit" in restored:
        restored["fit"] = _fit_from_json(restored["fit"])
    return restored


def _describe_restored_settings(kwargs: dict) -> str:
    """再生成で**何が復元されたか**を、日本語1行にする(round57)。

    round55で中身は合うようになったが、画面に出るのは「再生成しました」と
    リンクだけだった。利用者が確かめる手段は、出てきた型紙を見ることしか
    なかった——**設定が落ちていた頃と、画面の見え方が同じ**である。
    何を引き継いだのかを書けば、落ちていればその場で分かる。
    """
    parts: list[str] = []
    if kwargs.get("lining"):
        parts.append("裏地あり")
    fabrics = kwargs.get("fabric_group_assignments") or {}
    if fabrics:
        names = sorted(set(fabrics.values()))
        parts.append(f"生地{len(names) + 1}種類（{('・'.join(names))}を分けて裁つ）")
    lengths = kwargs.get("design_length_overrides") or {}
    for part_type, value in sorted(lengths.items()):
        if part_type.startswith("back_"):
            continue
        parts.append(f"{labels.PART_TYPE_LABELS_JA.get(part_type, part_type)}の丈{value:g}cm")
    alterations = kwargs.get("alterations") or {}
    if alterations:
        parts.append(f"補正{len(alterations)}項目")
    fit = kwargs.get("fit")
    if isinstance(fit, dict) or (fit and fit != DEFAULT_FIT):
        parts.append("ゆとりの指定")
    if kwargs.get("one_way_fabric"):
        parts.append("一方方向の生地")
    # round58: 原型・収縮率・柄のリピートも、利用者が入れた設定である。
    # round57はここに書き忘れていたので、「引き継いだ設定」を読んでも
    # 子ども原型で引いたかどうかが分からなかった。下の
    # `test_every_setting_shows_up_in_the_restored_summary`で、
    # 設定が増えたときに書き忘れると落ちるようにしてある。
    block_key = kwargs.get("block_key")
    if kwargs.get("measured_block"):
        parts.append("原型「採寸指定（専用原型）」")
    elif block_key:
        parts.append(f"原型「{get_block(block_key).label}」")
    shrink = kwargs.get("shrink_percent")
    if shrink:
        parts.append(f"収縮率{shrink:g}%")
    repeat = kwargs.get("pattern_repeat_cm")
    if repeat:
        parts.append(f"柄のリピート{repeat:g}cm")
    if kwargs.get("include_empty_tiles"):
        parts.append("白紙の面も印刷")
    if (kwargs.get("paper") or "A4").upper() != "A4":
        parts.append(f"用紙{str(kwargs['paper']).upper()}")
    seam = kwargs.get("seam_allowance_cm")
    if seam is not None and seam != DEFAULT_SEAM_ALLOWANCE_CM:
        parts.append(f"縫い代{seam:g}cm")
    # round74: 重ね着の前提(中に着る服の出来上がりバスト)。これが落ちると
    # コートが中の服と同じ太さで再生成されるので、必ず書く。
    worn_over = kwargs.get("worn_over_bust_cm")
    if worn_over:
        parts.append(f"バスト{worn_over:g}cmの服の上に羽織る前提"
                     + ("" if kwargs.get("worn_over_has_sleeves", True)
                        else "（中は袖なし）"))
    # round76: ドロップショルダー。落ちると肩の形が変わった型紙が
    # 黙ってセットインスリーブに戻るので、必ず書く。
    drop = kwargs.get("shoulder_drop_cm")
    if drop:
        parts.append(f"肩先を{drop:g}cm出すドロップショルダー")
    if not parts:
        return "引き継いだ設定: 既定のまま（任意の設定は使われていません）"
    return "引き継いだ設定: " + " / ".join(parts)


def _evaluate_stash(pipeline_obj, result, spec, measurements, stash, *,
                     fabric_group_assignments=None, per_fabric_stash=None, **kwargs):
    """手持ちの生地で足りるかを判定する。生地を分けていれば**生地ごと**に。

    round55で直した実害: 手持ちの端切れは1種類の生地なのに、全パーツを
    1枚に詰めた長さで判定していた。「白い身頃＋紺のスカート」の紺だけを
    110×130cm持っている人に「117cm足りません」と答えていた——紺のぶんは
    124cmで、**実際には収まっていた**。持っている生地を使わずに買い足させる、
    いちばん困る間違え方である。

    Returns:
        (代表の判定, 生地ごとの判定のリスト)。生地を分けていないときは
        リストの方が空になり、round54までとまったく同じ形で返る。
    """
    if not result.fabric_groups:
        return pipeline_obj.evaluate_stash_for(
            result, spec, measurements,
            have_width_cm=stash[0], have_length_cm=stash[1], **kwargs), []

    by_fabric = []
    for group in result.fabric_groups:
        # round57: その生地ぶんの手持ちが入っていれば、それで判定する。
        # 入っていなければ、これまでどおり共通の1枚の寸法を当てる。
        have = (per_fabric_stash or {}).get(group.name, stash)
        verdict = pipeline_obj.evaluate_stash_for(
            result, spec, measurements,
            fabric_group_assignments=fabric_group_assignments,
            fabric_group_name=group.name,
            have_width_cm=have[0], have_length_cm=have[1], **kwargs)
        by_fabric.append((group.name, verdict))
    # 代表は「いちばん足りていないもの」にする。1つの数字しか見ない
    # 利用者に対して、**足りている方**を見せるのは危ない。
    worst = max(by_fabric, key=lambda item: (not item[1].fits,
                                              item[1].needed_length_cm))
    return worst[1], by_fabric


def _parse_fabric_groups(form) -> dict[str, str]:
    """「生地の割り当て」欄を読む(round54で追加)。

    フィールド名は`fabric_<区分key>`(例: `fabric_skirt`)。空欄の区分は
    既定の生地(表地)に入るので、ここには入れない。

    キャラクターの衣装は1着が1種類の生地でできていない——本体の色・
    差し色・別布・裏地と3〜5種類使う。round53まではその割り当てを
    受け取る場所が無く、全パーツを1枚の生地に詰めた配置しか出せなかった。
    """
    raw = {area.key: form.get(f"fabric_{area.key}") for area in ASSIGNABLE_AREAS}
    try:
        return normalize_assignments(raw)
    except FabricGroupError as exc:
        raise ValueError(str(exc)) from exc


def _parse_design_lengths(form) -> dict[str, float]:
    """「丈を指定する」欄を読む(round52で追加)。

    キャラクターの衣装は丈でシルエットが決まるので、身長からの比例だけでは
    合わせられない(膝丈・くるぶし丈・床に着く丈…)。空欄なら従来どおり
    身長に比例した丈になる。

    範囲は読み取り側と同じ `SKIRT_LENGTH_RANGE_CM` を使う——画面と
    エンジンで別々の数字を持つと、片方を直したときに食い違う。
    """
    lo, hi = SKIRT_LENGTH_RANGE_CM
    lengths: dict[str, float] = {}
    for part_type, label in DESIGN_LENGTH_FIELDS:
        raw = (form.get(f"length_{part_type}") or "").strip()
        if not raw:
            continue
        try:
            value = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{label}は数値で入力してください: {raw!r}") from exc
        if not (lo <= value <= hi):
            raise ValueError(
                f"{label}は{lo:g}〜{hi:g}cmの範囲で指定してください: {value:g}")
        lengths[part_type] = value
        # パンツ・身頃は前後で1枚ずつなので、後ろにも同じ丈を渡す。
        pair = DESIGN_LENGTH_PAIRS.get(part_type)
        if pair:
            lengths[pair] = value
    return lengths


def _parse_measured_block(form, block_key: str | None) -> dict[str, float] | None:
    """採寸指定原型の8項目を読む。空欄を成人女子式で補わない。"""
    if block_key != MEASURED_BLOCK_KEY:
        return None
    raw = {key: (form.get(f"block_{key}") or "").strip()
           for key in MEASURED_BLOCK_FIELDS}
    return validate_measured_block(raw)


def _too_large_message() -> str:
    """送信データが上限を超えたときに返す文(round37)。

    この上限に当たる経路は2つある——イラスト入力の画像と、カスタムパーツの
    輪郭(頂点の列をフォームの値として送る)。以前は前者だと決め打ちして
    「アップロードされた画像が大きすぎます」と返しており、画像を1枚も
    添付していない利用者にそう言っていた。何を減らせばよいのか分からない。

    ここでは実際の送信サイズも添える。`request.content_length`はヘッダから
    読むだけなので、本文の読み込みで例外になったあとでも安全に参照できる
    (`request.form`や`request.files`に触るとその場でもう一度例外になる)。
    """
    max_bytes = app.config["MAX_CONTENT_LENGTH"]
    sent = request.content_length or 0

    # 【どちらの上限に当たったのかを見分ける】上限は2つある。
    #   * MAX_CONTENT_LENGTH (12MB) — リクエスト全体。主に画像。
    #   * Werkzeugの max_form_memory_size (既定500KB) — **ファイル以外の
    #     フォームの値**の合計。カスタムパーツの輪郭(custom_panels_json)は
    #     ここに入る。
    # round37の実測では、輪郭を大きくして送ったとき、全体は1.9MBで12MBに
    # 届いていないのに413になっていた——効いていたのは後者である。
    # それなのに「上限12MB」と表示していたので、
    # 「12MBより小さいのに大きすぎると言われる」という、直しようのない
    # 案内になっていた。当たった方の上限を名指しする。
    form_limit = getattr(request, "max_form_memory_size", None)
    hit_content_length = bool(max_bytes) and sent > max_bytes
    if hit_content_length or not form_limit:
        return (
            f"送信されたデータが大きすぎます（上限{max_bytes / (1024 * 1024):.0f}MB"
            + (f"、今回は約{sent / (1024 * 1024):.1f}MB" if sent else "")
            + "）。添付する画像を小さくするか、枚数を減らしてください。"
        )
    return (
        f"入力内容が大きすぎます（画像以外の入力の上限は約{form_limit / 1000:.0f}KB"
        + (f"、今回の送信全体は約{sent / (1024 * 1024):.1f}MB" if sent else "")
        + "）。カスタムパーツを使っている場合は、輪郭の頂点を減らすか、"
        "パーツの数を減らしてください。"
    )


def _parse_seam_allowance_fields(form) -> tuple[float, float | None]:
    """`seam_allowance_cm`(通常の縫い代)と`hem_seam_allowance_cm`
    (裾だけ別幅にしたい場合。空欄なら通常の縫い代と同じ=従来通り)を
    フォームから読み取り、範囲チェックする。

    どちらも未入力(空文字列)を許容する任意項目にしてある。未入力時は
    seam_allowance_cmはDEFAULT_SEAM_ALLOWANCE_CM(1.0cm)、
    hem_seam_allowance_cmはNone(=通常縫い代と同じ)を返す。
    """
    raw_seam = (form.get("seam_allowance_cm") or "").strip()
    raw_hem = (form.get("hem_seam_allowance_cm") or "").strip()

    if raw_seam:
        try:
            seam_cm = float(raw_seam)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"縫い代は数値で入力してください: {raw_seam!r}") from exc
        # 0は「縫わない(線の上で切る)」の意思表示として通す(round52)。
        if seam_cm != SEAM_ALLOWANCE_NONE_CM and not (
                MIN_SEAM_ALLOWANCE_CM <= seam_cm <= MAX_SEAM_ALLOWANCE_CM):
            raise ValueError(
                f"縫い代は{MIN_SEAM_ALLOWANCE_CM}〜{MAX_SEAM_ALLOWANCE_CM}cmの範囲で指定してください"
                f"（EVAフォームなど縫わない素材は0を指定できます）: {seam_cm}cm"
            )
    else:
        seam_cm = DEFAULT_SEAM_ALLOWANCE_CM

    hem_cm: float | None = None
    if raw_hem:
        try:
            hem_cm = float(raw_hem)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"裾の縫い代は数値で入力してください: {raw_hem!r}") from exc
        if not (MIN_HEM_SEAM_ALLOWANCE_CM <= hem_cm <= MAX_HEM_SEAM_ALLOWANCE_CM):
            raise ValueError(
                f"裾の縫い代は{MIN_HEM_SEAM_ALLOWANCE_CM}〜{MAX_HEM_SEAM_ALLOWANCE_CM}cmの範囲で指定してください: {hem_cm}cm"
            )

    return seam_cm, hem_cm


def _parse_custom_grade_cm(form) -> dict[str, float] | None:
    """カスタムグレーディングルール(round7で追加)をフォームから読み取る。

    フィールド名は`grade_<部位名>`(例: `grade_bust`)で、`STANDARD_SIZE_GRADE_CM`
    の項目のうち入力があったものだけを辞書に含める。全て空欄ならNoneを返し
    (=呼び出し側で完全に既定値のまま扱われる)、1つでも入力があれば
    部分的な上書き用の辞書を返す(`engine.pipeline.PatternForgePipeline.
    generate_multi_size`のdocstring参照。指定しなかった項目は既定値の
    ままになる)。値の範囲チェック自体は`engine.measurements.
    validate_custom_grade_cm()`に委ねる(このアプリのUIから来た値も、
    将来APIを直接叩く利用者の値も、同じ検証を必ず通るようにするため)。
    """
    raw: dict[str, float] = {}
    for field_name in STANDARD_SIZE_GRADE_CM:
        value = (form.get(f"grade_{field_name}") or "").strip()
        if not value:
            continue
        try:
            raw[field_name] = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"カスタムグレーディングルール(grade_{field_name})は数値で入力してください: {value!r}"
            ) from exc
    if not raw:
        return None
    return validate_custom_grade_cm(raw)


#: イラストモードで一度に受け付ける画像の枚数の上限(round18)。
#: 1枚ごとに分割と判定(APIキーがあればClaude API呼び出し)が走るため、
#: 処理時間と費用が枚数に比例する。同じ衣装を別角度から数枚、という
#: 想定の枚数に留める。
MAX_ILLUSTRATION_IMAGES = 6


def _load_uploaded_image(uploaded) -> Image.Image:
    """アップロードされたイラストを検証しつつ読み込む。

    Image.open() 自体は(多くの形式で)ヘッダのみ読み、画素バッファはまだ
    確保しない。load()を呼ぶ前に幅×高さを検査することで、法外な解像度の
    画像に対して実際のデコード・メモリ確保コストを払わずに拒否できる
    （詳細はMAX_UPLOAD_IMAGE_PIXELSの定義コメントを参照）。

    実際のスマートフォン写真でテストして見つかった不具合の修正: 多くの
    スマホカメラはJPEGを「そのままのセンサー向き」のピクセル配列で保存し、
    表示時にどれだけ回転すべきかをEXIFのOrientationタグ(0x0112)に記録する
    （縦向きで撮った写真が横向きのピクセル配列で保存されているケースが多い）。
    Image.open()はこのタグを見て自動回転はしてくれないため、対策しないと
    「見た目は縦長の服の写真」を実際には90度回転した状態でパーツ分割してしまい、
    ネックライン・裾の位置判定が全てずれる。ImageOps.exif_transpose()で
    見た目通りの向きに正規化してから以降の処理に渡す。
    """
    try:
        image = Image.open(uploaded.stream)
    except Exception as exc:
        raise ValueError("画像を読み込めませんでした。対応形式(PNG/JPEG等)かご確認ください。") from exc

    width, height = image.size
    if width * height > MAX_UPLOAD_IMAGE_PIXELS:
        raise ValueError(
            f"アップロードされた画像の解像度が大きすぎます({width}x{height}px)。"
            "目安として長辺5000px程度以下に縮小してから再度お試しください。"
        )
    try:
        image.load()
        image = ImageOps.exif_transpose(image)
    except Exception as exc:
        raise ValueError("画像を読み込めませんでした。ファイルが破損している可能性があります。") from exc
    return image


def _has_custom_panels(raw_json: str) -> bool:
    """`custom_panels_json`に、実際にカスタムパーツが1つ以上入っているか。

    この欄の既定値は空文字ではなく **文字列 "[]"** なので、文字列としての
    真偽値で判定してはいけない(round32で直した実バグ。詳細は呼び出し側の
    コメント参照)。JSONとして壊れている場合はTrueを返し、`_parse_custom_panels`
    側の具体的なエラーメッセージに任せる(ここで黙って無視すると、送った
    はずのカスタムパーツが理由も無く消える)。
    """
    if not raw_json:
        return False
    try:
        parsed = json.loads(raw_json)
    except (TypeError, ValueError):
        return True
    if isinstance(parsed, list):
        return len(parsed) > 0
    return True


def _parse_custom_panels(raw_json: str, measurements: Measurements) -> list[CustomPanelSpec]:
    """`custom_panels_json`フォームフィールド(JSON文字列)を解析し、校正済み
    (cm単位)のCustomPanelSpecのリストに変換する(round10で追加)。

    期待するJSON形式は以下のようなオブジェクトの配列:
      [{"label": "マント", "points": [[x,y], ...],
        "ref_point_a": [x,y], "ref_point_b": [x,y],
        "reference_cm": 40.0,             # または "measurement_field": "shoulder_width"
        "quantity": 1, "mirror": false}, ...]
    座標(points/ref_point_a/ref_point_b)は同じ単位系(通常はアップロード画像の
    ピクセル座標、または手動トレースUIのcanvas座標)であれば何でもよい。
    校正(ピクセル距離→実寸cm)自体は`engine.custom_panel.calibrate_points_to_cm`
    に委譲し、ここでは「JSONとして正しいか」「1リクエストあたりの上限」
    「どのパーツ(何番目/ラベル)が失敗したか分かるメッセージにする」という
    HTTP層固有の関心事だけを扱う。
    """
    try:
        raw_panels = json.loads(raw_json)
    except (TypeError, ValueError) as exc:
        raise ValueError("custom_panels_jsonの形式が不正です(JSONとして解析できませんでした)。") from exc
    if not isinstance(raw_panels, list):
        raise ValueError("custom_panels_jsonはパーツの配列(リスト)にしてください。")
    if len(raw_panels) > MAX_CUSTOM_PANELS_PER_REQUEST:
        raise ValueError(
            f"カスタムパーツは1リクエストあたり{MAX_CUSTOM_PANELS_PER_REQUEST}個までです"
            f"（現在{len(raw_panels)}個）。"
        )

    specs: list[CustomPanelSpec] = []
    for idx, raw in enumerate(raw_panels):
        panel_no = idx + 1
        if not isinstance(raw, dict):
            raise ValueError(f"カスタムパーツ{panel_no}番目の形式が不正です。")
        panel_label_for_error = raw.get("label") if isinstance(raw.get("label"), str) else f"{panel_no}番目"
        try:
            label = validate_label(raw.get("label"))
            quantity = validate_quantity(raw.get("quantity", 1))
            resolved_cm = resolve_reference_cm(
                raw.get("reference_cm"), raw.get("measurement_field"), measurements,
            )
            points_cm = calibrate_points_to_cm(
                raw.get("points"), raw.get("ref_point_a"), raw.get("ref_point_b"), resolved_cm,
            )
            mirror = validate_boolean(raw.get("mirror"), "mirror")
            # round57: 生地幅に収まらないときに分けてよいか(既定は分けない)。
            # マントは中心で縫い合わせるのがふつうだが、EVAフォームの装甲に
            # 縫い目を入れるのは別の話なので、**作る人が決める**。
            allow_split = validate_boolean(raw.get("allow_split"), "allow_split")
            replacement_part_type = validate_replacement_part_type(
                raw.get("replacement_part_type"))
            seam_fit_confirmed = validate_boolean(
                raw.get("seam_fit_confirmed"), "seam_fit_confirmed")
            grade_width_cm = validate_grade_increment(
                raw.get("grade_width_cm"), "幅のサイズ刻み")
            grade_height_cm = validate_grade_increment(
                raw.get("grade_height_cm"), "高さのサイズ刻み")
            if replacement_part_type and not seam_fit_confirmed:
                raise CustomPanelError(
                    "標準パーツを置き換えるには、この輪郭が着用画像の外形ではなく"
                    "実寸の平面型紙であり、接続する縫い線を確認済みであることを"
                    "確認してください。")
        except CustomPanelError as exc:
            raise ValueError(f"カスタムパーツ「{panel_label_for_error}」: {exc}") from exc
        specs.append(CustomPanelSpec(
            label=label, points_cm=points_cm, quantity=quantity,
            mirror=mirror, allow_split=allow_split,
            replacement_part_type=replacement_part_type,
            seam_fit_confirmed=seam_fit_confirmed if replacement_part_type else False,
            grade_width_cm=grade_width_cm, grade_height_cm=grade_height_cm))
    return specs


def _custom_panel_specs_to_requests(specs: list[CustomPanelSpec]) -> list:
    """校正済みのCustomPanelSpecのリストを、GarmentSpec.partsに追加できる
    PartRequestのリストに変換する(mirror指定のパーツは2枚分に展開される)。
    """
    requests = []
    for spec in specs:
        requests.extend(build_custom_panel_requests(
            spec.label, spec.points_cm, quantity=spec.quantity, mirror=spec.mirror,
            allow_split=getattr(spec, "allow_split", False),
            replacement_part_type=getattr(spec, "replacement_part_type", None),
            seam_fit_confirmed=getattr(spec, "seam_fit_confirmed", False),
            grade_width_cm=getattr(spec, "grade_width_cm", 0.0),
            grade_height_cm=getattr(spec, "grade_height_cm", 0.0),
        ))
    return requests


_custom_panel_trace_rate_limiter = _RateLimiter("custom_panel_trace", max_requests=20, window_seconds=60.0)


@app.post("/api/measurements/check")
def api_measurements_check():
    """採寸値の「たぶん測り間違い」を、生成する前に返す(round33で追加)。

    【なぜ生成前に要るか】採寸ミスはこのサービスがうまくいかない最大の
    原因なのに、round32までは指摘が**生成したあと**にしか出ていなかった
    (クランプ警告・胸幅の警告)。1日の生成回数を1回使い、PDFを開いて
    初めて「肩幅の採寸を確かめてください」と言われる。入れた直後に
    分かれば、その回を使わずに済む。

    判定は`engine/plausibility.py`にあり、型紙を作らないので生成回数は
    消費しない。値が有効範囲(`Measurements`の検証)の外なら、その旨だけを
    返す(ここで例外にすると、入力途中の欄でエラーが出続けてしまう)。
    """
    try:
        measurements = _parse_measurements(request.form)
    except ValueError as exc:
        return jsonify({"ok": True, "hints": [
            {"field": "", "severity": "warning", "message": str(exc)}]})
    hints = measurement_hints(measurements)
    return jsonify({"ok": True, "hints": [h.as_dict() for h in hints]})


@app.post("/api/custom-panel/trace")
def api_custom_panel_trace():
    """アップロードされたイラスト画像から輪郭を自動抽出する(round10で追加)。

    「アニメ画像からのコスプレ生成」要望に対応するcustom_panel機能
    (engine/custom_panel.py参照)の入力補助エンドポイント。フロントエンドの
    手動トレースUI(round10、web/static/app.js予定)は、まずここに画像を
    送って自動抽出した輪郭を初期値として表示し、利用者はその後クリックで
    頂点を追加・削除・ドラッグ調整できる(「自動抽出＋手動調整の両方」という
    round10のAskUserQuestion回答に対応)。

    実際に型紙を生成する`/api/generate`とは違い、これは輪郭候補を返すだけの
    補助APIのため、1日あたりの生成回数上限(daily usage)は消費しない
    （課金対象は実際にパターンを生成する/api/generateのみ、という既存の
    設計方針を踏襲）。ただし画像処理コスト自体は無視できないため、IPベースの
    レート制限(_custom_panel_trace_rate_limiter)は別途適用する。
    """
    if not _custom_panel_trace_rate_limiter.allow(_client_key()):
        return jsonify({"ok": False, "error": "リクエストが多すぎます。しばらく待って再試行してください。"}), 429
    try:
        uploaded = request.files.get("image")
        if not (uploaded and uploaded.filename):
            raise ValueError("画像がアップロードされていません。")
        image = _load_uploaded_image(uploaded)
        # auto_trace_outlineはSimpleSilhouetteSegmenter固有のメソッド(round9で
        # 追加)。イラストモード本体のパーツ判定に使うget_default_segmenter()
        # (AI判定込みのSAMSegmenter等になりうる)とは無関係に、常にこの
        # 単純な画像処理ベースの輪郭抽出を使う(輪郭トレースはAIのパーツ種
        # 判定とは別の、幾何学的な処理のため)。
        points = SimpleSilhouetteSegmenter().auto_trace_outline(image)
        if points is None:
            return jsonify({
                "ok": False,
                "error": "画像から輪郭を自動抽出できませんでした。背景と衣装の境目がはっきりした"
                          "画像でお試しいただくか、手動で頂点をクリックして輪郭を指定してください。",
            }), 422
        width, height = image.size
        return jsonify({
            "ok": True,
            "points": [[round(x, 1), round(y, 1)] for x, y in points],
            "image_width": width,
            "image_height": height,
        })
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except RequestEntityTooLarge:
        # round37: 文言の理由は下の`_too_large_message`と、
        # /api/generate 側の同じ except 節のコメントを参照。
        return jsonify({"ok": False, "error": _too_large_message()}), 413
    except Exception:
        error_id = uuid.uuid4().hex[:8]
        app.logger.exception("custom panel auto trace failed [error_id=%s]", error_id)
        return jsonify({
            "ok": False,
            "error": f"内部エラーが発生しました（エラーID: {error_id}）。しばらく待って再試行してください。",
        }), 500


def _normalize_motif_points(points) -> tuple[list[list[float]], tuple[float, float, float, float]]:
    """画像座標の輪郭を0..1へ変換し、元の外接枠も返す。"""
    if not points or len(points) < 3:
        raise ValueError(
            "装飾画像から外周を抽出できませんでした。透明背景PNG、または背景と"
            "装飾の境界がはっきりした画像を使用してください。")
    min_x = min(x for x, _y in points)
    max_x = max(x for x, _y in points)
    min_y = min(y for _x, y in points)
    max_y = max(y for _x, y in points)
    width, height = max_x - min_x, max_y - min_y
    if width <= 1e-6 or height <= 1e-6:
        raise ValueError("装飾画像の外周に幅または高さがありません。")
    return ([[round((x - min_x) / width, 6),
              round((y - min_y) / height, 6)] for x, y in points],
            (min_x, min_y, max_x, max_y))


def _trace_normalized_motif_data(uploaded) -> tuple[list[list[float]], list[dict]]:
    """外周に加え、主要な色面を再生成可能な輪郭として抽出する。"""
    image = _load_uploaded_image(uploaded)
    points = SimpleSilhouetteSegmenter().auto_trace_outline(image)
    outline, bounds = _normalize_motif_points(points)
    rgba = image.convert("RGBA")
    quantized = rgba.convert("RGB").quantize(colors=8)
    palette = quantized.getpalette() or []
    def _pixels(image):
        getter = getattr(image, "get_flattened_data", None)
        return list(getter() if getter is not None else image.getdata())

    indexed = _pixels(quantized)
    alpha = _pixels(rgba.getchannel("A"))
    inside_image = Image.new("1", rgba.size, 0)
    ImageDraw.Draw(inside_image).polygon(points, fill=1)
    inside = _pixels(inside_image)
    counts: dict[int, int] = {}
    for index, opacity, is_inside in zip(indexed, alpha, inside):
        if opacity >= 64 and is_inside:
            counts[index] = counts.get(index, 0) + 1
    minimum = max(8, int(sum(counts.values()) * 0.01))
    regions: list[dict] = []
    segmenter = SimpleSilhouetteSegmenter()
    for colour_index, count in sorted(counts.items(), key=lambda item: -item[1]):
        if count < minimum or len(regions) >= 6:
            continue
        mask = Image.new("RGB", rgba.size, "white")
        mask.putdata([
            (0, 0, 0) if idx == colour_index and opacity >= 64 and is_inside
            else (255, 255, 255)
            for idx, opacity, is_inside in zip(indexed, alpha, inside)
        ])
        region_points = segmenter.auto_trace_outline(mask)
        if not region_points or len(region_points) < 3:
            continue
        min_x, min_y, max_x, max_y = bounds
        width, height = max_x - min_x, max_y - min_y
        normalized = [[round(max(0.0, min(1.0, (x - min_x) / width)), 6),
                       round(max(0.0, min(1.0, (y - min_y) / height)), 6)]
                      for x, y in region_points]
        rgb = palette[colour_index * 3:colour_index * 3 + 3]
        if len(rgb) != 3:
            continue
        regions.append({"color": "#" + "".join(f"{value:02X}" for value in rgb),
                        "points": normalized})
    return outline, regions


def _trace_normalized_motif_outline(uploaded) -> list[list[float]]:
    """後方互換用。装飾画像の外周だけを返す。"""
    return _trace_normalized_motif_data(uploaded)[0]




# ---------------------------------------------------------------------------
# `/api/generate` が受け取った値を、1つに束ねたもの(round63で追加)
#
# 【なぜ束ねるか】3つのモード(手動・イラスト・サイズ展開)の生成は、
# どれも同じ28個の値を使う。引数で並べると1つの関数に押し込めるしか
# なくなり、実際そうなっていた——`api_generate`は498行あった。
# 束ねれば、モードごとに分けて読めるようになる。
#
# それぞれのモードの関数は、冒頭で**使う値だけを取り出して**いる。
# その数行を読めば、そのモードが何に依存しているかが分かる。
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class GenerationInputs:
    """画面から届いた値と、利用回数の確認結果。"""
    allow_rotation: object = None
    accessory_3d: object = None
    alterations: object = None
    block_key: object = None
    custom_grade_cm: object = None
    custom_panel_specs: object = None
    costume_project: object = None
    daily_limit: object = None
    design_lengths: object = None
    fabric_groups: object = None
    fit: object = None
    garment_spec_kwargs: object = None
    hem_seam_allowance_cm: object = None
    illustration_views: object = None
    illustration_corrections: object = None
    illustration_stage: object = None
    image: object = None
    include_body_garment: object = None
    lining: object = None
    measurements: object = None
    measured_block: object = None
    mode: object = None
    one_way_fabric: object = None
    owner_key: object = None
    pattern_repeat_cm: object = None
    per_fabric_stash: object = None
    plan_name: object = None
    project_name: object = None
    seam_allowance_cm: object = None
    shrink_percent: object = None
    sizes: object = None
    spec: object = None
    stash: object = None
    used_today: object = None


def _export_accessory_outputs(result, custom_panel_specs, settings):
    """自由輪郭をSTLと業者入稿ZIPへ出し、生成結果へ登録する。"""
    if not settings:
        return None, None
    custom_panel_specs = [
        spec for spec in custom_panel_specs
        if not getattr(spec, "replacement_part_type", None)
    ]
    if not custom_panel_specs:
        raise ValueError(
            "3D小物にできる追加パーツがありません。標準の服型紙を置き換える"
            "輪郭は布用として扱います。3D出力する小物は別のカスタムパーツとして"
            "追加してください。")
    stl_path = os.path.join(OUTPUT_DIR, f"{result.job_id}.stl")
    accessory_result = export_accessories_stl(
        custom_panel_specs, stl_path,
        thickness_mm=settings["thickness_mm"],
        bed_width_mm=settings["bed_width_mm"],
        bed_depth_mm=settings["bed_depth_mm"],
        curvature_radius_mm=settings.get("curvature_radius_mm"),
        curvature_radius_height_mm=settings.get("curvature_radius_height_mm"),
        curve_axis=settings.get("curve_axis", "width"),
        mounting_hole_pattern=settings.get("mounting_hole_pattern", "none"),
        mounting_hole_diameter_mm=settings.get("mounting_hole_diameter_mm"),
        mounting_hole_inset_mm=settings.get("mounting_hole_inset_mm"),
        mounting_slot_pattern=settings.get("mounting_slot_pattern", "none"),
        mounting_slot_length_mm=settings.get("mounting_slot_length_mm"),
        mounting_slot_width_mm=settings.get("mounting_slot_width_mm"),
        mounting_slot_axis=settings.get("mounting_slot_axis", "width"),
        mounting_slot_inset_mm=settings.get("mounting_slot_inset_mm"),
        magnet_pocket_pattern=settings.get("magnet_pocket_pattern", "none"),
        magnet_pocket_diameter_mm=settings.get("magnet_pocket_diameter_mm"),
        magnet_pocket_depth_mm=settings.get("magnet_pocket_depth_mm"),
        magnet_pocket_inset_mm=settings.get("magnet_pocket_inset_mm"),
        attachment_interface=settings.get("attachment_interface", "none"),
    )
    result.output_files["stl"] = stl_path
    vendor_path = os.path.join(OUTPUT_DIR, f"{result.job_id}_vendor.zip")
    vendor_result = export_vendor_package(
        custom_panel_specs, vendor_path,
        thickness_mm=settings["thickness_mm"],
        bed_width_mm=settings["bed_width_mm"],
        bed_depth_mm=settings["bed_depth_mm"],
        material_profile=settings.get("material_profile", "consult"),
        finish_note=settings.get("finish_note", "業者と相談"),
        curvature_radius_mm=settings.get("curvature_radius_mm"),
        curvature_radius_height_mm=settings.get("curvature_radius_height_mm"),
        curve_axis=settings.get("curve_axis", "width"),
        mounting_hole_pattern=settings.get("mounting_hole_pattern", "none"),
        mounting_hole_diameter_mm=settings.get("mounting_hole_diameter_mm"),
        mounting_hole_inset_mm=settings.get("mounting_hole_inset_mm"),
        mounting_slot_pattern=settings.get("mounting_slot_pattern", "none"),
        mounting_slot_length_mm=settings.get("mounting_slot_length_mm"),
        mounting_slot_width_mm=settings.get("mounting_slot_width_mm"),
        mounting_slot_axis=settings.get("mounting_slot_axis", "width"),
        mounting_slot_inset_mm=settings.get("mounting_slot_inset_mm"),
        magnet_pocket_pattern=settings.get("magnet_pocket_pattern", "none"),
        magnet_pocket_diameter_mm=settings.get("magnet_pocket_diameter_mm"),
        magnet_pocket_depth_mm=settings.get("magnet_pocket_depth_mm"),
        magnet_pocket_inset_mm=settings.get("magnet_pocket_inset_mm"),
        attachment_interface=settings.get("attachment_interface", "none"),
    )
    result.output_files["vendor_zip"] = vendor_path
    result.garment_spec.construction["accessory_3d"] = {
        "thickness_mm": settings["thickness_mm"],
        "curvature_radius_mm": settings.get("curvature_radius_mm"),
        "curvature_radius_height_mm": settings.get("curvature_radius_height_mm"),
        "curve_axis": settings.get("curve_axis", "width"),
        "mounting_hole_pattern": settings.get("mounting_hole_pattern", "none"),
        "mounting_hole_diameter_mm": settings.get("mounting_hole_diameter_mm"),
        "mounting_hole_inset_mm": settings.get("mounting_hole_inset_mm"),
        "mounting_slot_pattern": settings.get("mounting_slot_pattern", "none"),
        "mounting_slot_length_mm": settings.get("mounting_slot_length_mm"),
        "mounting_slot_width_mm": settings.get("mounting_slot_width_mm"),
        "mounting_slot_axis": settings.get("mounting_slot_axis", "width"),
        "mounting_slot_inset_mm": settings.get("mounting_slot_inset_mm"),
        "magnet_pocket_pattern": settings.get("magnet_pocket_pattern", "none"),
        "magnet_pocket_diameter_mm": settings.get("magnet_pocket_diameter_mm"),
        "magnet_pocket_depth_mm": settings.get("magnet_pocket_depth_mm"),
        "magnet_pocket_inset_mm": settings.get("magnet_pocket_inset_mm"),
        "attachment_interface": settings.get("attachment_interface", "none"),
        "material_profile": settings.get("material_profile", "consult"),
        "finish_note": settings.get("finish_note", "業者と相談"),
    }
    if "spec_pdf" in result.output_files:
        export_specification_pdf(result, result.output_files["spec_pdf"])
    return accessory_result, vendor_result


def _mark_svg_as_draft(path: str) -> None:
    """診断用SVGへ、裁断用ではないことを消せない見た目で重ねる。"""
    try:
        source = Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return
    marker = """
<g id="patternforge-draft-watermark" pointer-events="none">
  <rect x="0" y="0" width="100%" height="100%" fill="#fff" fill-opacity="0.32"/>
  <text x="50%" y="48%" text-anchor="middle" font-family="sans-serif"
        font-size="48" font-weight="700" fill="#b00020" fill-opacity="0.72"
        transform="rotate(-18)">DRAFT / NOT FOR CUTTING</text>
  <text x="50%" y="54%" text-anchor="middle" font-family="sans-serif"
        font-size="22" font-weight="700" fill="#b00020">未確認項目があります・裁断禁止</text>
</g>
"""
    index = source.rfind("</svg>")
    if index < 0 or "patternforge-draft-watermark" in source:
        return
    temp_path = path + ".draft.tmp"
    try:
        Path(temp_path).write_text(source[:index] + marker + source[index:],
                                   encoding="utf-8")
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def _withhold_unconfirmed_outputs(result) -> str | None:
    """ラフ確認では裁断・CAD・投影データを配らず、透かし入りSVGだけ残す。"""
    if not result.garment_spec.construction.get("draft_mode"):
        return None
    preview_path = result.output_files.get("svg")
    if preview_path:
        _mark_svg_as_draft(preview_path)
    output_root = os.path.abspath(OUTPUT_DIR)
    for key, path in list(result.output_files.items()):
        if key in {"svg", "spec_pdf"}:
            continue
        absolute = os.path.abspath(path)
        try:
            inside_output = os.path.commonpath([output_root, absolute]) == output_root
        except ValueError:
            inside_output = False
        if inside_output and os.path.isfile(absolute):
            os.remove(absolute)
        result.output_files.pop(key, None)
    # SVGは結果画面の診断プレビュー専用。通常のダウンロード一覧には出さない。
    result.output_files.pop("svg", None)
    return preview_path


def _production_status(result) -> dict:
    ready, pending = production_readiness(result)
    draft = bool(result.garment_spec.construction.get("draft_mode"))
    return {"ready": bool(ready and not draft), "draft": draft, "pending": pending}


def _respond_illustration(inputs: GenerationInputs):
    """イラストから読み取って生成する。

    `api_generate`から呼ばれる。このモードが使う値は、下の数行で
    まとめて取り出している(20個)。
    """
    allow_rotation = inputs.allow_rotation
    alterations = inputs.alterations
    block_key = inputs.block_key
    daily_limit = inputs.daily_limit
    design_lengths = inputs.design_lengths
    fabric_groups = inputs.fabric_groups
    fit = inputs.fit
    hem_seam_allowance_cm = inputs.hem_seam_allowance_cm
    illustration_views = inputs.illustration_views
    illustration_corrections = inputs.illustration_corrections
    illustration_stage = inputs.illustration_stage
    custom_panel_specs = inputs.custom_panel_specs or []
    accessory_3d = inputs.accessory_3d
    image = inputs.image
    lining = inputs.lining
    measurements = inputs.measurements
    measured_block = inputs.measured_block
    mode = inputs.mode
    one_way_fabric = inputs.one_way_fabric
    owner_key = inputs.owner_key
    pattern_repeat_cm = inputs.pattern_repeat_cm
    plan_name = inputs.plan_name
    project_name = inputs.project_name
    seam_allowance_cm = inputs.seam_allowance_cm
    shrink_percent = inputs.shrink_percent
    used_today = inputs.used_today

    result = pipeline.generate_from_illustration(
        image, measurements, allow_rotation=allow_rotation,
        seam_allowance_cm=seam_allowance_cm, hem_seam_allowance_cm=hem_seam_allowance_cm,
        views=illustration_views, fit=fit,
        # round52: 丈の指定は、イラストからの読み取りより優先する
        # (engine側が `"skirt" not in design_length_overrides` を
        #  見て、読み取り値で上書きしないようになっている)。
        design_length_overrides=design_lengths or None,
        fabric_group_assignments=fabric_groups or None,
        # round57: 画面にある設定は、イラストモードでも効かせる。
        one_way_fabric=one_way_fabric, shrink_percent=shrink_percent,
        pattern_repeat_cm=pattern_repeat_cm,
        alterations=alterations, lining=lining, block_key=block_key,
        measured_block=measured_block,
        corrections=illustration_corrections,
        extra_part_requests=_custom_panel_specs_to_requests(custom_panel_specs),
        include_empty_tiles=_bool_field(request.form, "include_empty_tiles"),
        paper=(request.form.get("paper") or "").strip() or None,
    )

    draft_preview_path = _withhold_unconfirmed_outputs(result)
    accessory_3d_result, vendor_package_result = _export_accessory_outputs(
        result, custom_panel_specs, accessory_3d)
    payload = result.summary()
    payload["production_status"] = _production_status(result)
    if draft_preview_path:
        payload["preview_svg"] = f"/download/{result.job_id}/svg"
    if accessory_3d_result:
        payload["accessory_3d"] = accessory_3d_result.as_dict()
        payload["accessory_3d"]["vendor_package"] = vendor_package_result.as_dict()
    # round57: イラストから作ったものも、生成履歴から作り直せるようにする。
    #
    # round51以来「画像を保存していないため作り直せません」と案内して
    # きたが、作り直すのに要るのは**画像ではなく、画像から決まった
    # 結果**である。イラストが決めるのはパーツ構成(襟ぐり・袖・
    # スカートの種類)と丈だけで、どちらも生成結果に残っている。
    # それを保存すれば、**画像を持ち続けずに**同じ型紙を作り直せる。
    # 画像そのものは今までどおり保存しない。
    illustration_spec = {
        "mode": "illustration_replay",
        "project_name": project_name,
        "measurements": measurements.as_dict(),
        "parts": [
            {"part_type": part.part_type, "variation": part.variation,
             "quantity": part.quantity,
             "design_length_cm": part.design_length_cm,
             "layer_number": part.layer_number,
             "custom_segments": part.custom_segments,
             "allow_split": part.allow_split,
             "replacement_part_type": part.replacement_part_type,
             "seam_fit_confirmed": part.seam_fit_confirmed,
             "grade_width_cm": part.grade_width_cm,
             "grade_height_cm": part.grade_height_cm}
            for part in result.garment_spec.parts
        ],
        "princess_line": bool(result.garment_spec.princess_line),
        "construction": dict(result.garment_spec.construction),
        "custom_panels": [
            {"label": panel.label, "points_cm": [list(point) for point in panel.points_cm],
             "quantity": panel.quantity, "mirror": panel.mirror,
             "allow_split": panel.allow_split,
             "replacement_part_type": getattr(panel, "replacement_part_type", None),
             "seam_fit_confirmed": getattr(panel, "seam_fit_confirmed", False),
             "grade_width_cm": getattr(panel, "grade_width_cm", 0.0),
             "grade_height_cm": getattr(panel, "grade_height_cm", 0.0)}
            for panel in custom_panel_specs
        ],
        "accessory_3d": accessory_3d,
        "illustration_stage": illustration_stage,
        "generation_kwargs": {
            "allow_rotation": allow_rotation,
            "seam_allowance_cm": seam_allowance_cm,
            "hem_seam_allowance_cm": hem_seam_allowance_cm,
            "fit": _fit_to_json(fit),
            "one_way_fabric": one_way_fabric,
            "shrink_percent": shrink_percent,
            "pattern_repeat_cm": pattern_repeat_cm,
            "alterations": alterations or None,
            "lining": lining,
            "block_key": block_key,
            "measured_block": measured_block,
            "fabric_group_assignments": fabric_groups or None,
            "include_empty_tiles": _bool_field(request.form, "include_empty_tiles"),
            "paper": (request.form.get("paper") or "").strip() or None,
            # 絵から読み取った丈も含めて、実際に使われた値を残す。
            "design_length_overrides": (result.resolved_design_lengths or None),
        },
    }
    db.record_job(result.job_id, owner_key, part_count=payload["part_count"],
                  waste_ratio=payload["waste_ratio"],
                  spec_json=json.dumps(illustration_spec), project_name=project_name)
    payload["project_name"] = project_name
    payload["download"] = _download_links(result)
    payload["classification_log"] = [
        {"part_type": c.part_type, "variation": c.variation, "confidence": round(c.confidence, 2),
         "mode": (c.raw or {}).get("mode", "claude")}
        for c in result.classification_log
    ]
    # ラフ画像は「生成に成功」しても、線が少ないため細部を読み落としやすい。
    # とくに簡易判定(モック)では入力画像を意味的に解析していないので、成功した
    # PDFを高い再現度の結果と誤解させない。結果画面に、何を読んだか／次に何を
    # 足すべきかを構造化して返す。
    modes = {entry["mode"] for entry in payload["classification_log"]}
    used_mock = "mock" in modes
    has_back_reference = any(f and f.filename for f in request.files.getlist("illustration_back"))
    has_side_reference = any(f and f.filename for f in request.files.getlist("illustration_side"))
    has_detail_reference = any(f and f.filename for f in request.files.getlist("illustration_detail"))
    evidence = payload.get("classification_evidence") or []
    if evidence:
        detected = []
        for entry in evidence:
            text = (f"{entry['part_type']}：{entry['variation'] or '標準'}"
                    f"（{entry['votes']}票・合計信頼度 {entry['confidence_sum']:.2f}）")
            if entry.get("conflicted"):
                alternatives = "、".join(
                    f"{item['variation'] or '標準'} {item['confidence_sum']:.2f}"
                    for item in entry.get("alternatives", [])[:2])
                text += f"／要確認: 別候補 {alternatives}"
            detected.append(text)
    else:
        detected = [
            f"{entry['part_type']}：{entry['variation']}（信頼度 {entry['confidence']:.0%}）"
            for entry in payload["classification_log"]
        ]
    missing = ["着る人の実採寸（入力済みの値を確認）"]
    if not has_back_reference:
        missing.insert(0, "背面資料（後ろ襟・背中の切替・ファスナー位置を確認）")
    if not has_side_reference:
        missing.append("側面資料（脇線・前後差・厚み・ドレープを確認）")
    if not has_detail_reference:
        missing.append("装飾拡大（留め具・金具・プリント・切替線を確認）")
    if any(entry.get("conflicted") for entry in evidence):
        missing.append("複数画像で形の判定が割れています。要確認と表示されたパーツを確定してください")
    if illustration_corrections:
        detected.insert(0, "利用者の確認入力を自動判定より優先して反映")
    if used_mock:
        payload.setdefault("measurement_warnings", []).append(
            "この画像入力は簡易判定（モック）で生成しました。ラフの細部は読めないため、"
            "生成した型紙をそのまま裁断せず、正面・背面・側面・装飾拡大を追加し、"
            "『自動判定を確認・補正する』で形を確定してから仮縫いしてください。"
        )
        summary = ("簡易判定でシルエットの土台を生成しました。自動判定が難しい形は、"
                   "生成前の確認・補正欄で確定できます。")
    else:
        summary = "画像判定でシルエットの土台を生成しました。下の読み取り内容と資料不足を確認してから裁断してください。"
    payload["reference_review"] = {
        "summary": summary,
        "detected": detected,
        "missing": missing,
        "has_back_reference": has_back_reference,
        "has_side_reference": has_side_reference,
        "has_detail_reference": has_detail_reference,
        "used_mock": used_mock,
    }
    payload["usage"] = {"plan": plan_name, "used_today": used_today, "daily_limit": daily_limit}
    return jsonify({"ok": True, "mode": mode, **payload})


def _respond_multi_size(inputs: GenerationInputs):
    """同じ服を複数サイズぶん生成する。

    `api_generate`から呼ばれる。このモードが使う値は、下の数行で
    まとめて取り出している(24個)。
    """
    allow_rotation = inputs.allow_rotation
    alterations = inputs.alterations
    block_key = inputs.block_key
    custom_grade_cm = inputs.custom_grade_cm
    custom_panel_specs = inputs.custom_panel_specs or []
    daily_limit = inputs.daily_limit
    design_lengths = inputs.design_lengths
    fabric_groups = inputs.fabric_groups
    fit = inputs.fit
    garment_spec_kwargs = inputs.garment_spec_kwargs
    hem_seam_allowance_cm = inputs.hem_seam_allowance_cm
    lining = inputs.lining
    measurements = inputs.measurements
    measured_block = inputs.measured_block
    mode = inputs.mode
    one_way_fabric = inputs.one_way_fabric
    owner_key = inputs.owner_key
    pattern_repeat_cm = inputs.pattern_repeat_cm
    per_fabric_stash = inputs.per_fabric_stash
    plan_name = inputs.plan_name
    project_name = inputs.project_name
    seam_allowance_cm = inputs.seam_allowance_cm
    shrink_percent = inputs.shrink_percent
    sizes = inputs.sizes
    spec = inputs.spec
    stash = inputs.stash
    used_today = inputs.used_today

    multi_size_kwargs = {
        "allow_rotation": allow_rotation,
        "seam_allowance_cm": seam_allowance_cm,
        "hem_seam_allowance_cm": hem_seam_allowance_cm,
        "custom_grade_cm": custom_grade_cm,
        "fit": fit,
        "fabric_group_assignments": fabric_groups or None,
        "one_way_fabric": one_way_fabric,
        "shrink_percent": shrink_percent,
        "pattern_repeat_cm": pattern_repeat_cm,
        "design_length_overrides": design_lengths or None,
        "alterations": alterations or None,
        "lining": lining,
        "block_key": block_key,
        "measured_block": measured_block,
        "include_empty_tiles": _bool_field(request.form, "include_empty_tiles"),
        "paper": (request.form.get("paper") or "").strip() or None,
    }
    multi = pipeline.generate_multi_size(
        spec, measurements, sizes, **multi_size_kwargs)
    total_parts = sum(r.summary()["part_count"] for r in multi.results.values())
    regen_spec = {
        "mode": "multi_size",
        "project_name": project_name,
        "measurements": measurements.as_dict(),
        "garment_spec": garment_spec_kwargs,
        "sizes": sizes,
        "custom_grade_cm": custom_grade_cm,
        "custom_panels": [
            {"label": panel.label,
             "points_cm": [list(point) for point in panel.points_cm],
             "quantity": panel.quantity, "mirror": panel.mirror,
             "allow_split": panel.allow_split,
             "replacement_part_type": panel.replacement_part_type,
             "seam_fit_confirmed": panel.seam_fit_confirmed,
             "grade_width_cm": panel.grade_width_cm,
             "grade_height_cm": panel.grade_height_cm}
            for panel in custom_panel_specs
        ],
        "construction": dict(spec.construction),
        "allow_rotation": allow_rotation,
        "seam_allowance_cm": seam_allowance_cm,
        "hem_seam_allowance_cm": hem_seam_allowance_cm,
        # round55: 手動生成と同じく、渡した設定をそのまま保存する
        # (それまで fit と生地の割り当てが再生成で消えていた)。
        # round58: 「そのまま保存する」と書きながら、実際には6件を
        # **手で並べ直して**いたので、生成に渡す側が増えても
        # 保存側は増えなかった。渡した辞書そのものを保存する。
        "multi_size_kwargs": {**multi_size_kwargs,
                               "fit": _fit_to_json(multi_size_kwargs["fit"])},
    }
    db.record_job(multi.bundle_job_id, owner_key, part_count=total_parts, waste_ratio=None,
                  spec_json=json.dumps(regen_spec), project_name=project_name)

    results_payload = {}
    for size, result in multi.results.items():
        # round58: 手持ちの生地で足りるかを、**サイズごとに**判定する。
        #
        # 【round57まで何が起きていたか】手持ちの欄は「⑤生地の配置
        # 設定」の中にあり、どのモードでも出ている。それなのに判定を
        # していたのは手動モードだけで、サイズ展開では
        # `stash_verdict` が null のまま返っていた(実測)。
        # 画面にも何も出ないので、**入れたことすら忘れる**。
        # S/M/Lを1枚の端切れから取れるかは、まさにここで知りたい。
        if stash is not None:
            result.stash_verdict, result.stash_verdicts_by_fabric = _evaluate_stash(
                pipeline, result, spec, result.measurements, stash,
                fabric_group_assignments=fabric_groups or None,
                per_fabric_stash=per_fabric_stash,
                allow_rotation=allow_rotation,
                one_way_fabric=one_way_fabric,
                block_key=block_key,
                measured_block=measured_block,
                seam_allowance_cm=seam_allowance_cm,
                hem_seam_allowance_cm=hem_seam_allowance_cm)
        size_payload = result.summary()
        # 各サイズに実際に使った採寸を返す。基準値だけでは、
        # 専用原型の肩幅・袖ぐりがS/M/Lで変化したかを画面から
        # 確認できない。
        size_payload["measurements"] = result.measurements.as_dict()
        db.record_job(result.job_id, owner_key, part_count=size_payload["part_count"],
                      waste_ratio=size_payload["waste_ratio"], project_name=project_name)
        # round41: ここには`"projector"`が**2回**書かれていた
        # (2つ目はインデントも崩れていた)。dictリテラルの重複キーは
        # 例外にならず後勝ちで潰れるので、値が同じだったこの箇所では
        # 実害が出ないまま残っていた。リンクの組み立ては1か所にする。
        size_payload["download"] = _download_links(result)
        results_payload[size] = size_payload

    # round49はここで「サイズ展開では裏地を引いていません」と
    # 断っていた。`generate_multi_size`がliningを受け取らなかった
    # からで、画面でも節ごと隠していた。round58でサイズ展開にも
    # 渡るようにしたので、断り書きは要らなくなった(画面の
    # 節も出す。web/static/app.js参照)。
    multi_notes = []
    # round58: 丈の指定は、サイズが変わっても指定どおりのままに
    # している。身幅はS/M/Lで変わるのに丈だけ変わらないのは、
    # 黙っていると「グレーディングが効いていない」と見える。
    if design_lengths:
        multi_notes.append(
            "丈の指定(" + "・".join(
                f"{DESIGN_LENGTH_LABELS.get(k, k)}{v:g}cm"
                for k, v in sorted(design_lengths.items())
                if k not in DESIGN_LENGTH_PAIRS.values())
            + ")は、どのサイズでも指定どおりの長さにしています。"
            "身幅・肩幅はサイズごとに変わりますが、丈は変えていません"
            "(サイズごとに丈も変えたい場合は、そのサイズだけ"
            "「手動でパーツを選ぶ」モードで作り直してください)。")

    return jsonify({
        "ok": True,
        "mode": mode,
        "project_name": project_name,
        "sizes": multi.sizes,
        "bundle_job_id": multi.bundle_job_id,
        "base_measurements": multi.base_measurements.as_dict(),
        "results": results_payload,
        "design_notes": multi_notes,
        "size_consistency_warnings": multi.size_consistency_warnings(),
        "grading_precision_notes": multi.grading_precision_notes(),
        "grade_cm_used": multi.effective_grade_cm(),
        "custom_grade_cm_applied": bool(multi.custom_grade_cm),
        # round69: 全サイズを合わせた「何枚刷るか・何を買うか」。
        # 同じ衣装を何人ぶんか作る人が、印刷代と買う量を見積もれるように。
        "totals": multi.totals(),
        "download": {"zip": f"/download/{multi.bundle_job_id}/zip"},
        "usage": {"plan": plan_name, "used_today": used_today, "daily_limit": daily_limit},
    })


def _respond_manual(inputs: GenerationInputs):
    """選んだパーツ構成で生成する。

    `api_generate`から呼ばれる。このモードが使う値は、下の数行で
    まとめて取り出している(24個)。
    """
    allow_rotation = inputs.allow_rotation
    accessory_3d = inputs.accessory_3d
    alterations = inputs.alterations
    block_key = inputs.block_key
    custom_panel_specs = inputs.custom_panel_specs
    costume_project = inputs.costume_project
    daily_limit = inputs.daily_limit
    design_lengths = inputs.design_lengths
    fabric_groups = inputs.fabric_groups
    fit = inputs.fit
    garment_spec_kwargs = inputs.garment_spec_kwargs
    hem_seam_allowance_cm = inputs.hem_seam_allowance_cm
    include_body_garment = inputs.include_body_garment
    lining = inputs.lining
    measurements = inputs.measurements
    measured_block = inputs.measured_block
    mode = inputs.mode
    one_way_fabric = inputs.one_way_fabric
    owner_key = inputs.owner_key
    pattern_repeat_cm = inputs.pattern_repeat_cm
    per_fabric_stash = inputs.per_fabric_stash
    plan_name = inputs.plan_name
    project_name = inputs.project_name
    seam_allowance_cm = inputs.seam_allowance_cm
    shrink_percent = inputs.shrink_percent
    spec = inputs.spec
    stash = inputs.stash
    used_today = inputs.used_today

    generation_kwargs = {
        "allow_rotation": allow_rotation,
        "seam_allowance_cm": seam_allowance_cm,
        "hem_seam_allowance_cm": hem_seam_allowance_cm,
        "fit": fit,          # 保存時に _fit_to_json で変換する
        "one_way_fabric": one_way_fabric,
        "shrink_percent": shrink_percent,
        "pattern_repeat_cm": pattern_repeat_cm,
        "alterations": alterations or None,
        "lining": costume_project.lining if costume_project else lining,
        "block_key": block_key,
        "measured_block": measured_block,
        "design_length_overrides": design_lengths or None,
        "fabric_group_assignments": fabric_groups or None,
        # round57: 白紙の面も印刷するか(既定は省く)。
        "include_empty_tiles": _bool_field(request.form, "include_empty_tiles"),
        # round57: 用紙(A4/A3)。コンビニのA3はA4と同じ単価で面積2倍。
        "paper": (request.form.get("paper") or "").strip() or None,
        # round74: 「この服は、出来上がりバスト◯cmの服の上に羽織る」。
        # 入れると、ゆとりの基準が素体から中に着る服へ移る
        # (engine/layering.py)。空欄なら従来どおり素体基準。
        "worn_over_bust_cm": (costume_project.worn_over_bust_cm if costume_project
                               else _parse_worn_over_bust_cm(request.form)),
        "worn_over_has_sleeves": _bool_field_default(
            request.form, "worn_over_has_sleeves", True),
        # round76: 「肩先を◯cm外へ出す」(ドロップショルダー)。
        # 入れると肩先が肩線の延長上へ出て、袖山が低くなる
        # (engine/drop_shoulder.py)。空欄なら従来どおり。
        "shoulder_drop_cm": (costume_project.shoulder_drop_cm if costume_project
                              else _parse_shoulder_drop_cm(request.form)),
    }
    result = pipeline.generate_from_selection(
        spec, measurements, **generation_kwargs)

    # round39: 手持ちの生地の判定。寸法を入れた人にだけ走らせる
    # (丈を変えた型紙を何通りも作り直すので、常に走らせるには重い)。
    if stash is not None:
        result.stash_verdict, result.stash_verdicts_by_fabric = _evaluate_stash(
            pipeline, result, spec, measurements, stash,
            allow_rotation=allow_rotation, one_way_fabric=one_way_fabric,
            fit=fit, seam_allowance_cm=seam_allowance_cm,
            hem_seam_allowance_cm=hem_seam_allowance_cm,
            block_key=block_key,
            measured_block=measured_block,
            fabric_group_assignments=fabric_groups or None,
            per_fabric_stash=per_fabric_stash)

    accessory_3d_result, vendor_package_result = _export_accessory_outputs(
        result, custom_panel_specs, accessory_3d)
    payload = result.summary()
    if accessory_3d_result:
        payload["accessory_3d"] = accessory_3d_result.as_dict()
        payload["accessory_3d"]["vendor_package"] = vendor_package_result.as_dict()
    if costume_project:
        payload["costume_project"] = costume_project.as_dict()
    regen_spec = {
        "mode": "manual",
        "project_name": project_name,
        "measurements": measurements.as_dict(),
        "garment_spec": garment_spec_kwargs,
        # round10で追加。既存(round10より前)の生成履歴にはこの2キーが
        # 無いが、regenerate_job側は.get()で既定値(True/[])を補うため、
        # 過去の生成履歴の再生成には影響しない。
        "include_body_garment": include_body_garment,
        "custom_panels": [
            {
                "label": s.label,
                "points_cm": [list(p) for p in s.points_cm],
                "quantity": s.quantity,
                "mirror": s.mirror,
                "allow_split": getattr(s, "allow_split", False),
                "replacement_part_type": getattr(s, "replacement_part_type", None),
                "seam_fit_confirmed": getattr(s, "seam_fit_confirmed", False),
                "grade_width_cm": getattr(s, "grade_width_cm", 0.0),
                "grade_height_cm": getattr(s, "grade_height_cm", 0.0),
            }
            for s in custom_panel_specs
        ],
        "construction": dict(spec.construction),
        "accessory_3d": accessory_3d,
        "allow_rotation": allow_rotation,
        "seam_allowance_cm": seam_allowance_cm,
        "hem_seam_allowance_cm": hem_seam_allowance_cm,
        # round55: 再生成で渡し直す設定一式(上のdocstring参照)。
        # 古い履歴にはこのキーが無いので、再生成側は
        # 従来の3つだけを読む形に落ちる(挙動は変わらない)。
        "generation_kwargs": {**generation_kwargs,
                               "fit": _fit_to_json(generation_kwargs["fit"])},
    }
    db.record_job(result.job_id, owner_key, part_count=payload["part_count"],
                  waste_ratio=payload["waste_ratio"], spec_json=json.dumps(regen_spec),
                  project_name=project_name)
    payload["project_name"] = project_name
    payload["download"] = _download_links(result)
    payload["classification_log"] = [
        {"part_type": c.part_type, "variation": c.variation, "confidence": round(c.confidence, 2),
         "mode": (c.raw or {}).get("mode", "claude")}
        for c in result.classification_log
    ]
    payload["usage"] = {"plan": plan_name, "used_today": used_today, "daily_limit": daily_limit}
    return jsonify({"ok": True, "mode": mode, **payload})


def _api_generate_impl():
    if not _generate_rate_limiter.allow(_client_key()):
        return jsonify({"ok": False, "error": "リクエストが多すぎます。しばらく待って再試行してください。"}), 429

    _cleanup_old_outputs_throttled()

    # 生成処理(イラストモードのAI判定・ネスティング等)が失敗した場合に、
    # 既に加算した利用回数を取り消す(refund)必要があるかどうかの目印。
    # 実際に見つかった不具合(store.Store.refund_usageのdocstring参照)の
    # 修正で使う: 以前はcheck_and_increment_usage()が実際の生成処理より前に
    # 呼ばれているため、生成そのものが失敗しても利用回数は減らなかった。
    _usage_owner_key: str | None = None
    _usage_day: str | None = None
    try:
        measurements = _parse_measurements(request.form)
        project_name = _parse_project_name(request.form)
        mode = request.form.get("mode", "manual")
        allow_rotation = _bool_field(request.form, "allow_rotation")
        one_way_fabric, shrink_percent, pattern_repeat_cm = \
            _parse_fabric_shopping_fields(request.form)
        stash = _parse_stash_fields(request.form)
        per_fabric_stash = _parse_stash_per_fabric(request.form)
        alterations = _parse_alteration_fields(request.form)
        # round52: 丈の直接指定(キャラクターの衣装は丈でシルエットが決まる)。
        design_lengths = _parse_design_lengths(request.form)
        fabric_groups = _parse_fabric_groups(request.form)
        # round41: 裏地の型紙も一緒に出すか(engine/lining.py)。
        lining = _bool_field(request.form, "lining")
        lining_scope = request.form.getlist("lining_scope") if lining else []
        allowed_lining_scope = {
            "front_bodice", "back_bodice", "sleeve", "skirt",
            "front_pants", "back_pants",
        }
        unknown_lining_scope = sorted(set(lining_scope) - allowed_lining_scope)
        if unknown_lining_scope:
            raise ValueError("裏地の対象部位が不正です。画面から選び直してください。")
        # round42: どの原型で引くか(engine/blocks.py)。知らないキーは
        # get_block()が明確なエラーにする(黙って大人に落とさない)。
        block_key = (request.form.get("block") or "").strip() or None
        measured_block = _parse_measured_block(request.form, block_key)
        if measured_block is None:
            get_block(block_key)
        seam_allowance_cm, hem_seam_allowance_cm = _parse_seam_allowance_fields(request.form)

        image = None
        spec = None
        # round63: モードによっては決まらない値。ここで既定を置いておく
        # ——下で`GenerationInputs`に束ねるとき、どのモードでも参照するため
        # (イラストモードでは`garment_spec_kwargs`が、手動モードでは
        #  `illustration_views`が、それぞれ決まらない)。
        illustration_views: list[str] | None = None
        illustration_corrections: dict[str, object] | None = None
        illustration_stage = "production"
        garment_spec_kwargs: dict | None = None
        sizes: list[str] | None = None
        custom_grade_cm: dict[str, float] | None = None
        # round10で追加: 「定型に当てはまらない自由形状パーツ」(custom_panel、
        # engine/custom_panel.py参照)関連の状態。illustration/multi_sizeの
        # 分岐では使わない(未対応、下記参照)ため既定値のまま。
        include_body_garment = True
        custom_panel_specs: list[CustomPanelSpec] = []
        accessory_3d = None
        costume_project = get_costume_project(
            (request.form.get("costume_project") or "").strip(), measurements)
        if costume_project and mode != "manual":
            raise ValueError("衣装プリセットは「手動でパーツを選ぶ」モードで使用してください。")
        # round24: ゆとり(着方)の選択。未指定は既定("standard")で、
        # round23までとまったく同じ寸法になる。未知の値は
        # engine/part_specs.pyのfit_easeが明確なエラーにする(黙って標準に
        # 落とすと、指定したつもりのゆとりが効いていないことに気付けない)。
        fit = _parse_fit(request.form, measurements)
        if mode == "illustration":
            # round18: 複数枚に対応。同じ衣装の別カットを渡すと、パーツ構成は
            # 全枚の和を取り、丈・広がりは枚ごとに読んで中央値を使う
            # (engine/pipeline.pyのgenerate_from_illustration参照)。
            # round21: 「後ろから見た絵」を別の入力欄で受け取る。前後で
            # 襟ぐりが違うデザインを、後身頃側にも反映するため
            # (engine/pipeline.pyのgenerate_from_illustrationのdocstring参照)。
            # 従来の"illustration"欄だけを使えばround20までとまったく同じ動き。
            front_uploads = [f for f in request.files.getlist("illustration") if f and f.filename]
            back_uploads = [f for f in request.files.getlist("illustration_back") if f and f.filename]
            side_uploads = [f for f in request.files.getlist("illustration_side") if f and f.filename]
            detail_uploads = [f for f in request.files.getlist("illustration_detail") if f and f.filename]
            uploads = front_uploads + back_uploads + side_uploads + detail_uploads
            illustration_views = (["front"] * len(front_uploads)
                                   + ["back"] * len(back_uploads)
                                   + ["side"] * len(side_uploads)
                                   + ["detail"] * len(detail_uploads))
            if not uploads:
                # イラストモードを選んだのにファイルが無い場合、手動モードの
                # デフォルト選択で黙って生成してしまうと「イラストを見て
                # くれなかった」ことに利用者が気づけない。明確なエラーにする。
                raise ValueError("イラストモードが選択されていますが、画像がアップロードされていません。")
            if not front_uploads:
                # round51: 後ろ姿の絵だけでも、上の `not uploads` は通って
                # しまっていた。後ろの絵は**補助**(「指定すると、後身頃の
                # 襟ぐりを後ろ姿の絵から読み取ります」)であって、前身頃・袖・
                # スカートは前の絵から読む。後ろだけ渡すと、**前身頃が
                # 既定のまま黙って生成される**——上のコメントが防ごうとした
                # 「イラストを見てくれなかったことに気づけない」が、
                # そのまま起きていた。実測で 200・パーツ6枚が返っていた。
                raise ValueError(
                    "補助資料だけが選ばれています。"
                    "前から見た絵は必ず指定してください"
                    "(後ろ・側面・装飾拡大は補助資料です)。")
            if len(uploads) > MAX_ILLUSTRATION_IMAGES:
                raise ValueError(
                    f"イラストは一度に{MAX_ILLUSTRATION_IMAGES}枚までです"
                    f"（{len(uploads)}枚が選択されています）。"
                )
            image = [_load_uploaded_image(f) for f in uploads]

            illustration_stage = (request.form.get("illustration_stage")
                                  or "production").strip()
            if illustration_stage not in {"production", "draft"}:
                raise ValueError("画像生成の段階は「製作用」または「ラフ確認」を選んでください。")

            # 画像に写らない／ラフでは判別しづらい構造だけを、人が確認して
            # 上書きできる。"auto" は辞書に入れず、自動判定をそのまま使う。
            illustration_corrections = {}
            front_neckline = (request.form.get("illustration_neckline") or "auto").strip()
            back_neckline = (request.form.get("illustration_back_neckline") or "auto").strip()
            sleeve_style = (request.form.get("illustration_sleeve_style") or "auto").strip()
            skirt_style = (request.form.get("illustration_skirt_style") or "auto").strip()
            pants_style = (request.form.get("illustration_pants_style") or "auto").strip()
            collar_style = (request.form.get("illustration_collar_style") or "auto").strip()
            cuffs_style = (request.form.get("illustration_cuffs_style") or "auto").strip()
            waistband_style = (request.form.get("illustration_waistband_style") or "auto").strip()
            hood = (request.form.get("illustration_hood") or "auto").strip()
            if front_neckline != "auto":
                illustration_corrections["neckline"] = front_neckline
            if back_neckline != "auto":
                illustration_corrections["back_neckline"] = back_neckline
            if sleeve_style != "auto":
                illustration_corrections["sleeve_style"] = None if sleeve_style == "none" else sleeve_style
            if skirt_style != "auto":
                illustration_corrections["skirt_style"] = None if skirt_style == "none" else skirt_style
            for field_value, key in (
                (pants_style, "pants_style"), (collar_style, "collar_style"),
                (cuffs_style, "cuffs_style"), (waistband_style, "waistband_style"),
            ):
                if field_value != "auto":
                    illustration_corrections[key] = (
                        None if field_value == "none"
                        else "" if field_value == "default"
                        else field_value)
            if hood != "auto":
                illustration_corrections["hood"] = hood == "yes"
            closure = (request.form.get("illustration_closure") or "auto").strip()
            if closure != "auto":
                illustration_corrections["closure"] = closure
            closure_length = (request.form.get("illustration_closure_length_cm") or "").strip()
            if closure_length:
                illustration_corrections["closure_length_cm"] = closure_length
            closure_count = (request.form.get("illustration_closure_count") or "").strip()
            closure_spacing = (request.form.get("illustration_closure_spacing_cm") or "").strip()
            closure_overlap = (request.form.get("illustration_closure_overlap_cm") or "").strip()
            if closure_count:
                illustration_corrections["closure_count"] = closure_count
            if closure_spacing:
                illustration_corrections["closure_spacing_cm"] = closure_spacing
            if closure_overlap:
                illustration_corrections["closure_overlap_cm"] = closure_overlap
            if _bool_field(request.form, "illustration_front_zip"):
                illustration_corrections["front_zip"] = True
            if _bool_field(request.form, "illustration_princess_line"):
                illustration_corrections["princess_line"] = True
            for form_name, correction_name in (
                ("illustration_symmetry", "symmetry"),
                ("illustration_internal_support", "internal_support"),
                ("illustration_movement", "movement"),
            ):
                value = (request.form.get(form_name) or "auto").strip()
                if value != "auto":
                    illustration_corrections[correction_name] = value
            petticoat_style = (request.form.get("illustration_petticoat_style") or "").strip()
            petticoat_tiers = (request.form.get("illustration_petticoat_tier_count") or "").strip()
            petticoat_length = (request.form.get("illustration_petticoat_length_cm") or "").strip()
            petticoat_fullness = (request.form.get("illustration_petticoat_fullness_ratio") or "").strip()
            petticoat_diameters = (request.form.get("illustration_petticoat_hoop_diameters_cm") or "").strip()
            if petticoat_style:
                illustration_corrections["petticoat_style"] = petticoat_style
            if petticoat_tiers:
                illustration_corrections["petticoat_tier_count"] = petticoat_tiers
            if petticoat_length:
                illustration_corrections["petticoat_length_cm"] = petticoat_length
            if petticoat_fullness:
                illustration_corrections["petticoat_fullness_ratio"] = petticoat_fullness
            if petticoat_diameters:
                try:
                    illustration_corrections["petticoat_hoop_diameters_cm"] = [
                        float(value.strip()) for value in petticoat_diameters.split(",")
                        if value.strip()
                    ]
                except ValueError as exc:
                    raise ValueError("ワイヤー輪直径は半角カンマ区切りの数値で入力してください。") from exc
            layer_count = (request.form.get("illustration_layer_count") or "1").strip()
            if layer_count != "1":
                illustration_corrections["layer_count"] = layer_count
            layer_lengths = (request.form.get("illustration_layer_lengths_cm") or "").strip()
            if layer_lengths:
                try:
                    illustration_corrections["layer_lengths_cm"] = [
                        float(value.strip()) for value in layer_lengths.split(",")
                        if value.strip()
                    ]
                except ValueError as exc:
                    raise ValueError(
                        "層ごとの丈は半角カンマ区切りの数値で入力してください。"
                        "例: 80,65,50") from exc
            gather_ratio = (request.form.get("illustration_gather_ratio") or "").strip()
            if gather_ratio:
                illustration_corrections["gather_ratio"] = gather_ratio
            pleat_count = (request.form.get("illustration_pleat_count") or "").strip()
            if pleat_count:
                illustration_corrections["pleat_count"] = pleat_count
            pleat_depth = (request.form.get("illustration_pleat_depth_cm") or "").strip()
            if pleat_depth:
                illustration_corrections["pleat_depth_cm"] = pleat_depth
            slit_position = (request.form.get("illustration_slit_position") or "none").strip()
            slit_length = (request.form.get("illustration_slit_length_cm") or "").strip()
            if slit_position != "none" or slit_length:
                illustration_corrections["slit_position"] = slit_position
                illustration_corrections["slit_length_cm"] = slit_length
            motif_position = (request.form.get("illustration_motif_position") or "none").strip()
            motif_width = (request.form.get("illustration_motif_width_cm") or "").strip()
            motif_height = (request.form.get("illustration_motif_height_cm") or "").strip()
            if motif_position != "none" or motif_width or motif_height:
                illustration_corrections["motif_position"] = motif_position
                illustration_corrections["motif_width_cm"] = motif_width
                illustration_corrections["motif_height_cm"] = motif_height
                motif_image = request.files.get("illustration_motif_image")
                if motif_image and motif_image.filename:
                    motif_outline, motif_regions = _trace_normalized_motif_data(motif_image)
                    illustration_corrections["motif_outline_normalized"] = motif_outline
                    if motif_regions:
                        illustration_corrections["motif_regions_normalized"] = motif_regions
            construction_note = (request.form.get("illustration_construction_note") or "").strip()
            if construction_note:
                illustration_corrections["construction_note"] = construction_note
            # 左右非対称の本番型紙は、同一型紙の反転では作れない。確認ゲートの
            # 前に左右別の自由輪郭を解析し、実在する2形状があるかまで確かめる。
            raw_custom_panels_json = (request.form.get("custom_panels_json") or "").strip()
            if _has_custom_panels(raw_custom_panels_json):
                custom_panel_specs.extend(
                    _parse_custom_panels(raw_custom_panels_json, measurements))
            # 画像だけでは縫製構造を確定できない。自動判定のまま残した項目を
            # 仕様書へ引き継ぎ、「確認済み」と誤表示しない。
            unconfirmed_fields = [
                label for value, label in (
                    (front_neckline, "前の襟ぐりを確認してください"),
                    (back_neckline, "後ろの襟ぐりを確認してください"),
                    (sleeve_style, "袖の有無・形を確認してください"),
                    (skirt_style, "スカートの有無・形を確認してください"),
                    (pants_style, "パンツの有無・形を確認してください"),
                    (collar_style, "衿の有無・形を確認してください"),
                    (cuffs_style, "カフスの有無・形を確認してください"),
                    (waistband_style, "ウエストベルトの有無・形を確認してください"),
                    (hood, "フードの有無を確認してください"),
                    (closure, "開閉方法を確認してください"),
                    ((request.form.get("illustration_symmetry") or "auto").strip(),
                     "左右対称・非対称を確認してください"),
                    ((request.form.get("illustration_internal_support") or "auto").strip(),
                     "芯材・ボーン等の内部構造を確認してください"),
                    ((request.form.get("illustration_movement") or "auto").strip(),
                     "着用時の動作量を確認してください"),
                ) if value == "auto"
            ]
            if unconfirmed_fields:
                illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if closure in {"back_zip", "side_zip"} and not closure_length:
                unconfirmed_fields.append("ファスナーの開き長を確認してください")
                illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if closure in {"hooks", "snaps"}:
                missing = []
                if not closure_count:
                    missing.append("個数")
                if not closure_spacing:
                    missing.append("間隔")
                if closure == "snaps" and not closure_overlap:
                    missing.append("重なり量")
                if missing:
                    unconfirmed_fields.append(
                        "ホック／スナップの" + "・".join(missing)
                        + "を確認してください")
                    illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if pleat_count and not pleat_depth:
                unconfirmed_fields.append("プリーツのひだ深さを確認してください")
                illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            support_value = (request.form.get("illustration_internal_support") or "auto").strip()
            if support_value == "interfacing":
                interfacing_targets = [value.strip() for value in
                                       request.form.getlist("illustration_interfacing_targets")
                                       if value.strip()]
                interfacing_inset = (request.form.get(
                    "illustration_interfacing_inset_cm") or "0").strip()
                illustration_corrections["interfacing_targets"] = interfacing_targets
                illustration_corrections["interfacing_inset_cm"] = interfacing_inset
                if not interfacing_targets:
                    unconfirmed_fields.append("接着芯を貼る部位を確認してください")
                    illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if support_value == "petticoat":
                missing = []
                if petticoat_style not in {"soft", "hoop"}:
                    missing.append("方式")
                if not petticoat_tiers:
                    missing.append("段数")
                if not petticoat_length:
                    missing.append("丈")
                if petticoat_style == "soft" and not petticoat_fullness:
                    missing.append("段倍率")
                if petticoat_style == "hoop" and not petticoat_diameters:
                    missing.append("輪直径")
                if missing:
                    unconfirmed_fields.append(
                        "パニエの" + "・".join(missing) + "を確認してください")
                    illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if support_value == "armor_base" and not custom_panel_specs:
                unconfirmed_fields.append(
                    "造形物用の土台輪郭をカスタムパーツでトレースしてください")
                illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            symmetry = (request.form.get("illustration_symmetry") or "auto").strip()
            if symmetry == "asymmetric":
                distinct_shapes = {repr(panel.points_cm)
                                   for panel in custom_panel_specs}
                if len(distinct_shapes) < 2:
                    unconfirmed_fields.append(
                        "左右非対称は左側・右側それぞれの異なる輪郭を2件以上"
                        "トレースしてください")
                    illustration_corrections["unconfirmed_fields"] = unconfirmed_fields
            if illustration_stage == "production" and unconfirmed_fields:
                raise ValueError(
                    "製作用データを出すには、自動判定のままの項目をすべて確認してください: "
                    + "／".join(unconfirmed_fields)
                    + "。まだ決められない場合は「ラフ確認」を選べますが、"
                      "その場合は裁断用PDF・DXF・STLを出しません。")
            if illustration_stage == "draft":
                illustration_corrections["draft_mode"] = True
            illustration_corrections = illustration_corrections or None
            # 左右非対称、ケープ、翼、装甲などの自由輪郭は、上の製作可否
            # チェック前に解析済み。校正済みcmなのでAI側の再スケーリングはしない。
        else:
            # round8で追加: 生成履歴からの再生成機能のため、build_garment_spec
            # に渡す引数をそのままJSONに保存できる辞書として先に組み立てる
            # (下のdb.record_job呼び出し参照)。イラストモードはアップロード
            # 画像自体を保持しないため対象外(この辞書はmode!="illustration"
            # の場合にのみ構築される)。
            garment_spec_kwargs = {
                "neckline": request.form.get("neckline", "round_neck"),
                "sleeve_style": (request.form.get("sleeve_style") or None),
                "skirt_style": (request.form.get("skirt_style") or None),
                "front_zip": _bool_field(request.form, "front_zip"),
                "include_pants": _bool_field(request.form, "include_pants"),
                "pants_style": request.form.get("pants_style", ""),
                "include_collar": _bool_field(request.form, "include_collar"),
                "collar_style": request.form.get("collar_style", ""),
                "include_cuffs": _bool_field(request.form, "include_cuffs"),
                "cuffs_style": request.form.get("cuffs_style", ""),
                "include_waistband": _bool_field(request.form, "include_waistband"),
                "waistband_style": request.form.get("waistband_style", ""),
                # round30: 身頃を切り替え線(プリンセスライン)で分割するか。
                "princess_line": _bool_field(request.form, "princess_line"),
            }
            if costume_project:
                # プリセットは市販衣装のような一式を対象に、検証済みの構成を
                # 強制する。フォームの古い選択が混ざり、別の衣装になったまま
                # 「管理人」と表示されることを避ける。
                garment_spec_kwargs.update(costume_project.garment_spec_kwargs)
                lining = costume_project.lining
            raw_custom_panels_json = (request.form.get("custom_panels_json") or "").strip()
            # round32で直した実バグ: この欄の**既定値は文字列 "[]"** で、
            # カスタムパーツを1つも作っていなくても空文字にはならない
            # (web/static/app.jsの`validateCustomPanelsBeforeSubmit`が、
            #  手動モード以外では明示的に "[]" を書き戻す)。ところが判定が
            # 文字列の真偽値だったため、**サイズ展開モードを選んで生成する
            # だけで**「カスタムパーツ(自由形状)は現在、サイズ展開モードでは
            # 併用できません」という、まったく身に覚えのないエラーが出た
            # (実際にブラウザで操作して発見。サイズ展開モードが事実上
            #  まったく使えない状態だった)。中身が空の配列かどうかで見る。
            has_custom_panels = _has_custom_panels(raw_custom_panels_json)
            if mode == "multi_size":
                if has_custom_panels:
                    custom_panel_specs.extend(
                        _parse_custom_panels(raw_custom_panels_json, measurements))
                spec = build_garment_spec(**garment_spec_kwargs)
                if custom_panel_specs:
                    spec.parts = merge_custom_panel_requests(
                        spec.parts, _custom_panel_specs_to_requests(custom_panel_specs),
                        princess_line=spec.princess_line)
                sizes = request.form.getlist("sizes")
                if not sizes:
                    raise ValueError(
                        "サイズ展開モードでは、生成するサイズを1つ以上選択してください。"
                    )
                # round7で追加。空欄なら従来通り既定のグレーディングルール
                # (STANDARD_SIZE_GRADE_CM)のまま生成する。
                custom_grade_cm = _parse_custom_grade_cm(request.form)
            else:
                # round10で追加: 「体にフィットする本体パーツ(身頃等)」を
                # 含めるかどうか。未指定(既定)なら従来通りTrue(含める)。
                # マント・翼・装甲プレートのような小道具だけをカスタムパーツ
                # として作りたい場合(本体の服は別に用意する/既に持っている)
                # にFalseを指定する(round10のAskUserQuestion「両方お願い」
                # ＝標準の本体パーツとの併用も、カスタムパーツ単独も両方
                # 対応する、という回答に基づく)。
                include_body_garment = (True if costume_project else
                                        _bool_field_default(request.form, "include_body_garment", True))
                spec = build_garment_spec(**garment_spec_kwargs) if include_body_garment else GarmentSpec(parts=[])
                if costume_project:
                    custom_panel_specs.extend(costume_project.custom_panel_specs)
                if has_custom_panels:
                    custom_panel_specs.extend(
                        _parse_custom_panels(raw_custom_panels_json, measurements))
                if custom_panel_specs:
                    spec.parts = merge_custom_panel_requests(
                        spec.parts,
                        _custom_panel_specs_to_requests(custom_panel_specs),
                        princess_line=spec.princess_line)
                if not spec.parts:
                    raise ValueError(
                        "生成するパーツがありません。本体パーツを含めるか、"
                        "カスタムパーツを1つ以上追加してください。"
                    )

        # 対象が未選択なら従来どおり総裏。選択があれば部分裏として、同じ
        # GarmentSpecに保存するので手動・画像・サイズ展開・再生成で共通に効く。
        if lining_scope:
            if spec is not None:
                spec.construction["lining_scope"] = list(lining_scope)
            if illustration_corrections is not None:
                illustration_corrections["lining_scope"] = list(lining_scope)

        if _bool_field(request.form, "generate_accessory_stl"):
            if mode not in {"manual", "illustration"}:
                raise ValueError("3D小物のSTL出力は手動または画像モードで使用してください。")
            if not custom_panel_specs:
                raise ValueError(
                    "3D小物を出力するには、カスタムパーツを1つ以上追加してください。")
            if mode == "illustration" and illustration_stage == "draft":
                raise ValueError(
                    "ラフ確認ではSTLを出力できません。画像の確認項目を確定し、"
                    "「製作用データを作る」を選んでください。")
            thickness, bed_width, bed_depth = validate_accessory_settings(
                request.form.get("accessory_thickness_mm", "3"),
                request.form.get("accessory_bed_width_mm", "220"),
                request.form.get("accessory_bed_depth_mm", "220"),
            )
            curvature_radius, curvature_height_radius, curve_axis = \
                validate_compound_curvature_settings(
                request.form.get("accessory_curvature_radius_mm"),
                request.form.get("accessory_curvature_radius_height_mm"),
                request.form.get("accessory_curve_axis") or "width",
            )
            material_profile, finish_note = normalize_order_options(
                request.form.get("accessory_material_profile") or "consult",
                request.form.get("accessory_finish_note") or "業者と相談",
            )
            hole_pattern, hole_diameter, hole_inset = validate_mounting_holes(
                request.form.get("accessory_mounting_hole_pattern") or "none",
                request.form.get("accessory_mounting_hole_diameter_mm"),
                request.form.get("accessory_mounting_hole_inset_mm"),
            )
            (attachment_interface, attachment_pattern,
             attachment_diameter, attachment_inset) = validate_attachment_interface(
                request.form.get("accessory_attachment_interface") or "none",
                request.form.get("accessory_attachment_hole_diameter_mm"),
                request.form.get("accessory_attachment_hole_inset_mm"),
            )
            if attachment_interface != "none":
                if hole_pattern != "none":
                    raise ValueError(
                        "取付金具インターフェースと汎用の丸穴は同時に指定できません。"
                        "金具用の穴は自動で作られます。")
                hole_pattern, hole_diameter, hole_inset = (
                    attachment_pattern, attachment_diameter, attachment_inset)
            slot_pattern, slot_length, slot_width, slot_axis, slot_inset = \
                validate_mounting_slots(
                    request.form.get("accessory_mounting_slot_pattern") or "none",
                    request.form.get("accessory_mounting_slot_length_mm"),
                    request.form.get("accessory_mounting_slot_width_mm"),
                    request.form.get("accessory_mounting_slot_axis") or "width",
                    request.form.get("accessory_mounting_slot_inset_mm"),
                )
            magnet_pattern, magnet_diameter, magnet_depth, magnet_inset = \
                validate_magnet_pockets(
                    request.form.get("accessory_magnet_pocket_pattern") or "none",
                    request.form.get("accessory_magnet_pocket_diameter_mm"),
                    request.form.get("accessory_magnet_pocket_depth_mm"),
                    request.form.get("accessory_magnet_pocket_inset_mm"),
                    thickness,
                )
            accessory_3d = {
                "thickness_mm": thickness,
                "bed_width_mm": bed_width,
                "bed_depth_mm": bed_depth,
                "curvature_radius_mm": curvature_radius,
                "curvature_radius_height_mm": curvature_height_radius,
                "curve_axis": curve_axis,
                "material_profile": material_profile,
                "finish_note": finish_note,
                "mounting_hole_pattern": hole_pattern,
                "mounting_hole_diameter_mm": hole_diameter,
                "mounting_hole_inset_mm": hole_inset,
                "mounting_slot_pattern": slot_pattern,
                "mounting_slot_length_mm": slot_length,
                "mounting_slot_width_mm": slot_width,
                "mounting_slot_axis": slot_axis,
                "mounting_slot_inset_mm": slot_inset,
                "magnet_pocket_pattern": magnet_pattern,
                "magnet_pocket_diameter_mm": magnet_diameter,
                "magnet_pocket_depth_mm": magnet_depth,
                "magnet_pocket_inset_mm": magnet_inset,
                "attachment_interface": attachment_interface,
            }

        # 入力検証(採寸値・パーツ構成の組み合わせ・画像の妥当性)を通過した
        # リクエストだけを1回分の利用回数として数える。単純な入力ミスで
        # 400になったリクエストまで課金対象にすると利用者体験が悪い。
        owner_key = _current_owner_key()
        plan_name = _current_plan_name()
        daily_limit = _daily_limit_for_plan(plan_name)
        allowed, used_today = db.check_and_increment_usage(owner_key, daily_limit, _today_str())
        if not allowed:
            return jsonify({
                "ok": False,
                "error": f"本日の生成回数の上限（{daily_limit}回/日、{_plan_display_name(plan_name)}）"
                          "に達しました。プランをアップグレードすると上限が上がります。",
                "upgrade_url": url_for("pricing"),
            }), 429
        # ここまで到達した時点で利用回数は加算済み。これより下で失敗した場合は
        # except側でrefund_usage()を呼んで取り消す必要があるため記録しておく。
        _usage_owner_key, _usage_day = owner_key, _today_str()

        # ここまでで読み取った値を1つに束ね、モードごとの関数へ渡す。
        inputs = GenerationInputs(
            allow_rotation=allow_rotation,
            accessory_3d=accessory_3d,
            alterations=alterations,
            block_key=block_key,
            custom_grade_cm=custom_grade_cm,
            custom_panel_specs=custom_panel_specs,
            costume_project=costume_project,
            daily_limit=daily_limit,
            design_lengths=design_lengths,
            fabric_groups=fabric_groups,
            fit=fit,
            garment_spec_kwargs=garment_spec_kwargs,
            hem_seam_allowance_cm=hem_seam_allowance_cm,
            illustration_views=illustration_views,
            illustration_corrections=illustration_corrections,
            illustration_stage=illustration_stage,
            image=image,
            include_body_garment=include_body_garment,
            lining=lining,
            measurements=measurements,
            measured_block=measured_block,
            mode=mode,
            one_way_fabric=one_way_fabric,
            owner_key=owner_key,
            pattern_repeat_cm=pattern_repeat_cm,
            per_fabric_stash=per_fabric_stash,
            plan_name=plan_name,
            project_name=project_name,
            seam_allowance_cm=seam_allowance_cm,
            shrink_percent=shrink_percent,
            sizes=sizes,
            spec=spec,
            stash=stash,
            used_today=used_today,
        )
        if mode == "illustration":
            return _respond_illustration(inputs)
        if mode == "multi_size":
            return _respond_multi_size(inputs)
        return _respond_manual(inputs)
    except ValueError as exc:
        # 実際に見つかった不具合の修正(store.Store.refund_usageのdocstring
        # 参照): イラストからパーツ領域/パーツ種を判定できなかった場合等、
        # 利用回数の加算より後で発生するValueErrorも「単純な入力ミス」と
        # 同じ理由で課金対象にすべきでないため、加算済みなら取り消す。
        if _usage_owner_key is not None:
            db.refund_usage(_usage_owner_key, _usage_day)
        return jsonify({"ok": False, "error": str(exc)}), 400
    except RequestEntityTooLarge:
        # 送信データが大きすぎるのはクライアント側の入力ミスであり、
        # 「内部エラー」として500を返すのは誤解を招く。413で明確に伝える。
        # (この例外は_load_uploaded_imageより前、Flask自体のリクエスト
        # サイズ制限で発生するため、この時点では利用回数はまだ加算されていない。)
        #
        # 【round37で直した文言】以前は「アップロードされた**画像**が
        # 大きすぎます」と決め打ちしていた。だがこの上限に当たるのは画像
        # だけではない——round9で入れたカスタムパーツの輪郭は、頂点の列を
        # フォームの値(custom_panels_json)として送るので、細かい輪郭や
        # パーツを増やせばここに当たる。実測(round37)では、画像を1枚も
        # 添付していないのに「画像が大きすぎます」と返っていた。
        # 言われた側は直しようがないので、実際の大きさと、考えられる原因の
        # 両方を挙げる。
        return jsonify({"ok": False, "error": _too_large_message()}), 413
    except Exception as exc:  # 想定外の例外もJSONで返し、フロント側で表示できるようにする
        if _usage_owner_key is not None:
            db.refund_usage(_usage_owner_key, _usage_day)
        # 以前は str(exc) をそのままクライアントに返していたため、ライブラリ
        # 内部のエラー文字列やファイルパスが有料顧客に漏れる恐れがあった上、
        # 全ての異なるバグが同一の汎用メッセージに潰れ、サポート側がログと
        # 紐付けられなかった。エラーIDを発行してサーバー側ログにはフルの
        # 例外情報を残し、クライアントにはIDだけを返す。
        error_id = uuid.uuid4().hex[:8]
        app.logger.exception("pattern generation failed [error_id=%s]", error_id)
        return jsonify({
            "ok": False,
            "error": f"内部エラーが発生しました（エラーID: {error_id}）。"
                      "しばらく待って再試行するか、このIDをサポートにお伝えください。",
        }), 500


@app.post("/api/generate")
def api_generate():
    """画面からの生成要求を、入力解析とモード別処理へ引き渡す。"""
    return _api_generate_impl()


@app.get("/download/<job_id>/<fmt>")
def download(job_id: str, fmt: str):
    if not _download_rate_limiter.allow(_client_key()):
        return jsonify({"ok": False, "error": "リクエストが多すぎます。しばらく待って再試行してください。"}), 429
    # round39: projector = プロジェクター投影用の実寸1枚ものPDF。
    # ファイル名だけ `<job_id>_projector.pdf` と別なので、下で読み替える。
    if not _JOB_ID_RE.match(job_id) or fmt not in _DOWNLOAD_FORMATS:
        # round51: ブラウザには画面を返す。リンクが途中で切れたブックマークや
        # 打ち間違いでもここへ来るので、生のJSONを見せない
        # (下の `_download_not_found` のdocstring参照)。
        if not (request.path.startswith("/api/")
                or request.accept_mimetypes["application/json"]
                > request.accept_mimetypes["text/html"]):
            return render_template("404.html"), 400
        return jsonify({"ok": False, "error": "invalid request"}), 400

    # 以前はjob_id(12桁16進数)を知っているだけで誰でもダウンロードできた。
    # job_idはプレビューリンクのReferer等で漏れうるうえ、body測定値から
    # 生成された個人性のあるファイルなので、生成したセッション/アカウント
    # 以外からはアクセスできないようにする。存在しない場合と所有者が違う
    # 場合を同じ404にすることで、他人のjob_idが存在するかどうかを外部から
    # 探索できないようにしている。
    job_owner = db.get_job_owner(job_id)
    if job_owner is None or job_owner != _current_owner_key():
        return _download_not_found()

    filename = _DOWNLOAD_FORMATS[fmt].format(job_id=job_id)
    if not os.path.isfile(os.path.join(OUTPUT_DIR, filename)):
        # 持ち主は合っているのにファイルが無い＝保存期間を過ぎて消えた。
        return _download_not_found(expired=True)

    response = send_from_directory(
        OUTPUT_DIR, filename,
        as_attachment=not filename.endswith(".svg"))
    # 顧客の身体測定値に由来するファイルなので、共有プロキシ/CDN等に
    # キャッシュされて別の利用者に渡ってしまうことを防ぐ。
    response.headers["Cache-Control"] = "private, no-store"
    if filename.endswith(".svg"):
        # SVGはブラウザで直接開くと埋め込みscriptを実行できてしまう。今は
        # SVG内に利用者が持ち込んだ自由文字列は含まれないため実害は無いが、
        # 将来自由入力欄が増えたときのために、このレスポンスに対する
        # スクリプト実行・フォーム送信等を無効化しておく。
        response.headers["Content-Security-Policy"] = "sandbox"
    return response


# ---------------------------------------------------------------------------
# アカウント・プラン（テスト実装。モジュールdocstring参照）
# ---------------------------------------------------------------------------

@app.get("/signup")
def signup():
    if _current_user():
        return redirect(url_for("account"))
    return render_template("signup.html")


@app.post("/signup")
def signup_submit():
    email = request.form.get("email", "")
    password = request.form.get("password", "")
    try:
        user_id = db.create_user(email, password)
    except (ValueError, store.EmailAlreadyRegisteredError) as exc:
        flash(str(exc), "error")
        return render_template("signup.html", email=email), 400

    _adopt_anonymous_jobs_into_account(user_id)
    _login_session_start(db.get_user(user_id))
    flash("登録しました。", "success")
    _send_verification_email(user_id, email)
    return redirect(url_for("account"))


def _deliver_verification_email(email: str, token: str) -> None:
    """既に発行済みのverifyトークンでメールを送る(送信部分のみ)。

    サインアップ直後(クールダウン確認不要、常に新規トークンを発行)と、
    再送(`/account/resend-verification`。クールダウン確認込みでトークンを
    発行する必要がある)の両方から、トークン発行の方法だけを差し替えて
    使えるように送信部分だけを分離している。
    """
    verify_url = url_for("verify_email", token=token, _external=True)
    try:
        mail.send(
            email,
            "PatternForge — メールアドレスの確認",
            f"以下のURLをクリックしてメールアドレスを確認してください（{store.EMAIL_VERIFY_TOKEN_TTL_SECONDS // 3600}時間有効）:\n{verify_url}",
        )
    except Exception:  # pragma: no cover - メール送信基盤の障害でサインアップ自体は失敗させない
        app.logger.exception("failed to send verification email")
    if mail.is_console:
        # 開発時のフォールバック: SMTPが未設定のため実際にはメールが届かない。
        # フローを最後まで試せるよう、確認用URLを画面にも表示する。
        flash(f"[開発用] 確認メールは送信されていません。このURLで確認できます: {verify_url}", "success")


def _send_verification_email(user_id: int, email: str) -> None:
    """サインアップ直後に呼ぶ。クールダウン確認は不要(初回発行なので常に許可)。"""
    token = db.create_email_token(user_id, "verify", store.EMAIL_VERIFY_TOKEN_TTL_SECONDS)
    _deliver_verification_email(email, token)


@app.get("/verify/<token>")
def verify_email(token: str):
    user_id = db.consume_email_token(token, "verify")
    if user_id is None:
        # 実際に見つかった不具合の修正(store.Store.peek_verify_token_user_id
        # のdocstring参照): 企業のメールセキュリティゲートウェイ(Microsoft
        # Defender for Office 365のSafe Links等)が、利用者が実際にクリック
        # する前にメール内のリンクを自動的に「事前アクセス」してマルウェア
        # 検査を行うことが広く知られている。このURLはGETだけでトークンを
        # 消費するため、その自動prefetchが先にトークンを使用済みにしてしまい、
        # 利用者本人が後から同じリンクを開くと以前は無条件に「リンクが無効、
        # または期限切れ」と表示していた。実際には確認自体は(prefetchの時点で)
        # 完了しているため、これは実害のあるユーザー体験上の不具合だった
        # (実際に「別クライアントが先にGET→本人が同じリンクを開く」という
        # 手順で再現して確認した)。既に確認済みであれば、エラーではなく
        # 成功として案内する。
        fallback_user_id = db.peek_verify_token_user_id(token)
        fallback_user = db.get_user(fallback_user_id) if fallback_user_id else None
        if fallback_user and fallback_user.email_verified:
            flash("メールアドレスを確認しました。", "success")
            return redirect(url_for("account") if _current_user() else url_for("login"))
        flash("確認用リンクが無効、または有効期限が切れています。マイページから再送してください。", "error")
        return redirect(url_for("index"))
    db.mark_email_verified(user_id)
    flash("メールアドレスを確認しました。", "success")
    if _current_user():
        return redirect(url_for("account"))
    return redirect(url_for("login"))


@app.post("/account/resend-verification")
@_login_required
def resend_verification():
    user = _current_user()
    if user.email_verified:
        flash("既に確認済みです。", "success")
        return redirect(url_for("account"))
    if not _email_send_rate_limiter.allow(_client_key()):
        flash("リクエストが多すぎます。しばらく待って再試行してください。", "error")
        return redirect(url_for("account"))
    # クールダウン確認とトークン発行を1つのDBトランザクションで行う
    # (store.Store.try_create_email_token_with_cooldownのdocstring参照。
    # 以前は確認と発行が別のDB呼び出しに分かれており、実際に真の並行リクエスト
    # で試したところ20回中18回もクールダウンをすり抜けてしまう実バグがあった)。
    token = db.try_create_email_token_with_cooldown(
        user.id, "verify", _EMAIL_TOKEN_COOLDOWN_SECONDS, store.EMAIL_VERIFY_TOKEN_TTL_SECONDS,
    )
    if token is None:
        flash("確認メールを送信済みです。しばらく待ってから再度お試しください。", "error")
        return redirect(url_for("account"))
    _deliver_verification_email(user.email, token)
    flash("確認メールを再送しました。", "success")
    return redirect(url_for("account"))


@app.get("/login")
def login():
    if _current_user():
        return redirect(url_for("account"))
    # login_required=1は_login_requiredデコレータからのリダイレクトの目印。
    # session(flash)を経由せずクエリ文字列だけで伝える理由は、
    # _login_requiredのコメント参照(セッションを書き換えて既存Cookieを
    # 上書きする副作用を避けるため)。
    show_login_required_notice = request.args.get("login_required") == "1"
    return render_template("login.html", show_login_required_notice=show_login_required_notice)


@app.post("/login")
def login_submit():
    if not _login_rate_limiter.allow(_client_key()):
        flash("ログイン試行が多すぎます。しばらく待ってから再試行してください。", "error")
        return render_template("login.html", email=request.form.get("email", "")), 429

    email = request.form.get("email", "")
    password = request.form.get("password", "")

    # round7で追加: 上のIPベースの制限とは別に、アカウント(メールアドレス)
    # 単位でも総当たりを防ぐ。多数のIP/ボットネットを使い分けて1つの
    # メールアドレスのパスワードを狙う分散的な総当たりは、IPベースの制限
    # だけでは防げないため(store.check_account_lockout()のdocstring参照)。
    # ロック中はdb.authenticate()(bcrypt/scrypt相当のコストがかかる実際の
    # パスワード照合)自体を呼ばない。実在しないメールアドレスでも同じ
    # ロック判定を行う(存在有無をロックの有無から推測させないため)。
    lockout_remaining = db.check_account_lockout(email)
    if lockout_remaining > 0:
        wait_minutes = max(1, math.ceil(lockout_remaining / 60))
        flash(
            f"試行回数が多すぎるため、このアカウントへのログインを一時的に"
            f"制限しています。約{wait_minutes}分後に再度お試しください。",
            "error",
        )
        return render_template("login.html", email=email), 429

    user = db.authenticate(email, password)
    if not user:
        db.record_login_failure(email)
        flash("メールアドレスまたはパスワードが正しくありません。", "error")
        return render_template("login.html", email=email), 400

    db.clear_login_failures(email)
    _adopt_anonymous_jobs_into_account(user.id)
    _login_session_start(user)
    flash("ログインしました。", "success")
    return redirect(url_for("account"))


def _adopt_anonymous_jobs_into_account(user_id: int) -> None:
    """未ログインで生成したジョブの所有権を、ログイン/登録後の本人に引き継ぐ。

    先にログイン後の所有権キーへ引き継いでからsession["user_id"]をセット
    すること(呼び出し側の順序に注意)。visitor_idが無い(初回訪問がそのまま
    サインアップだった)場合は何もしない。
    """
    vid = session.get("visitor_id")
    if vid:
        db.reassign_jobs(f"anon:{vid}", f"user:{user_id}")


@app.post("/logout")
def logout():
    session.pop("user_id", None)
    session.pop("session_version", None)
    flash("ログアウトしました。", "success")
    return redirect(url_for("index"))


@app.get("/forgot-password")
def forgot_password():
    if _current_user():
        return redirect(url_for("account"))
    return render_template("forgot_password.html")


@app.post("/forgot-password")
def forgot_password_submit():
    start_time = time.time()
    email = request.form.get("email", "")
    # IPベースのレート制限。ただしここで429等を返して早期リターンすると、
    # 「このIPは制限されているが、他の応答は常に同じ文言」という違いから
    # 間接的に情報が漏れるわけではない(単に迷惑行為の抑止が目的)ため、
    # 制限にかかった場合も後続と同じ画面に遷移させて構わない。
    allowed_by_ip = _email_send_rate_limiter.allow(_client_key())
    user = db.get_user_by_email(email)
    if user and allowed_by_ip:
        # ユーザー単位のクールダウン(store.py参照)。IPローテーションを使った
        # 分散的なメール爆撃を防ぐため、IP制限とは別にDB側でも強制する。
        # クールダウン確認とトークン発行を1つのDBトランザクションで行う
        # (store.Store.try_create_email_token_with_cooldownのdocstring参照。
        # 以前は`seconds_since_last_token()`で確認してから別途
        # `create_email_token()`を呼ぶ2段構えで、実際に真の並行リクエストで
        # 試したところ20回中18回もクールダウンをすり抜けてしまう実バグが
        # あった)。
        token = db.try_create_email_token_with_cooldown(
            user.id, "reset", _EMAIL_TOKEN_COOLDOWN_SECONDS, store.PASSWORD_RESET_TOKEN_TTL_SECONDS,
        )
        if token is not None:
            reset_url = url_for("reset_password", token=token, _external=True)
            try:
                mail.send(
                    user.email,
                    "PatternForge — パスワードの再設定",
                    f"以下のURLからパスワードを再設定してください（{store.PASSWORD_RESET_TOKEN_TTL_SECONDS // 60}分有効）:\n{reset_url}",
                )
            except Exception:  # pragma: no cover
                app.logger.exception("failed to send password reset email")
            if mail.is_console:
                flash(f"[開発用] 再設定メールは送信されていません。このURLで再設定できます: {reset_url}", "success")
    # メールアドレスが登録されているかどうか・レート制限にかかったかどうかで
    # 文言を変えると、そのメールアドレスが登録済みかどうかを外部から探索
    # できてしまう(user enumeration)ため、常に同じ文言を表示する。
    #
    # 文言だけでなく応答時間も揃える(_FORGOT_PASSWORD_MIN_RESPONSE_SECONDS
    # のコメント参照)。実際にメール送信を行った分岐は既にこの下限に近い/
    # 超えている場合が多く、その場合はここでの追加待機はほぼ発生しない。
    _pad_to_min_response_time(start_time)
    flash("そのメールアドレスが登録されている場合、パスワード再設定用のメールを送信しました。", "success")
    return redirect(url_for("login"))


@app.get("/reset-password/<token>")
def reset_password(token: str):
    return render_template("reset_password.html", token=token)


@app.post("/reset-password/<token>")
def reset_password_submit(token: str):
    password = request.form.get("password", "")
    # 以前は db.consume_email_token(token, "reset") でトークンを先に消費し、
    # その後 db.set_password() を呼んでいたため、パスワードの検証(8文字未満)
    # で失敗した場合でもトークンは既に使用済みになり、利用者が正しい
    # パスワードで再送信しても「リンクが無効/期限切れ」という誤解を招く
    # エラーになってしまう不具合があった(実際に再現・修正済み。詳細は
    # store.Store.reset_password_with_token のdocstring参照)。
    # トークンの検証・消費とパスワード変更を1つのDBトランザクションに
    # まとめた db.reset_password_with_token() を使うことで、パスワードが
    # 無効な場合はトークンが消費されず、同じリンクで再試行できるようにした。
    try:
        user_id = db.reset_password_with_token(token, password)
    except ValueError as exc:
        flash(str(exc), "error")
        return render_template("reset_password.html", token=token), 400
    if user_id is None:
        flash("再設定用リンクが無効、または有効期限が切れています。もう一度お試しください。", "error")
        return redirect(url_for("forgot_password"))
    flash("パスワードを再設定しました。新しいパスワードでログインしてください。", "success")
    return redirect(url_for("login"))


@app.get("/account")
@_login_required
def account():
    user = _current_user()
    org = _current_org()
    plan_name = _current_plan_name()
    owner_key = _current_owner_key()
    limit = _daily_limit_for_plan(plan_name)
    used = db.usage_today(owner_key, _today_str())
    jobs = db.list_jobs_for_owner(owner_key)
    profiles = db.list_measurement_profiles(user.id)
    api_keys = db.list_api_keys(user.id)
    org_members = db.list_org_members(org["id"]) if org else []
    return render_template(
        "account.html", user=user, limit=limit, used=used, jobs=jobs, profiles=profiles,
        max_profiles=store.MAX_MEASUREMENT_PROFILES_PER_USER,
        is_mock_billing=payment_provider.is_mock,
        org=org, org_members=org_members, plan_display=_plan_display_name(plan_name),
        api_keys=api_keys, max_api_keys=store.Store.MAX_API_KEYS_PER_USER,
    )


# ---------------------------------------------------------------------------
# 採寸プロフィール（複数顧客・家族分の採寸値を名前付きで保存・呼び出し）
# ---------------------------------------------------------------------------

@app.post("/api/profiles")
@_login_required
def create_measurement_profile():
    """トップページの生成フォームから、現在入力中の採寸値を名前付きで保存する。

    fetch(AJAX)で呼ばれる想定のJSON API。生成結果を保持したまま(ページ
    遷移なしで)保存できるようにするため、/account/profiles とは別に用意
    している（そちらはマイページからの削除用フォームPOSTで使う）。
    """
    user = _current_user()
    try:
        measurements = _parse_measurements(request.form)
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    name = request.form.get("name", "")
    try:
        profile_id = db.create_measurement_profile(
            user.id, name, measurements.bust, measurements.waist, measurements.hip,
            measurements.height, measurements.sleeve_length, measurements.shoulder_width,
        )
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    profile = db.get_measurement_profile(profile_id, user.id)
    return jsonify({"ok": True, "profile": profile})


@app.post("/account/profiles/<int:profile_id>/delete")
@_login_required
def delete_measurement_profile(profile_id: int):
    user = _current_user()
    if db.delete_measurement_profile(profile_id, user.id):
        flash("プロフィールを削除しました。", "success")
    else:
        flash("プロフィールが見つかりませんでした。", "error")
    return redirect(url_for("account"))


# ---------------------------------------------------------------------------
# APIキー(round8で追加: B2B向けプログラマティックAPI)
# ---------------------------------------------------------------------------

@app.post("/account/api-keys")
@_login_required
def create_api_key():
    user = _current_user()
    name = request.form.get("name", "")
    try:
        _key_id, raw_key = db.create_api_key(user.id, name)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))
    # 生の鍵はこの応答でしか見られない(DBにはハッシュしか残らない)ため、
    # 目立つ形でその場に表示する。flash()はセッションに一時保存されるだけ
    # で外部に送信されないため、ここで表示すること自体に問題は無い
    # (ただしブラウザの「戻る」でキャッシュされたページに残る可能性がある
    # 共有端末での利用には注意が必要。この点はガイド/READMEに明記する)。
    flash(
        f"APIキーを発行しました。この鍵は今だけ表示されます。安全な場所に保存してください: {raw_key}",
        "success",
    )
    return redirect(url_for("account"))


@app.post("/account/api-keys/<int:key_id>/revoke")
@_login_required
def revoke_api_key(key_id: int):
    user = _current_user()
    if db.revoke_api_key(key_id, user.id):
        flash("APIキーを失効させました。", "success")
    else:
        flash("APIキーが見つかりませんでした。", "error")
    return redirect(url_for("account"))


def _require_api_key() -> "store.User | None":
    """`Authorization: Bearer <key>`ヘッダーからAPIキー認証する。B2B向け
    プログラマティックAPI(/api/v1/*)専用。ブラウザセッション(Cookie)による
    認証とは完全に別経路であり、CSRFトークンの検証対象にもしていない
    (ブラウザのセッションCookieを一切使わないため、そもそもCSRFが成立しない。
    _CSRF_EXEMPT_ENDPOINTSに`api_v1_generate`を追加しているのはこのため)。
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None
    raw_key = auth_header[len("Bearer "):].strip()
    return db.authenticate_api_key(raw_key)


@app.post("/api/v1/generate")
def api_v1_generate():
    """プログラマティックAPI(B2B向け)。ブラウザのCookie/CSRFトークンでは
    なく、`Authorization: Bearer pf_live_...`ヘッダーのAPIキーで認証する。

    正直な実装レベルの注記(スコープの限界): 既存の/api/generate(ブラウザ
    フォームからの利用)にある、イラストモード・サイズ展開モードは今回は
    対応しない。B2Bの利用シナリオ(自社システムから採寸値とパーツ構成を
    渡して型紙を得る)で最も必要になる「手動選択モード」のみを最小構成で
    提供する(今後の拡張候補としてREADMEに明記する)。リクエストボディは
    `/api/generate`の手動選択モードと同じフォームフィールド
    (multipart/form-data、またはapplication/x-www-form-urlencoded)を
    受け付ける。画像解析・自由輪郭・3D小物にだけ使う入力は対象外とする。

    利用回数上限・レート制限は、鍵の持ち主のプラン・所有権キー
    (`user:<id>`、組織所属時は`org:<id>`)にそのまま従う(ブラウザ経由の
    利用と共有のプールになる。API専用の別枠は用意していない)。
    """
    if not _generate_rate_limiter.allow(_client_key()):
        return jsonify({"ok": False, "error": "リクエストが多すぎます。しばらく待って再試行してください。"}), 429

    user = _require_api_key()
    if user is None:
        return jsonify({"ok": False, "error": "無効なAPIキーです。Authorization: Bearer <key> ヘッダーを確認してください。"}), 401

    org = db.get_org_for_user(user.id)
    owner_key = f"org:{org['id']}" if org else f"user:{user.id}"
    plan_name = org["plan"] if org else user.plan
    daily_limit = _daily_limit_for_plan(plan_name)

    _usage_owner_key: str | None = None
    try:
        measurements = _parse_measurements(request.form)
        allow_rotation = _bool_field(request.form, "allow_rotation")
        one_way_fabric, shrink_percent, pattern_repeat_cm = \
            _parse_fabric_shopping_fields(request.form)
        stash = _parse_stash_fields(request.form)
        per_fabric_stash = _parse_stash_per_fabric(request.form)
        alterations = _parse_alteration_fields(request.form)
        # round52: 丈の直接指定(キャラクターの衣装は丈でシルエットが決まる)。
        design_lengths = _parse_design_lengths(request.form)
        fabric_groups = _parse_fabric_groups(request.form)
        lining = _bool_field(request.form, "lining")
        lining_scope = request.form.getlist("lining_scope") if lining else []
        allowed_lining_scope = {
            "front_bodice", "back_bodice", "sleeve", "skirt",
            "front_pants", "back_pants",
        }
        unknown_lining_scope = sorted(set(lining_scope) - allowed_lining_scope)
        if unknown_lining_scope:
            raise ValueError("裏地の対象部位が不正です。画面から選び直してください。")
        block_key = (request.form.get("block") or "").strip() or None
        measured_block = _parse_measured_block(request.form, block_key)
        if measured_block is None:
            get_block(block_key)
        seam_allowance_cm, hem_seam_allowance_cm = _parse_seam_allowance_fields(request.form)
        # round58: このAPIのdocstringは「リクエストボディは`/api/generate`と
        # 同じフォームフィールドを受け付ける」と約束している。round41に
        # 1度直したのに、その後に増えた欄がまた取りこぼされていた——
        # ゆとり(round24)・切り替え線(round30)・用紙(round57)・
        # 白紙の面(round57)の4つが、送っても効かなかった。
        # 下の`test_the_b2b_api_reads_the_same_fields_as_the_browser_form`で、
        # 読んでいるフォーム欄を数え上げて突き合わせる。
        fit = _parse_fit(request.form, measurements)
        paper = (request.form.get("paper") or "").strip() or None
        include_empty_tiles = _bool_field(request.form, "include_empty_tiles")
        garment_spec_kwargs = {
            "neckline": request.form.get("neckline", "round_neck"),
            "sleeve_style": (request.form.get("sleeve_style") or None),
            "skirt_style": (request.form.get("skirt_style") or None),
            "front_zip": _bool_field(request.form, "front_zip"),
            "include_pants": _bool_field(request.form, "include_pants"),
            "pants_style": request.form.get("pants_style", ""),
            "include_collar": _bool_field(request.form, "include_collar"),
            "collar_style": request.form.get("collar_style", ""),
            "include_cuffs": _bool_field(request.form, "include_cuffs"),
            "cuffs_style": request.form.get("cuffs_style", ""),
            "include_waistband": _bool_field(request.form, "include_waistband"),
            "waistband_style": request.form.get("waistband_style", ""),
            "princess_line": _bool_field(request.form, "princess_line"),
        }
        spec = build_garment_spec(**garment_spec_kwargs)
        if lining_scope:
            spec.construction["lining_scope"] = list(lining_scope)

        allowed, used_today = db.check_and_increment_usage(owner_key, daily_limit, _today_str())
        if not allowed:
            return jsonify({
                "ok": False,
                "error": f"本日の生成回数の上限（{daily_limit}回/日）に達しました。",
            }), 429
        _usage_owner_key = owner_key

        # 【round41で直した実バグ】この関数のdocstringは「リクエストボディは
        # `/api/generate`と同じフォームフィールドを受け付ける」と約束している
        # のに、上で読み取った one_way_fabric / shrink_percent /
        # pattern_repeat_cm / alterations / stash を**1つも渡していなかった**。
        # 読み取り側(`_parse_*`)は書いてあり、値の検証まで通るので、
        # API利用者から見ると「指定は受理されたのに効かない」——不正な値なら
        # 400が返るぶん、効いていると誤解しやすい。読み取ったものは渡す。
        result = pipeline.generate_from_selection(
            spec, measurements, allow_rotation=allow_rotation,
            seam_allowance_cm=seam_allowance_cm, hem_seam_allowance_cm=hem_seam_allowance_cm,
            one_way_fabric=one_way_fabric, shrink_percent=shrink_percent,
            pattern_repeat_cm=pattern_repeat_cm,
            alterations=alterations, lining=lining, block_key=block_key,
            measured_block=measured_block,
            design_length_overrides=design_lengths or None,
            fabric_group_assignments=fabric_groups or None,
            fit=fit, paper=paper, include_empty_tiles=include_empty_tiles,
        )
        if stash is not None:
            result.stash_verdict, result.stash_verdicts_by_fabric = _evaluate_stash(
                pipeline, result, spec, measurements, stash,
                fabric_group_assignments=fabric_groups or None,
                per_fabric_stash=per_fabric_stash,
                allow_rotation=allow_rotation, one_way_fabric=one_way_fabric,
                block_key=block_key, measured_block=measured_block,
                seam_allowance_cm=seam_allowance_cm,
                hem_seam_allowance_cm=hem_seam_allowance_cm)
        payload = result.summary()
        regen_spec = {
            "mode": "manual",
            "measurements": measurements.as_dict(),
            "garment_spec": garment_spec_kwargs,
            "allow_rotation": allow_rotation,
            "seam_allowance_cm": seam_allowance_cm,
            "hem_seam_allowance_cm": hem_seam_allowance_cm,
            # ブラウザ経由と同じ形式で保存する。専用原型は8項目すべてが
            # 揃わない限り再構築できないため、block名だけ／トップレベルの
            # 一部だけを保存して既定原型へ落とすことはしない。
            "generation_kwargs": {
                "allow_rotation": allow_rotation,
                "seam_allowance_cm": seam_allowance_cm,
                "hem_seam_allowance_cm": hem_seam_allowance_cm,
                "one_way_fabric": one_way_fabric,
                "shrink_percent": shrink_percent,
                "pattern_repeat_cm": pattern_repeat_cm,
                "alterations": alterations or None,
                "lining": lining,
                "block_key": block_key,
                "measured_block": measured_block,
                "design_length_overrides": design_lengths or None,
                "fabric_group_assignments": fabric_groups or None,
                "fit": _fit_to_json(fit),
                "paper": paper,
                "include_empty_tiles": include_empty_tiles,
            },
        }
        db.record_job(result.job_id, owner_key, part_count=payload["part_count"],
                      waste_ratio=payload["waste_ratio"], spec_json=json.dumps(regen_spec))
        payload["download"] = _download_links(result)
        payload["usage"] = {"used_today": used_today, "daily_limit": daily_limit}
        return jsonify({"ok": True, **payload})
    except ValueError as exc:
        if _usage_owner_key is not None:
            db.refund_usage(_usage_owner_key, _today_str())
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception:
        if _usage_owner_key is not None:
            db.refund_usage(_usage_owner_key, _today_str())
        error_id = uuid.uuid4().hex[:8]
        app.logger.exception("api v1 generation failed [error_id=%s]", error_id)
        return jsonify({
            "ok": False,
            "error": f"内部エラーが発生しました（エラーID: {error_id}）。",
        }), 500


# ---------------------------------------------------------------------------
# 組織アカウント(round8で追加: 最小構成のチーム機能。store.pyの
# 「組織アカウント」節のコメントに、スコープの限界を含めて詳しく記載)
# ---------------------------------------------------------------------------

@app.post("/org/create")
@_login_required
def org_create():
    user = _current_user()
    name = request.form.get("name", "")
    try:
        db.create_organization(user.id, name)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))
    flash("組織を作成しました。", "success")
    return redirect(url_for("account"))


@app.post("/org/invite")
@_login_required
def org_invite():
    user = _current_user()
    org = _current_org()
    if not org:
        flash("組織に所属していません。", "error")
        return redirect(url_for("account"))
    if org["owner_user_id"] != user.id:
        flash("メンバーの招待はオーナーのみ行えます。", "error")
        return redirect(url_for("account"))
    if not _email_send_rate_limiter.allow(_client_key()):
        flash("リクエストが多すぎます。しばらく待って再試行してください。", "error")
        return redirect(url_for("account"))
    email = request.form.get("email", "")
    try:
        token = db.create_org_invite(org["id"], email, user.id)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))
    invite_url = url_for("org_accept_invite", token=token, _external=True)
    try:
        mail.send(
            email.strip().lower(),
            f"PatternForge — 「{org['name']}」への招待",
            f"「{org['name']}」チームに招待されました。以下のURLから参加してください"
            f"（{store.Store.ORG_INVITE_TOKEN_TTL_SECONDS // 86400}日間有効）:\n{invite_url}",
        )
    except Exception:  # pragma: no cover - メール送信基盤の障害で招待発行自体は失敗させない
        app.logger.exception("failed to send org invite email")
    if mail.is_console:
        flash(f"[開発用] 招待メールは送信されていません。このURLで参加できます: {invite_url}", "success")
    flash(f"{email} を招待しました。", "success")
    return redirect(url_for("account"))


@app.get("/org/invites/<token>")
def org_accept_invite_page(token: str):
    invite = db.get_org_invite(token)
    if invite is None:
        flash("招待リンクが無効です。", "error")
        return redirect(url_for("index"))
    org = db.get_organization(invite["org_id"])
    return render_template("org_invite.html", invite=invite, org=org, token=token)


@app.post("/org/invites/<token>/accept")
@_login_required
def org_accept_invite(token: str):
    user = _current_user()
    try:
        org_id = db.accept_org_invite(token, user.id)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))
    if org_id is None:
        flash(
            "招待を受諾できませんでした（リンクが無効・期限切れ、または"
            "招待先メールアドレスとログイン中のアカウントが一致しません）。",
            "error",
        )
        return redirect(url_for("index"))
    flash("組織に参加しました。", "success")
    return redirect(url_for("account"))


@app.post("/org/members/<int:member_user_id>/remove")
@_login_required
def org_remove_member(member_user_id: int):
    user = _current_user()
    org = _current_org()
    if not org:
        flash("組織に所属していません。", "error")
        return redirect(url_for("account"))
    # オーナー本人か、自分自身(自主退会)のみ許可する。
    if org["owner_user_id"] != user.id and member_user_id != user.id:
        flash("他のメンバーを外せるのはオーナーのみです。", "error")
        return redirect(url_for("account"))
    if member_user_id == org["owner_user_id"]:
        flash("オーナーは組織から外せません。組織を解散する場合は「組織を解散」を使ってください。", "error")
        return redirect(url_for("account"))
    if db.remove_org_member(org["id"], member_user_id):
        flash("メンバーを外しました。" if member_user_id != user.id else "組織から抜けました。", "success")
    else:
        flash("メンバーが見つかりませんでした。", "error")
    return redirect(url_for("account"))


@app.post("/org/disband")
@_login_required
def org_disband():
    user = _current_user()
    org = _current_org()
    if not org:
        flash("組織に所属していません。", "error")
        return redirect(url_for("account"))
    try:
        db.disband_organization(org["id"], user.id)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))
    flash("組織を解散しました。", "success")
    return redirect(url_for("account"))


# ---------------------------------------------------------------------------
# アカウント削除・データエクスポート(round8で追加)
# ---------------------------------------------------------------------------

@app.get("/account/export")
@_login_required
def account_export():
    """自分のデータ一式をJSONファイルとしてダウンロードする。

    個人情報保護法(APPI)の開示請求への対応、およびサービス移行・記録保持
    のためのデータポータビリティ手段として提供する。パスワードハッシュ・
    APIキーの秘密値は含めない(store.Store.export_user_dataのdocstring
    参照)。
    """
    user = _current_user()
    data = db.export_user_data(user.id)
    body = json.dumps(data, ensure_ascii=False, indent=2)
    response = Response(body, mimetype="application/json")
    response.headers["Content-Disposition"] = (
        f'attachment; filename="patternforge_data_{user.id}_{_today_str()}.json"'
    )
    response.headers["Cache-Control"] = "private, no-store"
    return response


@app.get("/account/delete")
@_login_required
def account_delete_confirm():
    """退会の確認画面(パスワード再入力を要求する)。"""
    org = _current_org()
    return render_template("account_delete.html", org=org)


@app.post("/account/delete")
@_login_required
def account_delete_submit():
    """アカウントを完全に削除する(退会)。

    実際に動かして見つかった設計上の考慮点: ログイン済みセッションを
    乗っ取られた状態(例えばXSS等で盗まれたセッションCookie)からの誤操作・
    悪用による取り返しのつかない削除を防ぐため、パスワード確認フォーム
    ログインパスワードそのものを要求する(単なる「削除」ボタンのクリック
    だけでは実行できないようにする)。
    """
    user = _current_user()
    password = request.form.get("password", "")
    if not db.authenticate(user.email, password):
        flash("パスワードが正しくないため、削除できませんでした。", "error")
        return redirect(url_for("account_delete_confirm"))

    if not payment_provider.is_mock and user.stripe_subscription_id:
        try:
            payment_provider.cancel_subscription(user.stripe_subscription_id)
        except Exception:
            app.logger.exception(
                "failed to cancel stripe subscription during account deletion for user_id=%s", user.id
            )
            flash(
                "サブスクリプションの解約に失敗したため削除できませんでした。"
                "しばらくしてから再度お試しいただくか、サポートにご連絡ください。",
                "error",
            )
            return redirect(url_for("account_delete_confirm"))

    try:
        db.delete_user_account(user.id)
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("account"))

    session.pop("user_id", None)
    session.pop("session_version", None)
    flash("アカウントを削除しました。ご利用ありがとうございました。", "success")
    return redirect(url_for("index"))


@app.post("/account/jobs/<job_id>/regenerate")
@_login_required
def regenerate_job(job_id: str):
    """生成履歴の1件を、保存済みの入力(spec_json)から再生成する(round8で追加)。

    実際に動かして見つかった既存の制約への対応: 生成物(SVG/PDF/DXF)自体は
    OUTPUT_TTL_SECONDS(既定1時間)で自動削除されるため、それより後に
    マイページから再ダウンロードしようとしても失敗していた。入力
    (採寸値・パーツ構成等)さえ`jobs.spec_json`に残っていれば、同じ設定で
    型紙を作り直せるようにする。通常の/api/generateと同じ利用回数上限・
    レート制限を適用する(タダで無制限に再生成できると上限の意味が無くなる
    ため)。イラストモードで生成した履歴はアップロード画像自体を保持して
    いないため再生成できない(正直な限界。README参照)。
    """
    if not _generate_rate_limiter.allow(_client_key()):
        flash("リクエストが多すぎます。しばらく待って再試行してください。", "error")
        return redirect(url_for("account"))
    if not _JOB_ID_RE.match(job_id):
        flash("不正なリクエストです。", "error")
        return redirect(url_for("account"))

    owner_key = _current_owner_key()
    regen_spec = db.get_job_regeneration_spec(job_id, owner_key)
    if regen_spec is None:
        flash(
            "この生成履歴は再生成できません（イラストモードから生成された、"
            "または他のバージョンで生成されたため入力データが保存されていません）。",
            "error",
        )
        return redirect(url_for("account"))

    plan_name = _current_plan_name()
    daily_limit = _daily_limit_for_plan(plan_name)
    allowed, _used_today = db.check_and_increment_usage(owner_key, daily_limit, _today_str())
    if not allowed:
        flash(
            f"本日の生成回数の上限（{daily_limit}回/日、{_plan_display_name(plan_name)}）に達しました。",
            "error",
        )
        return redirect(url_for("account"))

    try:
        measurements = Measurements(**regen_spec["measurements"])
        project_name = regen_spec.get("project_name")
        # round57: イラストから作ったものは、パーツ構成を`garment_spec`
        # (選択肢の組み合わせ)ではなく、読み取った結果のパーツ一覧として
        # 保存してある。下の共通処理はその形を知らないので先に分ける。
        garment_spec_kwargs = regen_spec.get("garment_spec") or {}
        # round10で追加: include_body_garment/custom_panelsは古い(round10より
        # 前の)生成履歴のspec_jsonには存在しないため、.get()で既定値
        # (True/空リスト=従来通り本体パーツのみ)を補う。これにより、
        # round10より前に生成された履歴の再生成は一切挙動が変わらない。
        include_body_garment = regen_spec.get("include_body_garment", True)
        spec = build_garment_spec(**garment_spec_kwargs) if include_body_garment else GarmentSpec(parts=[])
        spec.construction.update(dict(regen_spec.get("construction") or {}))
        regen_custom_specs = [
            CustomPanelSpec(
                label=panel["label"],
                points_cm=[tuple(p) for p in panel["points_cm"]],
                quantity=panel.get("quantity", 1),
                mirror=panel.get("mirror", False),
                allow_split=panel.get("allow_split", False),
                replacement_part_type=panel.get("replacement_part_type"),
                seam_fit_confirmed=bool(panel.get("seam_fit_confirmed", False)),
                grade_width_cm=float(panel.get("grade_width_cm", 0.0)),
                grade_height_cm=float(panel.get("grade_height_cm", 0.0)),
            )
            for panel in regen_spec.get("custom_panels", [])
        ]
        if regen_custom_specs and regen_spec.get("mode") != "illustration_replay":
            spec.parts = merge_custom_panel_requests(
                spec.parts, _custom_panel_specs_to_requests(regen_custom_specs),
                princess_line=spec.princess_line)
        allow_rotation = regen_spec.get("allow_rotation", False)
        seam_allowance_cm = regen_spec.get("seam_allowance_cm", DEFAULT_SEAM_ALLOWANCE_CM)
        hem_seam_allowance_cm = regen_spec.get("hem_seam_allowance_cm")

        if regen_spec["mode"] == "illustration_replay":
            # round57: イラストから作ったものの作り直し。
            # 画像は保存していない(これまでどおり)。保存してあるのは
            # **画像から決まった結果**——パーツ構成と丈——なので、
            # 読み取りをやり直さずに同じ型紙が出る。
            spec = GarmentSpec(parts=[
                PartRequest(part_type=part["part_type"],
                            variation=part.get("variation", ""),
                            quantity=int(part.get("quantity", 1)),
                            custom_segments=part.get("custom_segments"),
                            allow_split=bool(part.get("allow_split", False)),
                            design_length_cm=part.get("design_length_cm"),
                            layer_number=part.get("layer_number"),
                            replacement_part_type=part.get("replacement_part_type"),
                            seam_fit_confirmed=bool(
                                part.get("seam_fit_confirmed", False)),
                            grade_width_cm=float(part.get("grade_width_cm", 0.0)),
                            grade_height_cm=float(part.get("grade_height_cm", 0.0)))
                for part in regen_spec.get("parts", [])
            ], princess_line=bool(regen_spec.get("princess_line", False)),
                construction=dict(regen_spec.get("construction") or {}))
            generation_kwargs = _restore_generation_kwargs(
                regen_spec.get("generation_kwargs") or {})
            result = pipeline.generate_from_selection(
                spec, measurements, **generation_kwargs)
            draft_preview_path = _withhold_unconfirmed_outputs(result)
            accessory_3d = regen_spec.get("accessory_3d")
            if accessory_3d:
                _export_accessory_outputs(result, regen_custom_specs, accessory_3d)
            payload = result.summary()
            db.record_job(result.job_id, owner_key, part_count=payload["part_count"],
                          waste_ratio=payload["waste_ratio"],
                          spec_json=json.dumps(regen_spec), project_name=project_name)
            if draft_preview_path:
                flash(
                    f"ラフ確認を再生成しました。未確認項目があるため裁断用PDF・DXFは"
                    f"出力していません。確認資料: /download/{result.job_id}/svg "
                    f"製作仕様書: /download/{result.job_id}/spec_pdf",
                    "success")
            else:
                flash(
                    f"再生成しました（イラストから読み取った構成のまま）。"
                    f"{_describe_restored_settings(generation_kwargs)}。"
                    f" ダウンロード: /download/{result.job_id}/svg （SVG） "
                    f"/download/{result.job_id}/pdf （PDF） "
                    f"/download/{result.job_id}/spec_pdf （製作仕様書）",
                    "success",
                )
        elif regen_spec["mode"] == "multi_size":
            sizes = regen_spec["sizes"]
            custom_grade_cm = regen_spec.get("custom_grade_cm")
            # round55: 生成したときの設定一式を渡し直す。
            # 古い履歴(このキーが無い)は従来どおり4つだけで再生成する。
            multi_size_kwargs = _restore_generation_kwargs(
                regen_spec.get("multi_size_kwargs") or {}) or {
                "allow_rotation": allow_rotation,
                "seam_allowance_cm": seam_allowance_cm,
                "hem_seam_allowance_cm": hem_seam_allowance_cm,
                "custom_grade_cm": custom_grade_cm,
            }
            multi = pipeline.generate_multi_size(
                spec, measurements, sizes, **multi_size_kwargs)
            total_parts = sum(r.summary()["part_count"] for r in multi.results.values())
            db.record_job(multi.bundle_job_id, owner_key, part_count=total_parts, waste_ratio=None,
                          spec_json=json.dumps(regen_spec), project_name=project_name)
            for size, result in multi.results.items():
                size_payload = result.summary()
                db.record_job(result.job_id, owner_key, part_count=size_payload["part_count"],
                              waste_ratio=size_payload["waste_ratio"],
                              project_name=project_name)
            flash(f"再生成しました。{_describe_restored_settings(multi_size_kwargs)}。"
                   f" ダウンロード: /download/{multi.bundle_job_id}/zip （ZIP一括）", "success")
        else:
            # round55: 生成したときの設定一式を、そのまま渡し直す。
            # 古い履歴(このキーが無い)は、従来どおり3つだけで再生成する。
            generation_kwargs = _restore_generation_kwargs(
                regen_spec.get("generation_kwargs") or {}) or {
                "allow_rotation": allow_rotation,
                "seam_allowance_cm": seam_allowance_cm,
                "hem_seam_allowance_cm": hem_seam_allowance_cm,
            }
            result = pipeline.generate_from_selection(
                spec, measurements, **generation_kwargs)
            accessory_3d = regen_spec.get("accessory_3d")
            stl_note = ""
            if accessory_3d:
                _export_accessory_outputs(result, regen_custom_specs, accessory_3d)
                stl_note = (
                    f" /download/{result.job_id}/stl （3D小物STL）"
                    f" /download/{result.job_id}/vendor_zip （業者入稿ZIP）")
            payload = result.summary()
            db.record_job(result.job_id, owner_key, part_count=payload["part_count"],
                          waste_ratio=payload["waste_ratio"], spec_json=json.dumps(regen_spec),
                          project_name=project_name)
            flash(
                f"再生成しました。{_describe_restored_settings(generation_kwargs)}。"
                f" ダウンロード: /download/{result.job_id}/svg （SVG） "
                f"/download/{result.job_id}/pdf （PDF） "
                f"/download/{result.job_id}/spec_pdf （製作仕様書）{stl_note}",
                "success",
            )
        return redirect(url_for("account"))
    except Exception:
        db.refund_usage(owner_key, _today_str())
        error_id = uuid.uuid4().hex[:8]
        app.logger.exception("regeneration failed [error_id=%s]", error_id)
        flash(f"再生成に失敗しました（エラーID: {error_id}）。", "error")
        return redirect(url_for("account"))


@app.post("/account/upgrade")
@_login_required
def account_upgrade():
    user = _current_user()
    org = _current_org()
    if org:
        # round8で追加: 組織に所属する場合はプランを組織単位で切り替える
        # (個人のplan列は無視する。_current_plan_name参照)。実際のStripe
        # 連携での組織単位請求は未実装(正直な限界。store.pyの組織関連の
        # コメント、READMEの既知の制約を参照)なので、モックモード以外では
        # 実行させず案内だけ表示する。
        if org["owner_user_id"] != user.id:
            flash("プランの変更は組織のオーナーのみ行えます。", "error")
            return redirect(url_for("account"))
        if org["plan"] == "pro":
            flash("既にProプランです。", "success")
            return redirect(url_for("account"))
        if not payment_provider.is_mock:
            flash(
                "組織プランでの実際の決済連携は現在未対応です。個人アカウントでの"
                "アップグレードのみStripe連携に対応しています。",
                "error",
            )
            return redirect(url_for("account"))
        db.set_org_plan(org["id"], "pro")
        flash("テストモードで組織をPro相当に切り替えました（実際の決済は発生していません）。", "success")
        return redirect(url_for("account"))
    if user.plan == "pro":
        # 二重クリック・フォーム再送信でStripe側に重複したCheckout
        # Session/サブスクリプションを作らないためのガード(第2回監査 指摘#7)。
        flash("既にProプランです。", "success")
        return redirect(url_for("account"))
    if payment_provider.is_mock:
        db.set_plan(user.id, "pro")
        flash("テストモードでPro相当に切り替えました（実際の決済は発生していません）。", "success")
        return redirect(url_for("account"))

    checkout_url = payment_provider.start_checkout(
        user,
        success_url=url_for("account", upgraded=1, _external=True),
        cancel_url=url_for("pricing", _external=True),
    )
    return redirect(checkout_url)


@app.post("/account/downgrade")
@_login_required
def account_downgrade():
    user = _current_user()
    org = _current_org()
    if org:
        if org["owner_user_id"] != user.id:
            flash("プランの変更は組織のオーナーのみ行えます。", "error")
            return redirect(url_for("account"))
        db.set_org_plan(org["id"], "free")
        flash("組織をFreeプランに戻しました。", "success")
        return redirect(url_for("account"))
    if not payment_provider.is_mock and user.stripe_subscription_id:
        try:
            payment_provider.cancel_subscription(user.stripe_subscription_id)
        except Exception:
            app.logger.exception("failed to cancel stripe subscription for user_id=%s", user.id)
            flash("解約処理に失敗しました。しばらくしてから再度お試しください。", "error")
            return redirect(url_for("account"))
        # 実際のplan更新はWebhook(customer.subscription.deleted)側で確定させる
        # のが正式な経路だが、解約操作をした利用者に即座にUI上で反映するため
        # ここでも先行して更新する(Webhookが後から来ても同じ状態に収束する)。
    #
    # 実際に動かして見つかった不具合(修正済み): 以前はここで単純に
    # db.set_plan(user.id, "free") を呼んでいたため、users.last_billing_event_at
    # (round21で追加したWebhook配信順序保護の基準値)がこの「即時反映」の
    # 際に更新されなかった。この状態で、キャンセル操作より前に生成された
    # (=時系列としては古いが、last_billing_event_atよりは新しいcreatedを
    # 持つ)Webhookイベント――例えば、キャンセル直前の決済成功で発生した
    # customer.subscription.updated(status=active)がStripe側の配信遅延で
    # 今になって届く場合――が後から処理されると、db.apply_billing_event()の
    # 古さ判定をすり抜けてplanが"pro"に巻き戻ってしまうことを、実際に
    # (1)決済成功Webhookを適用→pro、(2)このエンドポイントでfreeへ即時反映
    # (旧実装のset_plan相当)、(3)キャンセル前に生成された古いactive
    # Webhookを適用、という手順を直接実行して確認した(3の適用後、意図せず
    # planがproへ戻ってしまった)。この即時反映も
    # db.apply_billing_event()を通し、現在時刻をcreatedとして
    # last_billing_event_atを更新するようにすることで、キャンセル操作より
    # 前に生成された古いWebhookが後から届いても無視されるようにした
    # (実際に正しいcustomer.subscription.deletedのWebhookが確定として
    # 届く分には、その`created`は当然この即時反映より新しいため問題無く
    # 適用される)。
    db.apply_billing_event(user.id, time.time(), "free")
    flash("Freeプランに戻しました。", "success")
    return redirect(url_for("account"))


@app.post("/billing/webhook")
def billing_webhook():
    """Stripe Webhook。支払い確定/解約をここで正式に確定させる。

    アップグレード操作直後のリダイレクト(success_url)だけを頼りにplanを
    更新すると、利用者がリダイレクトを中断した場合に支払い済みなのに
    planが更新されないままになりうる。Webhookで確定させることで、
    ブラウザ側の状態に関係なく正しいplanに収束させる。
    """
    if payment_provider.is_mock:
        return jsonify({"ok": False, "error": "billing not configured"}), 404

    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET")
    if not webhook_secret:
        app.logger.error("Stripe webhook received but STRIPE_WEBHOOK_SECRET is not set")
        return jsonify({"ok": False, "error": "webhook secret not configured"}), 500

    payload = request.get_data()
    sig_header = request.headers.get("Stripe-Signature", "")
    try:
        event = payment_provider.construct_webhook_event(payload, sig_header, webhook_secret)
    except Exception:
        app.logger.exception("invalid stripe webhook signature")
        return jsonify({"ok": False, "error": "invalid signature"}), 400

    event_type = event["type"]
    obj = event["data"]["object"]
    # 実際に本物のStripeライブラリ(stripe-python)でWebhookイベントを構築して
    # 見つかった実バグの修正: construct_webhook_event()が返す`obj`は素の
    # dictではなく`stripe._stripe_object.StripeObject`で、`__getitem__`は
    # 使えるが`.get()`は実装されていない(呼ぶと
    # 「'get' is a dict method, but a StripeObject is not a dict」という
    # AttributeErrorになる)。以前のテストは`construct_webhook_event`自体を
    # 素のdictを返すモックに置き換えていたため、この不整合に気付けず、
    # 本物のStripe連携ではWebhookが来るたびに毎回500エラーになり、
    # 支払い確定(plan更新)が一度も成功しない状態だった。`.to_dict()`で
    # 素のdictに変換してから`.get()`を使うようにする。
    if hasattr(obj, "to_dict"):
        obj = obj.to_dict()

    # 実際に本物のstripeライブラリ・本物のHMAC署名で「支払い失敗
    # (past_due, 生成時刻t1) → リトライで復旧(active, 生成時刻t2>t1)」の
    # 2つのイベントを構築し、Stripeの公式ドキュメントが明記している
    # 「Webhookイベントの配信順序は保証されない」仕様通りに、新しいイベント
    # (active)を先に、古いイベント(past_due、再送/遅延で後から届いた)を
    # 後にサーバへ届けたところ、以前はどのイベントも受信した順にそのまま
    # planを上書きしていたため、実際には直近の状態が"active"(pro)である
    # にもかかわらず、後から届いた古い"past_due"イベントによってplanが
    # "free"へ巻き戻され、そのまま固定されてしまう実バグを確認した(詳細は
    # store.Store.apply_billing_event のdocstring参照)。イベントの
    # `created`(発生時刻)を`db.apply_billing_event()`に渡し、既に適用済みの
    # イベントより古い場合は無視するようにして、配信順序に依存せず常に
    # 最新の内容へ収束するように修正した。
    event_created_at = event["created"]

    if event_type == "checkout.session.completed":
        user_id_raw = obj.get("client_reference_id")
        # client_reference_id はStripe側の設定ミスや、こちらの実装変更・
        # 手動テスト等で数値以外や存在しないuser_idが来る可能性がある。
        # ここで例外を握りつぶさずに500を返すと、Stripeが同じイベントを
        # 再送し続けてログを埋め尽くすため、不正な形式は警告ログを残した上で
        # 200を返し「処理済み」としてStripe側の再送を止める(第2回監査 指摘#6)。
        if user_id_raw:
            try:
                user_id = int(user_id_raw)
            except (TypeError, ValueError):
                app.logger.warning(
                    "stripe webhook: client_reference_id is not an integer: %r", user_id_raw
                )
            else:
                if db.get_user(user_id) is None:
                    app.logger.warning(
                        "stripe webhook: checkout.session.completed for unknown user_id=%s", user_id
                    )
                else:
                    db.apply_billing_event(
                        user_id, event_created_at, "pro",
                        stripe_customer_id=obj.get("customer"),
                        stripe_subscription_id=obj.get("subscription"),
                    )
        else:
            app.logger.warning("stripe webhook: checkout.session.completed missing client_reference_id")
    elif event_type == "customer.subscription.deleted":
        customer_id = obj.get("customer")
        user = db.get_user_by_stripe_customer_id(customer_id) if customer_id else None
        if user:
            db.apply_billing_event(user.id, event_created_at, "free")
    elif event_type == "customer.subscription.updated":
        # 実際に本物のstripeライブラリ・本物のHMAC署名でWebhookイベントを
        # 構築し、支払い失敗(invoice.payment_failed)→サブスクリプションが
        # past_due状態になる(customer.subscription.updated)という実際の
        # Stripeの流れを再現してサーバに送ったところ、以前はこのイベント
        # 種別を一切処理しておらず、支払いが失敗してもplanが"pro"のまま
        # 変わらず、無制限に生成し続けられる状態だった(既存のテストは
        # checkout.session.completedとcustomer.subscription.deletedしか
        # 検証しておらず、この抜けに気付けなかった)。Stripeは支払い失敗時、
        # 通常はリトライ期間中はcustomer.subscription.deletedを送らず
        # (Stripe側のSmart Retries設定によっては、リトライを使い切っても
        # 自動キャンセルされずunpaidのまま残ることもある)、代わりに
        # このイベントのstatusフィールドでpast_due/unpaid等の状態変化を
        # 通知してくるため、statusを見て追従する必要がある。
        # active/trialingは支払いが正常な状態としてpro維持、それ以外
        # (past_due/unpaid/incomplete_expired/paused等)はpro機能を無制限に
        # 使わせるべきではないためfreeに戻す。リトライで支払いが復旧して
        # 再びactiveに戻った場合も、同じイベントで自動的にproへ復帰する。
        customer_id = obj.get("customer")
        status = obj.get("status")
        user = db.get_user_by_stripe_customer_id(customer_id) if customer_id else None
        if user:
            db.apply_billing_event(
                user.id, event_created_at, "pro" if status in ("active", "trialing") else "free",
            )

    return jsonify({"ok": True})


@app.get("/pricing")
def pricing():
    return render_template(
        "pricing.html", limits=store.DEFAULT_DAILY_LIMITS, is_mock_billing=payment_provider.is_mock,
    )


@app.get("/guide")
def guide():
    """使い方ガイド（操作マニュアル）。

    アカウント登録の有無に関わらず内容を読めるよう、ログイン必須にはしない。
    """
    return render_template(
        "guide.html", limits=store.DEFAULT_DAILY_LIMITS,
        max_profiles=store.MAX_MEASUREMENT_PROFILES_PER_USER,
    )


# ---------------------------------------------------------------------------
# 法的表示（利用規約・プライバシーポリシー・運営者情報）
# ---------------------------------------------------------------------------
#
# アカウント登録・メール送信・決済(Stripe)を扱う以上、これらのページは
# 実際に一般公開する前に必須。ただし事業者名・所在地・連絡先といった
# 実際の情報はこのリポジトリには含められないため、テンプレート内に
# 「[事業者名を入力]」のようなプレースホルダーを残している。公開前に
# 必ず実際の情報に差し替えること（README「公開前チェックリスト」参照）。

@app.get("/terms")
def terms():
    return render_template("terms.html")


@app.get("/privacy")
def privacy():
    return render_template("privacy.html")


@app.get("/legal")
def legal_notice():
    return render_template("legal.html")


# ---------------------------------------------------------------------------
# エラーページ
# ---------------------------------------------------------------------------

@app.errorhandler(RequestEntityTooLarge)
def _handle_request_entity_too_large(exc):
    """アップロードサイズ超過(413)を一貫したJSON/HTMLで返す。

    round6でCSRF検証(`_csrf_protect`)を追加したことで、multipart
    フォームのボディ解析(`request.form`へのアクセス)がbefore_requestの
    時点で発生するようになった。これにより、以前は`/api/generate`の
    view関数内のtry/exceptで捕まえていた`RequestEntityTooLarge`が、
    view関数に到達する前(before_requestの中)で送出されるケースが生まれた
    (実際にテストで確認: CSRF検証追加前は`/api/generate`のtry/exceptが
    捕捉していたため413+JSONを返せていたが、追加後はFlask標準の
    HTML形式の413ページになってしまっていた)。ここでグローバルな
    エラーハンドラを追加することで、view到達前後どちらで発生しても
    一貫したレスポンスになるようにする。
    """
    if request.path.startswith("/api/") or request.accept_mimetypes["application/json"] > request.accept_mimetypes["text/html"]:
        # round37: 文言は`_too_large_message`に集約した。
        # **実際に利用者へ届くのはここ**である——CSRF検証がbefore_requestで
        # 本文を読むため、view関数のtry/exceptより先にこのハンドラに来る。
        # round37の実測では、view側の文言だけ直してもここが古いままで、
        # 画面には古い文言が出続けていた(直したつもりで直っていなかった)。
        return jsonify({"ok": False, "error": _too_large_message()}), 413
    return render_template("500.html", error_id="413"), 413


def _download_not_found(expired: bool = False):
    """ダウンロードが見つからないときの応答 (round51)。

    【round50まで何が起きていたか】`/download/...` は Accept を見ずに
    `jsonify({"ok": False, "error": "not found"})` を返していた。
    ブラウザでリンクを開くと、画面に

        {"error":"not found","ok":false}

    と**生のJSONだけ**が出ていた。生成物の保存期間は既定1時間なので、
    「リンクをブックマークして翌日開く」「タブを開いたまま一晩置く」は
    ふつうに起こる。そのとき利用者に見えるのがこれだった。

    `expired=True` は「持ち主は合っているが、ファイルがもう無い」場合。
    持ち主の確認は済んでいるので、保存期間の説明まで踏み込んで書ける
    (他人のjob_idの存在を探れてしまう心配が無い)。
    それ以外は、存在しない場合と持ち主違いを区別しない従来どおりの404。
    """
    wants_json = (request.path.startswith("/api/")
                  or request.accept_mimetypes["application/json"]
                  > request.accept_mimetypes["text/html"])
    if wants_json:
        return jsonify({"ok": False, "error": "not found"}), 404
    if expired:
        hours = max(1, round(OUTPUT_TTL_SECONDS / 3600))
        return render_template("download_expired.html", hours=hours), 404
    return render_template("404.html"), 404


@app.errorhandler(404)
def _handle_not_found(exc):
    if request.path.startswith("/api/") or request.accept_mimetypes["application/json"] > request.accept_mimetypes["text/html"]:
        return jsonify({"ok": False, "error": "not found"}), 404
    return render_template("404.html"), 404


@app.errorhandler(405)
def _handle_method_not_allowed(exc):
    """許可されていないメソッド(405)を、この製品の言葉で返す。

    【round47まで何が起きていたか】404・413・500には手当てがあったのに
    405だけ無く、`GET /api/generate` はFlask既定の

        <title>405 Method Not Allowed</title>

    という**英語の枠組みそのままの画面**を返していた。日本語の製品の中で
    ここだけ素の英語が出るうえ、使っている枠組みを外へ知らせることにもなる。
    """
    if request.path.startswith("/api/") or request.accept_mimetypes["application/json"] > request.accept_mimetypes["text/html"]:
        return jsonify({"ok": False,
                        "error": "このURLでは、その送り方(メソッド)は使えません。"}), 405
    return render_template("404.html"), 405


@app.errorhandler(500)
def _handle_server_error(exc):
    # 想定外の例外の詳細はログにのみ残し、利用者にはIDだけを返す
    # (/api/generate の例外ハンドリングと同じ方針)。
    error_id = uuid.uuid4().hex[:8]
    app.logger.exception("unhandled server error [error_id=%s]", error_id)
    if request.path.startswith("/api/") or request.accept_mimetypes["application/json"] > request.accept_mimetypes["text/html"]:
        return jsonify({"ok": False, "error": f"internal error (id: {error_id})"}), 500
    return render_template("500.html", error_id=error_id), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=os.environ.get("FLASK_DEBUG") == "1")
